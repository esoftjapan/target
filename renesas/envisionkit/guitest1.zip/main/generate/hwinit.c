                                                                          
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                           
                                                                          
/************************************************************************
*
* Device     : RX/RX600/RX65N
*
* File Name  : hwsetup.c
*
* Abstract   : Hardware Setup file.
*
* History    : 0.5A  (2015-11-20)  [Hardware Manual Revision : 0.50]
*
* NOTE       : THIS IS A TYPICAL EXAMPLE.
*
* Copyright (C) 2015 Renesas Electronics Corporation.
*
************************************************************************/

#include "iodefine.h"
#ifdef __cplusplus
extern "C" {
#endif
extern void HardwareSetup(void);
#ifdef __cplusplus
}
#endif


static void SetupClock();

void HardwareSetup(void)
{
	/* クロック発生回路や動作モードレジスタの保護を解除 */
	SYSTEM.PRCR.WORD = 0xA50B;

	/* I/Oポートファンクションレジスタの書き込み保護を解除 */
	MPC.PWPR.BIT.B0WI = 0;
	MPC.PWPR.BIT.PFSWE = 1;

	/* クロックの設定 */
	SetupClock();

	/* I/Oポートファンクションレジスタの書き込み保護を設定 */
	MPC.PWPR.BIT.PFSWE = 0;
	MPC.PWPR.BIT.B0WI = 1;

	/* クロック発生回路や動作モードレジスタの保護を設定 */
	SYSTEM.PRCR.WORD = 0xA500;
}

void SetupClock()
{
	unsigned char rtcdv;

	/* メインクロック発振器：発振子使用、周波数16MHz以下、強制発振はしない */
	SYSTEM.MOFCR.BYTE = 0x20;

	/* メインクロック発振回路待ち時間の設定：(20msec×240kHz+16)/32=150 */
	SYSTEM.MOSCWTCR.BYTE = 150;

	/* メインクロック発振器を開始 */
	SYSTEM.MOSCCR.BIT.MOSTP = 0;

	/* メインクロックの発振が安定するまで待つ */
	while (1 != SYSTEM.OSCOVFSR.BIT.MOOVF);

	/* システムクロックの分周器を設定: ICLK=120MHz, PCLKA=120MHz, PCLKB,C,D=60MHz, BCLK=60MHz */
	SYSTEM.SCKCR.LONG = 0x21c21222;

	/* PLL回路の設定：PLL入力分周比=1/1、PLLSRCSEL=メインクロック、ICLk=120MHZ, 逓倍率=x20 */
	SYSTEM.PLLCR.WORD = 0x2700;

	/* PLL回路動作：発振 */
	SYSTEM.PLLCR2.BIT.PLLEN = 0;

	/* PLLの発振が安定するまで待つ */
	while (1 != SYSTEM.OSCOVFSR.BIT.PLOVF);

	/* RTCクロック源の選択、ボード上にサブクロック用水晶振動子が実装されていないので、メインクロックを使用する */
	RTC.RCR4.BYTE = 1;

#if 0
	/* RTCクロック停止 */
	RTC.RCR3.BIT.RTCEN = 0;

	/* RTCクロックが停止するまで待つ */
	while (0 != RTC.RCR3.BIT.RTCEN);

	/* サブクロック停止 */
	SYSTEM.SOSCCR.BIT.SOSTP = 1;

	/* レジスタが更新するまで待つ */
	while (1 != SYSTEM.SOSCCR.BIT.SOSTP);

	/* サブクロック発振器が停止するまで待つ */
	while (0 != SYSTEM.OSCOVFSR.BIT.SOOVF);

	/* サブクロックのドライブ能力、注意１：RTCDV=1の場合、サブクロックが発振しない恐れがある */
	rtcdv = 6;
	RTC.RCR3.BIT.RTCDV = rtcdv;

	/* RTCDVが更新されるのを待つ */
	while (rtcdv != RTC.RCR3.BIT.RTCDV);

	/* サブクロックの発振待ち時間の設定 */
	SYSTEM.SOSCWTCR.BYTE = 0x25;

	/* サブクロック発振開始 */
	SYSTEM.SOSCCR.BIT.SOSTP = 0;

	/* レジスタが更新するのを待つ */
	while (0 != SYSTEM.SOSCCR.BIT.SOSTP);

	/* サブクロックの発振が安定するまで待つ、上記注意１を見よ */
	while (1 != SYSTEM.OSCOVFSR.BIT.SOOVF);
	SYSTEM.SOSCWTCR.BYTE = 0x00;

	/* サブクロックの発振待ち時間の設定 */
	SYSTEM.SOSCWTCR.BYTE = 0x00;

	/* サブクロック発振開始  */
	RTC.RCR3.BIT.RTCEN = 1;

	/* レジスタが更新するまで待つ */
	while (1 != RTC.RCR3.BIT.RTCEN);
#endif

	/* UCLK=48MHz=240MHz/5 */
	SYSTEM.SCKCR2.WORD = 0x41;

	/* ROMウエイトサイクル、ICLK=120MHz ---> 2サイクル */
	SYSTEM.ROMWT.BYTE = 2;

	/* クロック源としてPLLを選択 */
	SYSTEM.SCKCR3.WORD = 0x400;
}
