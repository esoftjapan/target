/**
 * ui_types.h for linux
 *
 * Copyright 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */

#ifndef __UI_TYPES_H__
#define	__UI_TYPES_H__

#include "target_config.h"

typedef char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;

#if COLORDEPTH==32
/* CAUTION: sizeof(int)==4, but sizeof(long)=4 for 32bit linux, 8 for 64bit linux */
typedef unsigned int color_t;
#elif COLORDEPTH==16
typedef unsigned short color_t;
#else
#error invalid color depth, color depth must be 16bpp or 32bpp
#endif

typedef struct
{
	uint16			height;
	uint16			first;
	uint16			last;
	const uint16	*table;
	const uint8		*width_table;
} font_t;

//data types of model
typedef enum _DATATYPE
{
	VOID_T			= 0,
	STRING_T		= 1,
	BOOL_T			= 2,
	INT_T			= 3,
	LONGINT_T		= 4,
	REAL_T			= 5,
} DATATYPE;

#if COLORDEPTH==32
/**
 * RGB888 color
 * r:8, g:8, b:8
 */
#define REDMASK       	0xFF0000
#define REDSHIFT      	16
#define GREENMASK     	0x00FF00
#define GREENSHIFT    	8
#define BLUEMASK      	0x0000FF
#define BLUESHIFT     	0
#define RGBCOLOR(r,g,b)	((((r)&0xFF)<<REDSHIFT)|(((g)&0xFF)<<GREENSHIFT)|(((b)&0xFF)<<BLUESHIFT))
#elif COLORDEPTH==16
/**
 * RGB565 color
 * r:5, g:6, b:5
 */
#define NUM_COLORS   	65536
#define RED_COLORS    	0x20
#define GREEN_COLORS  	0x40
#define BLUE_COLORS   	0x20
#define REDMASK       	0xF800
#define REDSHIFT      	11
#define GREENMASK     	0x07E0
#define GREENSHIFT    	5
#define BLUEMASK      	0x001F
#define BLUESHIFT     	0
#define RGBCOLOR(r,g,b)	((((r>>3)&0x1F)<<REDSHIFT)|(((g>>2)&0x3F)<<GREENSHIFT)|(((b>>3)&0x1F)<<BLUESHIFT))
#else
#error invalid color depth, color depth must be 16bpp or 32bpp
#endif

#endif
