/**
 * ui_switch.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __SWITCH_H__
#define	__SWITCH_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __SWITCH
{
	CONTROL			base;

	/* switch */
	const uint8*	offimage;	/* off image */
	const uint8*	onimage;	/* onimage */
	const real_t	offvalue;	/* value at off */
	const real_t	onvalue;	/* value at on */
	const uint8		mode;		/* 0:toggle, 1:momentary */
	const uint8		init;		/* initial status */
	uint8			status;		/* 0:off, 1:on(pushed) */
	void*			buddy;		/* buddy */
	const uint8		dataType;	/* buddy data type */
} SWITCH;

extern int Notify_switch(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif