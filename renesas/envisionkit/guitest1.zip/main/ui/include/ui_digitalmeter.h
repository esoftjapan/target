#ifndef __DIGITALMETER_H__
#define	__DIGITALMETER_H__
 
#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

#ifndef NUMDIGITS
#define	NUMDIGITS		(64)
#endif

typedef struct __DIGITALMETER
{
	CONTROL			base;				//base class

	const color_t	bgcolor;			//background color
	const color_t	edgecolor;			//edge color
	const color_t	lcdcolor;			//LCD color
	uint8			ndigits;			//number of total digits
	uint8			precision;			//number of fraction didgits
	uint16			w;					//digit pitch
	uint16			h;					//digit height
	void*			buddy;				//buddy
	uint8			dataType;			//buddy data type
	char			value[NUMDIGITS];	//digits

} DIGITALMETER;

extern int Notify_digitalmeter(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif
