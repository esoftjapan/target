/**
 * ui_touchpanel.h
 */

#pragma once

extern int ui_touchpanel_init(void);
extern int ui_touchpanel_timer_callback(void);
extern int ui_touchpanel_get_x(void);
extern int ui_touchpanel_get_y(void);
extern void ui_calibrate_touchpanel(void);
