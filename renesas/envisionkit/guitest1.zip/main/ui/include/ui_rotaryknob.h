/**
 * ui_rotaryknob.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __ROTARYKNOB_H__
#define	__ROTARYKNOB_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __ROTARYKNOB
{
	CONTROL				base;

	/* rotaryknob */
	const uint16		xc;				/* center of outer circle */
	const uint16		yc;				/* center of outer circle */
	const uint16		rOuter;			/* radius of outer circle */
	const uint16		rInner;			/* radius of inner circle */
	const uint16		rknob;			/* radius of knob */
	const color_t		outercolor;		/* color of outer circle */
	const color_t		knobcolor;		/* knob color */
	const color_t		textcolor;		/* text color */
	const real_t		vmin;			/* minimum value */
	const real_t		vmax;			/* maximum value */
	const real_t		inc;			/* increment value per rotation */
	const real_t		init;			/* initial value */
	const uint8			accuracy;		/* nuber of digits of fraction */
	int16				nrotate;		/* number of rotation */
	real_t				angle;			/* angle */
	real_t				value;			/* value */
	char				text[32];		/* text of value */
	void*				buddy;			/* buddy */
	const uint8			dataType;		/* buddy data type */
} ROTARYKNOB;

extern int Notify_rotaryknob(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif