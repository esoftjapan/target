/**
 * ui_message.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __MESSAGE_H__
#define	__MESSAGE_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __MESSAGE
{
	CONTROL				base;
	
	color_t				fgcolor;
	color_t				bgcolor;
	color_t				edgecolor;
	int8				opaque;
	const uint8*		tga;

} MESSAGE;

extern int Notify_message(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

typedef struct __MESSAGEBOX
{
	CONTROL				base;
	
	int					status;
	color_t				bgcolor;
	color_t				edgecolor;
	MESSAGE*			message1;
	MESSAGE*			message2;
	MESSAGE*			message3;
	const uint8*		ok;
	int					ok_left;
	int					ok_top;
	int					ok_right;
	int					ok_bottom;
} MESSAGEBOX;

extern int Notify_messagebox(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);
extern int vcl_messagebox_show(MESSAGEBOX* mb, MESSAGE* msg1, MESSAGE* msg2, MESSAGE* msg3);
extern int vcl_messagebox_hide(MESSAGEBOX* mb);

#endif