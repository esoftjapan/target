/**
 * ui_bitmapex.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __BITMAPEX_H__
#define	__BITMAPEX_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __BITMAPEX
{
	CONTROL			base;

	/* bitmapex */
	const uint8*	image;		/* bitmap image */
	const uint8		angleUnit;	/* 0:degree, 1:radian */
	const int16		xpivot;		/* center of rotation */
	const int16		ypivot;		/* center of rotation */
	const real_t	xmin;		/* xmin(left) */
	const real_t	ymin;		/* ymin(bottom) */
	const real_t	xmax;		/* xmax(right) */
	const real_t	ymax;		/* ymax(top) */
	const real_t	xscale;		/* xscale = 1/(xmax-xmin) */
	const real_t	yscale;		/* xscale = 1/(ymax-ymin) */
	const uint8		transparent_enable;	/* transparent enable */
	const color_t	transparent_color;	/* transparent color */
	
	void*			xc;			/* x-center of image, cartesian coordinate */
	const uint8		xcdt;		/* xc data type */
	void*			yc;			/* y-center of image, cartesian coordinate */
	const uint8		ycdt;		/* yc data type */
	void*			angle;		/* angle of rotation, counter-clockwise */
	const uint8		angledt;	/* angle data type */
} BITMAPEX;

extern int Notify_bitmapex(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif