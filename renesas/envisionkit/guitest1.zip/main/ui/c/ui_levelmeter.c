/**
 * ui_levelmeter.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>

int Notify_levelmeter(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	LEVELMETER* l = (LEVELMETER*)me;

	if (type==NOTIFY_UPDATE && l->base.visible) {
		int x1 = l->base.left;
		int x2 = l->base.right;
		int y1 = l->base.top;
		int y2 = l->base.bottom;
		real_t value,inv;

		value = 0;
		if (l->buddy) {
			if (l->dataType==BOOL_T||l->dataType==INT_T||l->dataType==LONGINT_T) {
				int_t ivalue = *(int_t*)l->buddy;
				value = (real_t)ivalue;
			} else {
				value = *(real_t*)l->buddy;
			}
		}
		inv = 1/(l->max-l->min);
		
		ui_draw_icon(l->image,l->xorg,l->yorg);
		
		x1 += 1; y1 += 1;
		x2 -= 2; y2 -= 2;
		if (l->style==LMSTYLE_VERT) {
			int y = (int)(((y1-y2)*(value-l->min))*inv+y2);
			y = min(y2,max(y1,y));
			ui_draw_filled_rectangle(x1,y2,x2,y,l->levelcolor,l->levelcolor);
		} else {
			int x = (int)(((x2-x1)*(value-l->min))*inv+x1);
			x = min(x2,max(x1,x));
			ui_draw_filled_rectangle(x1,y1,x,y2,l->levelcolor,l->levelcolor);
		}
	}
	return ecode;
}
