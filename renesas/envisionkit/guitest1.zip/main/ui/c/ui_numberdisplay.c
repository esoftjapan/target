/**
 *
 * ui_numberdisplay.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * --------------------------------------------------------------------------------------------
 *	2018/06/01		YT				created
 *
 */
 
#include <ui_vlx.h>

extern int DrawNumberDisplay(NUMBERDISPLAY* me);

int Notify_numberdisplay(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	NUMBERDISPLAY* nd = (NUMBERDISPLAY*)me;

	if (type==NOTIFY_UPDATE) {
		ecode = DrawNumberDisplay(nd);
		if (nd->edgecolor!=nd->bgcolor) {
			ui_draw_rectangle(nd->base.left,nd->base.top,nd->base.right,nd->base.bottom,nd->edgecolor);
		}
	}
	return ecode;
}

int DrawNumberDisplay(NUMBERDISPLAY* me)
{
	int16 width,height,sp1,sp2;
	int16 n,count,pitch,x,y;
	char c;
	const char *p;
	TGAHEADER* tga;
		
	tga = (TGAHEADER*)me->tga_0;
	pitch = me->pitch;
	x = me->base.right-tga->width/2;
	y = (me->base.top+me->base.bottom-tga->height)/2;

	if (me->buddy) {
		if (me->dataType==BOOL_T||me->dataType==INT_T||me->dataType==LONGINT_T) {
			int_t ivalue = *(int_t*)me->buddy;
			count = i2s(ivalue,me->value,me->ndigits,0);
		} else {
			real_t rvalue = *(real_t*)me->buddy;
			count = ConvR2S(rvalue,me->value,me->ndigits,me->precision,0);
		}
	} else {
		/* CAUTION: numberdisplay inside tenkey has no buddy */
	}
	
	n = 0;
	p = me->value;
	while (*p) {
		p++;
		n++;
	}
	n--;
	
	if (1) {
		int16 x1 = me->base.left;
		int16 y1 = me->base.top;
		int16 x2 = me->base.right;
		int16 y2 = me->base.bottom;

		ui_draw_filled_rectangle(x1,y1,x2,y2,me->bgcolor,me->bgcolor);
	}

	while (n>=0) {
		c = me->value[n];
		switch(c) {
			case '+':
			    width = *((uint16 *)(me->tga_plus + 12));
   			 	height = *((uint16 *)(me->tga_plus + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_plus,x,y);
				break;
				
			case '-':
			    width = *((uint16 *)(me->tga_minus + 12));
   			 	height = *((uint16 *)(me->tga_minus + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_minus,x,y);
				break;
				
			case '.':
			    width = *((uint16 *)(me->tga_dot + 12));
   			 	height = *((uint16 *)(me->tga_dot + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_dot,x,y);
				break;
				
			case '0':
			    width = *((uint16 *)(me->tga_0 + 12));
   			 	height = *((uint16 *)(me->tga_0 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_0,x,y);
				break;
				
			case '1':
			    width = *((uint16 *)(me->tga_1 + 12));
   			 	height = *((uint16 *)(me->tga_1 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_1,x,y);
				break;
				
			case '2':
			    width = *((uint16 *)(me->tga_2 + 12));
   			 	height = *((uint16 *)(me->tga_2 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_2,x,y);
				break;
				
			case '3':
			    width = *((uint16 *)(me->tga_3 + 12));
   			 	height = *((uint16 *)(me->tga_3 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_3,x,y);
				break;
				
			case '4':
			    width = *((uint16 *)(me->tga_4 + 12));
   			 	height = *((uint16 *)(me->tga_4 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_4,x,y);
				break;
				
			case '5':
			    width = *((uint16 *)(me->tga_5 + 12));
   			 	height = *((uint16 *)(me->tga_5 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_5,x,y);
				break;
				
			case '6':
			    width = *((uint16 *)(me->tga_6 + 12));
   			 	height = *((uint16 *)(me->tga_6 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_6,x,y);
				break;
				
			case '7':
			    width = *((uint16 *)(me->tga_7 + 12));
   			 	height = *((uint16 *)(me->tga_7 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_7,x,y);
				break;
				
			case '8':
			    width = *((uint16 *)(me->tga_8 + 12));
   			 	height = *((uint16 *)(me->tga_8 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_8,x,y);
				break;
				
			case '9':
			    width = *((uint16 *)(me->tga_9 + 12));
   			 	height = *((uint16 *)(me->tga_9 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_9,x,y);
				break;
			
			default:
				sp2 = 0;
				break;
		}
		x -= sp2;		
		n--;
	}

	return 0;
}
