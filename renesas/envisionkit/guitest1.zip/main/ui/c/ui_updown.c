/**
 * ui_updown.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>

extern int DrawUpdownDisplay(UPDOWN* me);

int Notify_updown(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	UPDOWN* ud = (UPDOWN*)me;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	if (type==NOTIFY_INIT) {
		/* initialize the buddy */
		ud->value = ud->init;
		WriteValueToBuddy(ud->buddy,ud->dataType,ud->init);
	} else	
	if (type==NOTIFY_PRESSED) {
		UIRECT rcUp,rcDown;
		uint16 x1,x2,y1,y2,x3,x4,d;
		
		x1 = ud->base.left;
		y1 = ud->base.top;
		x2 = ud->base.right;
		y2 = ud->base.bottom;
		d = y2-y1;
		x3 = x2-d-d;
		x4 = x2-d;
		
		rcUp.left = x3; rcUp.top = y1; rcUp.right = x4; rcUp.bottom = y2;
		rcDown.left = x4; rcDown.top = y1; rcDown.right = x2; rcDown.bottom = y2;
		
		if (IsHitRect(&rcUp,x,y)) {
			real_t value = ud->value+ud->inc;
			value = min(ud->ulimit,value);
			ud->value = max(ud->llimit,value);
			WriteValueToBuddy(ud->buddy,ud->dataType,ud->value);
		} else
		if (IsHitRect(&rcDown,x,y)) {
			real_t value = ud->value-ud->inc;
			value = min(ud->ulimit,value);
			ud->value = max(ud->llimit,value);
			WriteValueToBuddy(ud->buddy,ud->dataType,ud->value);
		}
	} else		
	if (type==NOTIFY_UPDATE) {
		uint16 x2,y1,y2,x3,x4,d,z;
		point_t ptUp[3],ptDown[3];
		
		ecode = DrawUpdownDisplay(ud);

		d = ud->base.bottom-ud->base.top;
		ui_draw_rectangle(ud->base.left,ud->base.top,ud->base.right-d-d,ud->base.bottom,ud->edgecolor);
		
		y1 = ud->base.top;
		x2 = ud->base.right;
		y2 = ud->base.bottom;
		d = y2-y1;
		x3 = x2-d-d;
		x4 = x2-d;
		
		/* counter clockwise */
		z = d/5;
		ptUp[0].x = (x3+x4)/2;		ptUp[0].y = y1+z;
		ptUp[1].x = x3+z;			ptUp[1].y = y2-z;
		ptUp[2].x = x4-z;			ptUp[2].y = y2-z;
		
		ptDown[0].x = (x4+x2)/2;	ptDown[0].y = y2-z;
		ptDown[1].x = x2-z;			ptDown[1].y = y1+z;
		ptDown[2].x = x4+z;			ptDown[2].y = y1+z;

		ui_draw_polygon(3,ptUp,BLACK,BLACK);
		ui_draw_polygon(3,ptDown,BLACK,BLACK);
		ui_draw_rectangle(x3,y1,x2,y2,BLACK);
		ui_draw_vertical_line(x4,y1,y2,BLACK);
		
	}
	return ecode;
}

int DrawUpdownDisplay(UPDOWN* me)
{
	int16 width,height,sp1,sp2;
	int16 n,count,pitch,x,y,d;
	char c;
	const char *p;
	TGAHEADER* tga;
	
	tga = (TGAHEADER*)me->tga_0;
	pitch = me->pitch;
	d = me->base.bottom-me->base.top;
	x = me->base.right-d-d-tga->width/2;
	y = (me->base.top+me->base.bottom-tga->height)/2;
		
	if (me->dataType==BOOL_T||me->dataType==INT_T||me->dataType==LONGINT_T) {
		count = i2s((int_t)me->value,me->digits,me->ndigits,0);
	} else {
		qreal q = ConvR2Q(me->value);
		count = q2s(q,me->digits,me->ndigits,me->precision,0);
	}
	
	n = 0;
	p = me->digits;
	while (*p) {
		p++;
		n++;
	}
	n--;
	
	if (1) {
		int16 x1 = me->base.left;
		int16 y1 = me->base.top;
		int16 x2 = me->base.right;
		int16 y2 = me->base.bottom;

		ui_draw_filled_rectangle(x1,y1,x2,y2,me->bgcolor,me->bgcolor);
	}

	sp1 = 0;
	sp2 = 0;
	while (n>=0) {
		c = me->digits[n];
		switch(c) {
			case '+':
			    width = *((uint16 *)(me->tga_plus + 12));
   			 	height = *((uint16 *)(me->tga_plus + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_plus,x,y);
				break;
				
			case '-':
			    width = *((uint16 *)(me->tga_minus + 12));
   			 	height = *((uint16 *)(me->tga_minus + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_minus,x,y);
				break;
				
			case '.':
			    width = *((uint16 *)(me->tga_dot + 12));
   			 	height = *((uint16 *)(me->tga_dot + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_dot,x,y);
				break;
				
			case '0':
			    width = *((uint16 *)(me->tga_0 + 12));
   			 	height = *((uint16 *)(me->tga_0 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_0,x,y);
				break;
				
			case '1':
			    width = *((uint16 *)(me->tga_1 + 12));
   			 	height = *((uint16 *)(me->tga_1 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_1,x,y);
				break;
				
			case '2':
			    width = *((uint16 *)(me->tga_2 + 12));
   			 	height = *((uint16 *)(me->tga_2 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_2,x,y);
				break;
				
			case '3':
			    width = *((uint16 *)(me->tga_3 + 12));
   			 	height = *((uint16 *)(me->tga_3 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_3,x,y);
				break;
				
			case '4':
			    width = *((uint16 *)(me->tga_4 + 12));
   			 	height = *((uint16 *)(me->tga_4 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_4,x,y);
				break;
				
			case '5':
			    width = *((uint16 *)(me->tga_5 + 12));
   			 	height = *((uint16 *)(me->tga_5 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_5,x,y);
				break;
				
			case '6':
			    width = *((uint16 *)(me->tga_6 + 12));
   			 	height = *((uint16 *)(me->tga_6 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_6,x,y);
				break;
				
			case '7':
			    width = *((uint16 *)(me->tga_7 + 12));
   			 	height = *((uint16 *)(me->tga_7 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_7,x,y);
				break;
				
			case '8':
			    width = *((uint16 *)(me->tga_8 + 12));
   			 	height = *((uint16 *)(me->tga_8 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_8,x,y);
				break;
				
			case '9':
			    width = *((uint16 *)(me->tga_9 + 12));
   			 	height = *((uint16 *)(me->tga_9 + 14));
				sp1 = (pitch-width)>>1;
				sp2 = pitch-width-sp1;
				x -= width+sp1;
				ui_draw_icon(me->tga_9,x,y);
				break;
			
			default:
				break;
		}
		x -= sp2;		
		n--;
	}

	return 0;
}