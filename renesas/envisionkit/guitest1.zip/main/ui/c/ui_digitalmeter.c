/**
 *
 * ui_digitalmeter.c
 *
 * Copyright(C) 2019 eSoft. All right reserved.
 *
 * --------------------------------------------------------------------------------------------
 *	2019/04/28		YT				created
 *
 *
 *    +sssssssssssssssssssssss
 *	  ssss----------------ssss
 *    sss        a         sss
 *    ss|                  |ss
 *    ss|f                b|ss
 *    ss|                  |ss
 *    sss        g         sss
 *	  sss----------------sssss
 *    sss                  sss
 *    ss|                  |ss
 *    ss|e                c|ss
 *    ss|                  |ss
 *    sss        d         sss
 *	  ssss----------------ssss
 *    ssssssssssssssssssssssss
 *      
 */
 
#include <ui_vlx.h>

static int DrawDigitalMeter(DIGITALMETER* dm);

int Notify_digitalmeter(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	DIGITALMETER* dm = (DIGITALMETER*)me;

	if (type==NOTIFY_UPDATE) {
		ui_draw_filled_rectangle(dm->base.left,dm->base.top,dm->base.right,dm->base.bottom,dm->bgcolor,dm->edgecolor);
		DrawDigitalMeter(dm);
	}
	return ecode;
}

static int DrawDigitalMeter(DIGITALMETER* me)
{
	int16 x,y,w,h,w1,w12,h1,h2,linewidth,n,count;
	int16 s,s2,s3,s4,s6;
	color_t lcdcolor;
	const char *p;
	char c;

	if (me->buddy) {
		if (me->dataType==BOOL_T||me->dataType==INT_T||me->dataType==LONGINT_T) {
			int_t ivalue = *(int_t*)me->buddy;
			count = i2s(ivalue,me->value,me->ndigits,0);
		} else {
			real_t rvalue = *(real_t*)me->buddy;
			count = ConvR2S(rvalue,me->value,me->ndigits,me->precision,0);
		}
	} else {
		return 0;
	}

	n = 0;
	p = me->value;
	while (*p) {
		p++;
		n++;
	}
	n--;

	w = me->w;
	h = me->h;
	s = max(1,h/20);
	s2 = s*2;
	s3 = s*3;
	s4 = s*4;
	s6 = s*6;

	w1 = w-s*8;
	w12 = w1/2;
	h1 = h/2-s6;
	h2 = h1*2;
	linewidth = s;
	lcdcolor = me->lcdcolor;

	x = me->base.right-w;
	y = me->base.top+s2;

	while (n>=0) {
		c = me->value[n];
		switch(c) {
			case '+':
				ui_draw_vertical_line_linewidth(x+s4+w12,y+s4+h1-w12,y+s4+h1+w12,linewidth,lcdcolor);
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
				
			case '-':
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
				
			case '.':
				ui_draw_filled_rectangle(x+s4+w1/2-s,y+s6+h2-s,x+s4+w1/2+s,y+s6+h2+s,lcdcolor,lcdcolor);
				break;
				
			case '0':
				/*a*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s,linewidth,lcdcolor);
				/*b*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*c*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*d*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s6+h2,linewidth,lcdcolor);
				/*e*/ui_draw_vertical_line_linewidth(x+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*f*/ui_draw_vertical_line_linewidth(x+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				break;
				
			case '1':
				/*b-centor*/ui_draw_vertical_line_linewidth(x+s4+w12+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*c-centor*/ui_draw_vertical_line_linewidth(x+s4+w12+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				break;
				
			case '2':
				/*a*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s,linewidth,lcdcolor);
				/*b*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*d*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s6+h2,linewidth,lcdcolor);
				/*e*/ui_draw_vertical_line_linewidth(x+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
				
			case '3':
				/*a*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s,linewidth,lcdcolor);
				/*b*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*c*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*d*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s6+h2,linewidth,lcdcolor);
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
				
			case '4':
				/*b*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*c*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*f*/ui_draw_vertical_line_linewidth(x+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
				
			case '5':
				/*a*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s,linewidth,lcdcolor);
				/*c*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*d*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s6+h2,linewidth,lcdcolor);
				/*f*/ui_draw_vertical_line_linewidth(x+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
				
			case '6':
				/*a*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s,linewidth,lcdcolor);
				/*c*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*d*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s6+h2,linewidth,lcdcolor);
				/*e*/ui_draw_vertical_line_linewidth(x+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*f*/ui_draw_vertical_line_linewidth(x+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
				
			case '7':
				/*a*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s,linewidth,lcdcolor);
				/*b*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*c*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				break;
				
			case '8':
				/*a*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s,linewidth,lcdcolor);
				/*b*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*c*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*d*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s6+h2,linewidth,lcdcolor);
				/*e*/ui_draw_vertical_line_linewidth(x+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*f*/ui_draw_vertical_line_linewidth(x+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
				
			case '9':
				/*a*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s,linewidth,lcdcolor);
				/*b*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*c*/ui_draw_vertical_line_linewidth(x+s4+w1+s2,y+s6+h1,y+s6+h2,linewidth,lcdcolor);
				/*d*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s6+h2,linewidth,lcdcolor);
				/*f*/ui_draw_vertical_line_linewidth(x+s2,y+s3,y+s3+h1,linewidth,lcdcolor);
				/*g*/ui_draw_horizontal_line_linewidth(x+s4,x+s4+w1,y+s4+h1,linewidth,lcdcolor);
				break;
			
			default:
				break;
		}
		x -= w;		
		n--;
	}

	return 0;
}
