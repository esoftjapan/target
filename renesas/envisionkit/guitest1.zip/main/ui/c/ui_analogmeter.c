/**
 * ui_analogmeter.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>

int Notify_analogmeter(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	ANALOGMETER* a = (ANALOGMETER*)me;

	if (type==NOTIFY_UPDATE && a->base.visible) {
		int x1 = a->base.left;
		int x2 = a->base.right;
		int y1 = a->base.top;
		int y2 = a->base.bottom;
		real_t value,theta,inv;
		float angle,C,S,r,xc,yc,x,y;
		point_t pt[3];

		value = 0;
		if (a->buddy) {
			if (a->dataType==BOOL_T||a->dataType==INT_T||a->dataType==LONGINT_T) {
				int_t ivalue = *(int_t*)a->buddy;
				value = (real_t)ivalue;
			} else {
				value = *(real_t*)a->buddy;
			}
		}
		
		/* background image */
		ui_draw_icon(a->image,x1,y1);

		/* indicator */
		inv = 1/(a->max-a->min);
		theta = (value-a->min)*(a->end-a->begin)*inv+a->begin;
		angle = (float)theta;
		
		xc = (x1+x2)*0.5f;
		yc = (y1+y2)*0.5f;
		r = min(x2-x1,y2-y1)*0.5f;
		x = r*0.35f;
		y = r*0.03f;

		/* using lookup table */
		_sincosf(angle,&S,&C);

		/* vertes must be ordered in counter-clockwise */
		pt[0].x = (uint16)(xc-r*S);		pt[0].y = (uint16)(yc+r*C);
		pt[1].x = (uint16)(xc+x*S+y*C);	pt[1].y = (uint16)(yc-x*C+y*S);
		pt[2].x = (uint16)(xc+x*S-y*C);	pt[2].y = (uint16)(yc-x*C-y*S);
			
		//ui_draw_polyline(3,pt,a->indicatorcolor);
		ui_draw_polygon(3,pt,a->indicatorcolor,a->indicatorcolor);
	}
	return ecode;
}
