/**
 * ui_actionbuttonex.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>

extern int _active_panel;
extern int _previous_panel;
extern PANEL* _panels[];

int Notify_actionbuttonex(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	ACTIONBUTTONEX* b = (ACTIONBUTTONEX*)me;
	
	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	if (type==NOTIFY_PRESSED) {
		if (IsHit((CONTROL*)b,x,y)) {
			if (b->status==0) {
				b->status = 1;
				InvalidateDisplay();
			}
		}
	} else
	if (type==NOTIFY_RELEASED) {
		if (b->status) {
			if (b->type==ACTION_OPENPANEL) {
				if (b->panel>=0) {					
					/* pop up b->panel */
					_previous_panel = _active_panel;
					_active_panel = b->panel;
					_panels[_active_panel]->visible = 1;
				}
			} else
			if (b->type==ACTION_CLOSEPANEL) {
				if (b->panel>=0) {
					/* close b->panel */
					_panels[b->panel]->visible = 0;

					if (b->panel==_active_panel) {
						/* pop up previous panel */
						_active_panel = _previous_panel;
					}
				} else {
					/* close this panel */
					_panels[_active_panel]->visible = 0;
					
					/* pop up previous panel */
					_active_panel = _previous_panel;
				}
			} else
			if (b->type==ACTION_CLOSEANDOPENPANEL) {
				if (b->panel>=0) {
					/* close this panel */
					_panels[_active_panel]->visible = 0;
					
					/* open b->panel */
					_previous_panel = _active_panel;
					_active_panel = b->panel;
				} else {
					/* nothing happen */
				}
			} else
			if (b->type==ACTION_QUIT) {
				Quit();
			}
			b->status = 0;
			InvalidateDisplay();
		}
	} else
	if (type==NOTIFY_UPDATE) {
		int16 x1 = max(0,b->base.left-1);
		int16 y1 = max(0,b->base.top-1);
		int16 x2 = min(ui_get_framebuffer_width(),b->base.right+1);
		int16 y2 = min(ui_get_framebuffer_height(),b->base.bottom+1);

		if (b->status) {
			if (b->image) {
				ui_draw_icon(b->image,b->base.left+5,b->base.top+5);
			} else {
				ui_draw_rectangle(x1,y1,x2,y2,MAGENTA);
			}
		} else {
			if (b->image) {
				ui_draw_icon(b->image,b->base.left,b->base.top);
			} else {
				ui_draw_rectangle(x1,y1,x2,y2,BLACK);
			}
		}
	}
	return ecode;
}
