/**
 * ui_bitmapex.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>
	
#define	PIdiv2		(1.5707963267948966192313216916398f)
#define	PI2div360	(0.01745329251994329576923690768489f)

int Notify_bitmapex(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	BITMAPEX* b = (BITMAPEX*)me;

	if (type==NOTIFY_UPDATE) {
		if (b->base.visible) {
			uint16 x,y,xcImage,ycImage,xp,yp;
			uint16 width,height,panel_width,panel_height;
			uint8 current_transparent_enable = ui_get_transparent_enable();
			color_t current_transparent_color = ui_get_transparent_color();
			TGAHEADER* tga = (TGAHEADER*)b->image;
			
			panel_width = GetPanelWidth();
			panel_height = GetPanelHeight();
			width = tga->width; /* CAUTION: image size is different to control size */
			height = tga->height;
			xcImage = (b->base.left+b->base.right)/2;
			ycImage = (b->base.top+b->base.bottom)/2;
			xp = b->xpivot+width/2;
			yp = -b->ypivot+height/2;
			
			ui_set_transparent(b->transparent_enable,b->transparent_color);
			
			if (b->angle) {
				real_t angle = 0;
				
				if (b->xc) {
					real_t value = ReadValueFromBuddy(b->xc,b->xcdt);
					x = -xp+(uint16)((value-b->xmin)*panel_width*b->xscale);
				} else {
					x = xcImage-width/2;
				}
				if (b->yc) {
					real_t value = ReadValueFromBuddy(b->yc,b->ycdt);
					y = -yp+panel_height-(uint16)((value-b->ymin)*panel_height*b->yscale);
				} else {
					y = ycImage-height/2;
				}
				x = max(0,min(x,panel_width));
				y = max(0,min(y,panel_height));
				
				/* rotate */
				angle = ReadValueFromBuddy(b->angle,b->angledt);
				if (b->angleUnit==0) {
					angle *= (real_t)PI2div360;
				}
				
				/* angle in the model is count-clockwise */
				ui_draw_icon_with_rotate(b->image,x,y,xp,yp,-angle);
			} else {
				/* no rotate */
				if (b->xc) {
					real_t value = ReadValueFromBuddy(b->xc,b->xcdt);
					x = -xp+(uint16)((value-b->xmin)*panel_width*b->xscale);
				} else {
					x = xcImage-width/2;
				}
				if (b->yc) {
					real_t value = ReadValueFromBuddy(b->yc,b->ycdt);
					y = -yp+panel_height-(uint16)((value-b->ymin)*panel_height*b->yscale);
				} else {
					y = ycImage-height/2;
				}
				x = max(0,min(x,panel_width));
				y = max(0,min(y,panel_height));
				
				ui_draw_icon(b->image,x,y);
			}
			ui_set_transparent(current_transparent_enable,current_transparent_color);
		}
	}
	return ecode;
}
