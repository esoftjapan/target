/**
 * ui_framebuffer.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created 
 */
 
#include <string.h>
#include "ui_types.h"
#include "ui_colors.h"
#include "ui_framebuffer.h"
#include "ui_utils.h"
#include "ui_system.h"
#include "glcdc.h"

extern unsigned short* GetActiveFrameBuffer();
extern unsigned short* GetHiddenFrameBuffer();

/**
 * color_t = RGB16(r,g,b) = ((((r>>3)&0x1F)<<11)|(((g>>2)&0x3F)<<5)|(((b>>3)&0x1F)<<0))
 * COLORREF = RGB(r,g,b) = 0x00bbggrr
 */

/******************************************************************************/
inline void ui_draw_pixel(color_t* p, color_t color)
{
#if 0
	color_t* fb = ui_get_hidden_framebuffer();
	int width = GetPanelWidth;
	int height = GetPanelHeight();

	if (p>=fb+width*height*sizeof(color_t)) {
		FatalError(__FILE__,__LINE__,"ui_draw_pixel:out of range");
	}
#endif
	*p = color;
}

inline color_t ui_get_pixel_color(color_t* p)
{
	color_t color = *p;
	return color;
}

inline color_t* ui_get_active_framebuffer()
{
	return GetActiveFrameBuffer();
}

inline color_t* ui_get_hidden_framebuffer()
{
	return GetHiddenFrameBuffer();
}

inline uint16 ui_get_framebuffer_width()
{
	return LCD_HDOT;
}

inline uint16 ui_get_framebuffer_height()
{
	return LCD_VDOT;
}

void ui_clear_framebuffer(color_t bgcolor)
{
	color_t* fb = ui_get_hidden_framebuffer();

	if (bgcolor==WHITE) {
		/**
		 * memset is compiled to SSTR instruction
		 * the fastest
		 */
		memset(fb,0xff,LCD_VDOT*LCD_HDOT*sizeof(color_t));
	} else {
		int x,y;
		for (y=0; y<LCD_VDOT; y++) {
			for (x=0; x<LCD_HDOT; x++) {
				color_t* p = fb+y*LCD_HDOT+x;
				*p = bgcolor;
			}
		}
	}
}

void ui_draw_framebuffer()
{
}

void ui_switch_framebuffer()
{
	/**
	 * フレームバッファの切り替えはglcdc.cのVPOS割り込みの中で行う
	 */
}
