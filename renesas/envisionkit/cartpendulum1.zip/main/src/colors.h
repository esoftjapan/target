/**
 * colors.h
 *
 * Copyright 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */

#pragma once

#define RGB16(r,g,b)      	((((r>>3)&0x1F)<<11)|(((g>>2)&0x3F)<<5)|(((b>>3)&0x1F)<<0) )

#define BLACK     	    	RGB16(0, 0, 0)
#define LIGHTGRAY  	   		RGB16(192,192,192)
#define DARKGRAY   	   		RGB16(64, 64, 64)
#define WHITE      	   		RGB16(255, 255, 255)
#define RED           		RGB16(255, 0, 0)
#define GREEN         		RGB16(0, 255, 0)
#define BLUE          		RGB16(0, 0, 255)
#define MAGENTA       		(RED | BLUE)
#define CYAN          		(GREEN | BLUE)
#define YELLOW        		(RED | GREEN)
#define LIGHTRED      		RGB16(255, 64, 64)
#define LIGHTGREEN    		RGB16(64, 255, 64)
#define LIGHTBLUE     		RGB16(64, 64, 255)
#define LIGHTMAGENTA  		(LIGHTRED | LIGHTBLUE)
#define LIGHTCYAN     		(LIGHTGREEN | LIGHTBLUE)
#define LIGHTYELLOW   		(LIGHTRED | LIGHTGREEN)
#define REDMASK       		0xF800
#define REDSHIFT      		11
#define GREENMASK     		0x07E0
#define GREENSHIFT    		5
#define BLUEMASK      		0x001F
#define BLUESHIFT     		0

/* Number of colors in 565 mode */
#define NUM_COLORS    65536
#define RED_COLORS    0x20
#define GREEN_COLORS  0x40
#define BLUE_COLORS   0x20

