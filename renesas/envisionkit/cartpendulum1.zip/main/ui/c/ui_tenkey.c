/**
 * ui_tenkey.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <stdio.h>
#include <string.h>
#include <ui_vlx.h>

#pragma warning(disable:4996)

#define	KEY_DISPLAYAREA			(0)
#define	KEY_ENTER				(1)
#define	KEY_CLEAR				(2)
#define	KEY_BS					(3)
#define	KEY_ESC					(4)
#define	KEY_SIGN				(5)
#define	KEY_WIDTH				(50)
#define	KEY_HEIGHT				(40)

static int FindEntry(TENKEY* tk, int x, int y);

int Notify_tenkey(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	TENKEY* tk = (TENKEY*)me;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	if (type==NOTIFY_INIT) {
		uint16 x1 = tk->base.left;
		uint16 y1 = tk->base.top;
		uint16 x2 = tk->base.right;
		uint16 y2 = tk->y1+KEY_HEIGHT;
	
		tk->numberdisplay->base.left = x1;
		tk->numberdisplay->base.top = y1;
		tk->numberdisplay->base.right = x2;
		tk->numberdisplay->base.bottom = y2;
		tk->pos = 0;
		tk->status = 0;
		tk->base.visible = 0;
	}
	
	if (!tk->base.visible) {
		return ecode;
	}
	
	if (type==NOTIFY_PRESSED) {
		if (IsHit((CONTROL*)tk,x,y)) {
			Buzzer(250,25);
			tk->status = 1;			
			tk->entry = FindEntry(tk,x,y);
		} else {
			//cancel
			tk->base.visible = 0;
		}
	} else
	if (type==NOTIFY_RELEASED) {
		if (tk->status && IsHit((CONTROL*)tk,x,y)) {
			int entry = tk->entry;
			if (entry==KEY_DISPLAYAREA) {
			} else
			if (entry==KEY_ESC) {
				tk->base.visible = 0;
				InvalidateDisplay();
			} else
			if (entry==KEY_ENTER) {
				tk->numberdisplay->value[tk->pos] = 0;
				tk->pos = 0;
				tk->base.visible = 0;
				
				if (tk->owner && tk->owner->notify) {
					/* notify to the owner */
					(tk->owner->notify)(NOTIFY_ACTION,tk->owner,tk,tk->numberdisplay->value);
				}
				InvalidateDisplay();
			} else
			if (entry==KEY_CLEAR) {
				tk->pos = 0;
				tk->numberdisplay->value[0] = 0;
				InvalidateDisplay();
			} else
			if (entry==KEY_BS) {
				tk->pos = max(0,tk->pos-1);
				tk->numberdisplay->value[tk->pos] = 0;
				InvalidateDisplay();
			} else
			if (entry==KEY_SIGN) {
				//toggle sign
				int i,n;

				if (tk->numberdisplay->value[0]=='-') {
					//remove '-'
					n = tk->pos+1;
					for (i=1; i<n; i++) {
						tk->numberdisplay->value[i-1] = tk->numberdisplay->value[i];
					}
					tk->pos--;
				} else {
					//add '-'
					n = tk->pos;
					for (i=n; i>=0; i--) {
						tk->numberdisplay->value[i+1] = tk->numberdisplay->value[i];
					}
					tk->numberdisplay->value[0] = '-';
					tk->pos++;
				}
				InvalidateDisplay();
			} else {
				//0,1,2,3,4,5,6,7,8,9,.,
				tk->numberdisplay->value[tk->pos++] = entry;
				tk->numberdisplay->value[tk->pos] = 0;
				InvalidateDisplay();
			}	
			tk->status = 0;
		}
	} else
	if (type==NOTIFY_UPDATE) {
		if (tk->status) {
			ui_draw_icon(tk->tga,tk->base.left,tk->base.top);
		} else {
			ui_draw_icon(tk->tga,tk->base.left,tk->base.top);
		}
	}

	/* numberdisplay */
	Notify_numberdisplay(type,(CONTROL*)tk->numberdisplay,param1,param2);

	return ecode;
}

/**
 * find key entry
 */
int FindEntry(TENKEY* tk, int x, int y)
{
	int8 entry = 0;
	
	//1st row
	tk->x1 = tk->base.left;
	tk->y1 = tk->base.top;
	tk->x2 = tk->base.right;
	tk->y2 = tk->y1+KEY_HEIGHT;
	if (y>=tk->y1 && y<tk->y2) {
		entry = KEY_DISPLAYAREA;
		goto Lexit;
	}
	
	//2nd row
	tk->y1 += KEY_HEIGHT;
	tk->y2 += KEY_HEIGHT;
	if (y>=tk->y1 && y<tk->y2) {
		tk->x1 = tk->base.left;
		tk->x2 = tk->x1+KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '7';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '8';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '9';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		entry = KEY_CLEAR;
		goto Lexit;
	}
	
	//3rd row
	tk->y1 += KEY_HEIGHT;
	tk->y2 += KEY_HEIGHT;
	if (y>=tk->y1 && y<tk->y2) {
		tk->x1 = tk->base.left;
		tk->x2 = tk->x1+KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '4';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '5';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '6';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		entry = KEY_BS;
		goto Lexit;
	}
	
	//4th row
	tk->y1 += KEY_HEIGHT;
	tk->y2 += KEY_HEIGHT;
	if (y>=tk->y1 && y<tk->y2) {
		tk->x1 = tk->base.left;
		tk->x2 = tk->x1+KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '1';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '2';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '3';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		entry = KEY_ESC;
		goto Lexit;
	}
	
	//5th row
	tk->y1 += KEY_HEIGHT;
	tk->y2 += KEY_HEIGHT;
	if (y>=tk->y1 && y<tk->y2) {
		tk->x1 = tk->base.left;
		tk->x2 = tk->x1+KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '0';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = '.';
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		if (x>=tk->x1 && x<tk->x2) {
			entry = KEY_SIGN;
			goto Lexit;
		}
		tk->x1 += KEY_WIDTH;
		tk->x2 += KEY_WIDTH;
		entry = KEY_ENTER;
		goto Lexit;
	}

Lexit:		
	return entry;
}

void ui_tenkey_show(TENKEY* tk)
{
	tk->base.visible = 1;
	InvalidateDisplay();
}

void ui_tenkey_initialize(TENKEY* tk)
{
	tk->status = 0;
	tk->entry = 0;
	tk->pos = 0;
	tk->numberdisplay->value[0] = 0;
}

void ui_tenkey_set_value(TENKEY* tk, const char* src)
{
	tk->pos = strlen(src);
	strcpy(tk->numberdisplay->value,src);
}

void ui_tenkey_get_value(TENKEY* tk, char* dst)
{
	strcpy(dst,tk->numberdisplay->value);
}

int DrawDigitalMeter(NUMBERDISPLAY* me)
{
	return 0;
}
