/**
 * ui_utils.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */
 
#include <ui_vlx.h>
#include "model_ui.h"

#if !defined(NUMPANELS)
#error	NUMPANELS is not defined
#endif

PANEL* GetActivePanel()
{
#if NUMPANELS>0
	PANEL* panel = _panels[_active_panel]; 
	return panel;
#else
	return 0;
#endif
}

uint8 IsMainPanel(PANEL* panel)
{
#if NUMPANELS>0
	return panel==_panels[0];
#else
	return 0;
#endif
}

uint8 IsHit(CONTROL* c, uint16 x, uint16 y)
{
	uint8 yes = (x>=c->left && x<=c->right && y>=c->top && y<=c->bottom);
	return yes;
}

uint8 IsHitEx(CONTROL* c, uint16 x, uint16 y, uint16 dx, uint16 dy)
{
	uint8 yes = (x>=c->left-dx && x<=c->right+dx && y>=c->top-dy && y<=c->bottom+dy);
	return yes;
}

uint8 IsHitRect(UIRECT* rc, uint16 x, uint16 y)
{
	uint8 yes = (x>=rc->left && x<=rc->right && y>=rc->top && y<=rc->bottom);
	return yes;
}

int StringLength(const char* str)
{
	int len = 0;
	if (str==0) {
		return 0;
	}
	while (*str++) {
		len++;
	}
	return len;
}

int StringClear(char* str)
{
	if (str==0) {
		return -1;
	}
	while (*str) {
		*str++ = 0;
	}
	return 0;
}

int StringCopy(char* dst, const char* src, int count)
{
	int i;

	if (dst==0||src==0) {
		return -1;
	}

	i = 0;
	while (*src && i<count-1) {
		*dst++ = *src++;
		i++;
	}
	*dst = 0;
	return 0;
}

int StringAppend(char* dst, const char* src, int count)
{
	int i,len1,len2;

	if (dst==0||src==0) {
		return -1;
	}

	len1 = StringLength(dst);
	len2 = StringLength(src);

	i = len1;
	dst += len1;
	while (*src && len1+i<count-1) {
		*dst++ = *src++;
		i++;
	}
	*dst = 0;
	return i;
}

uint8 WriteValueToBuddy(void* buddy, DATATYPE dataType, real_t value)
{
	uint8 res = 1;
	
	if (buddy) {
		EnterCritical();
		if (dataType==BOOL_T) {
			*(bool_t*)buddy = (bool_t)value;
		} else
		if (dataType==INT_T) {
			*(int_t*)buddy = (int_t)value;
		} else
		if (dataType==LONGINT_T) {
			*(longint_t*)buddy = (longint_t)value;
		} else
		if (dataType==REAL_T) {
			*(real_t*)(buddy) = (real_t)value;
		} else {
			FatalError(__FILE__,__LINE__,"WriteValueToBuddy");
		}
		ExitCritical();
	} else {
		res = 0;
	}
	return res;
}

real_t ReadValueFromBuddy(void* buddy, DATATYPE dataType)
{
	real_t rvalue = 0;
	
	if (buddy) {
		if (dataType==BOOL_T) {
			bool_t bvalue = *(bool_t*)buddy;
			rvalue = (real_t)bvalue;	
		} else
		if (dataType==INT_T) {
			int_t ivalue = *(int_t*)buddy;
			rvalue = (real_t)ivalue;
		} else
		if (dataType==LONGINT_T) {
			longint_t livalue = *(longint_t*)buddy;
			rvalue = (real_t)livalue;	
		} else
		if (dataType==REAL_T) {
			rvalue  = *(real_t*)buddy;
		} else {
			FatalError(__FILE__,__LINE__,"ReadValueFromBuddy");
		}
	}
	return rvalue;
}

uint8 IsTrue(void* buddy, DATATYPE dataType, real_t threshold)
{
	uint8 res = 0;
	
	if (buddy) {
		if (dataType==BOOL_T) {
			bool_t value = *(bool_t*)buddy;
			res = (value>(bool_t)threshold)?1:0;			
		} else
		if (dataType==INT_T) {
			int_t value = *(int_t*)buddy;
			res = (value>(int_t)threshold)?1:0;			
		} else
		if (dataType==LONGINT_T) {
			longint_t value = *(longint_t*)buddy;
			res = (value>(longint_t)threshold)?1:0;			
		} else
		if (dataType==REAL_T) {
			real_t value = *(real_t*)buddy;
			res = (value>(real_t)threshold)?1:0;			
		} else {
			FatalError(__FILE__,__LINE__,"IsTrue");
		}
	}
	return res;
}

/**
 * quarter of sinf table
 */
#include "sinf_table.c"
int _sincosf(float theta, float* S, float* C)
{
	int k;
	int N2 = N*2;
	int N3 = N*3;
	int N4 = N*4;
	float y;

	if (S==0||C==0) {
		return -1;
	}
	
	y = theta*N2divPIf;
	k = (int)y;
	while (k<0) {
		k += N4;
	}
	while (k>N4) {
		k -= N4;
	}

	if (k<=N) {
		*S = _sinf_table[k];
		*C = _sinf_table[N-k];
	} else
	if (k<=N2) {
		*S = _sinf_table[2*N-k];
		*C = -_sinf_table[k-N];
	} else
	if (k<=N3) {
		*S = -_sinf_table[k-2*N];
		*C = -_sinf_table[3*N-k];
	} else {
		*S = -_sinf_table[4*N-k];
		*C = _sinf_table[k-3*N];
	}
	return 0;
}

uint16 GetPanelWidth()
{
	PANEL* panel = GetActivePanel();
	
	return panel->width;
}

uint16 GetPanelHeight()
{
	PANEL* panel = GetActivePanel();
	
	return panel->height;
}

extern const font_t default_system_font;

uint16 FontHeight()
{
	return default_system_font.height;
}

uint16 StringWidth(const char* str)
{
	uint16 total_width = 0;
	
	if (str==0) {
		return 0;
	}
	while (*str) {
		int index = *str-default_system_font.first;
		uint8 width = default_system_font.width_table[index];
		total_width += width;
		str++;
	}
	return total_width;
}
