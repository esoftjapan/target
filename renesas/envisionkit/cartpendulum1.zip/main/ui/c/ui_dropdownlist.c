/**
 * ui_dropdownlist.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>
	
int Notify_dropdownlist(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	uint16 panelHeight,ytop;
	DROPDOWNLIST* dd = (DROPDOWNLIST*)me;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	panelHeight = GetPanelHeight();
	if (dd->base.bottom+dd->nitems*dd->itemheight<=panelHeight) {
		ytop = dd->base.bottom;
	} else {
		ytop = dd->base.top-dd->nitems*dd->itemheight;
	}
	
	if (type==NOTIFY_INIT) {
		real_t value;
		dd->selected = dd->init;
		
		value = dd->items[dd->selected].value;
		WriteValueToBuddy(dd->buddy,dd->dataType,value);
	} else	
	if (type==NOTIFY_PRESSED) {
		if (dd->expanding==0) {
			UIRECT rc;
			rc.left = dd->base.right-dd->itemheight;
			rc.right = dd->base.right;
			rc.top = dd->base.top;
			rc.bottom = dd->base.bottom;
			
			if (IsHitRect(&rc,x,y)) {
				dd->expanding = 1;
				dd->hilighted = dd->selected;
			}
		}
	} else
	if (type==NOTIFY_RELEASED) {
		UIRECT rc;
		rc.left = dd->base.left;
		rc.right = dd->base.right;
		rc.top = ytop;
		rc.bottom = ytop+dd->itemheight*dd->nitems;
		
		if (IsHitRect(&rc,x,y)) {
			real_t value;
			dd->expanding = 0;
			dd->hilighted = (y-rc.top)/dd->itemheight;
			dd->hilighted = max(0,min(dd->nitems-1,dd->hilighted));
			dd->selected = dd->hilighted;
			value = dd->items[dd->selected].value;
			WriteValueToBuddy(dd->buddy,dd->dataType,value);
		} else
		if (IsHit((CONTROL*)dd,x,y)) {
			/* don't close */
		} else {
			dd->expanding = 0;
		}
	} else
	if (type==NOTIFY_MOVE) {
		if (dd->expanding) {
			UIRECT rc;
			rc.left = dd->base.left;
			rc.right = dd->base.right;
			rc.top = ytop;
			rc.bottom = ytop+dd->itemheight*dd->nitems;
			if (IsHitRect(&rc,x,y)) {
				dd->hilighted = (y-rc.top)/dd->itemheight;
				dd->hilighted = max(0,min(dd->nitems-1,dd->hilighted));
			}
		}
	} else
	if (type==NOTIFY_UPDATE) {
		if (dd->base.visible) {
			uint16 x1,y1,x2,y2,x3,yoffset,dx,dy;
			point_t pt[3];
			
			x1 = dd->base.left;
			x2 = dd->base.right;			
			x3 = x2-dd->itemheight;
			y1 = dd->base.top;
			y2 = dd->base.bottom;

			/* triangle */
			dx = 6; dy = 7;
			pt[0].x = (x3+x2)/2;	pt[0].y = y2-dy;
			pt[1].x = x2-dx;		pt[1].y = y1+dy;
			pt[2].x = x3+dx;		pt[2].y = y1+dy;
			ui_draw_polygon(3,pt,dd->edgecolor,dd->bgcolor);
			
			/* dropdown list body */
			ui_draw_icon(dd->items[dd->selected].image,x1,y1);
			ui_draw_rectangle(x1,y1,x3,y2,BLACK);
			ui_draw_rectangle(x3,y1,x2,y2,BLACK);
			
			/* drwa dropdown list */
			if (dd->expanding) {
				uint16 i;
				
				for (i=0; i<dd->nitems; i++) {
					if (i!=dd->hilighted) {
						yoffset = ytop+dd->itemheight*i; //y2+dd->itemheight*i;
						ui_draw_icon(dd->items[i].image,x1,yoffset);
						ui_draw_rectangle(x1,yoffset,x2,yoffset+dd->itemheight,BLACK);
					}
				}
				
				/* hilighted item */
				i = dd->hilighted;
				yoffset = ytop+dd->itemheight*i; //y2+dd->itemheight*i;
				ui_draw_icon(dd->items[i].image,x1,yoffset);
				ui_draw_rectangle_linewidth(x1,yoffset,x2,yoffset+dd->itemheight,BLUE,2);
			}			
		}
	}
	return ecode;
}
