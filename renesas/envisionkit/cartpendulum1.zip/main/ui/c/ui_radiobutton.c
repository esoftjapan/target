/**
 * ui_radiobutton.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>
	
int Notify_radiobutton(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	RADIOBUTTON* rb = (RADIOBUTTON*)me;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	if (type==NOTIFY_INIT) {
		rb->status = rb->init;
		if (rb->status==0) {
			WriteValueToBuddy(rb->buddy,rb->dataType,rb->offvalue);
		} else {
			WriteValueToBuddy(rb->buddy,rb->dataType,rb->onvalue);
		}
	} else	
	if (type==NOTIFY_PRESSED) {
		if (IsHitEx((CONTROL*)rb,x,y,0,10)) {
			rb->status = 1;
			WriteValueToBuddy(rb->buddy,rb->dataType,rb->onvalue);
			
			/* force others to go off state */ 
			if (rb->link) {
				RADIOBUTTON* next = rb->link;
				while (next!=rb) {
					next->status = 0;
					WriteValueToBuddy(next->buddy,next->dataType,next->offvalue);
					next = next->link;
				}
			}
		}
	} else
	if (type==NOTIFY_RELEASED) {
	} else	
	if (type==NOTIFY_UPDATE) {
		if (rb->base.visible) {
			if (rb->style==0) {
				uint16 x1 = rb->base.left;
				uint16 y1 = rb->base.top;
				uint16 x2 = rb->base.right;
				uint16 y2 = rb->base.bottom;
				uint16 d = 2;
				uint16 douter = min(x2-x1,y2-y1);
				uint16 dinner = max(2,douter-d*2);
				uint16 fonthight = FontHeight();
				
				if (rb->status>0) {
					ui_draw_rectangle(x1,y1,x1+douter,y1+douter,BLACK);
					ui_draw_filled_rectangle(x1+d,y1+d,x1+d+dinner,y1+d+dinner,BLACK,BLACK);					
				} else {
					ui_draw_rectangle(x1,y1,x1+douter,y1+douter,BLACK);
				}
				ui_draw_text_transparent(rb->caption,x1+douter+5,(y1+y2-fonthight)/2,BLACK);
			} else {
				if (rb->status>0) {
					ui_draw_icon(rb->onimage,rb->base.left,rb->base.top);
				} else {
					ui_draw_icon(rb->offimage,rb->base.left,rb->base.top);
				}
			}
		}
	}
	return ecode;
}
