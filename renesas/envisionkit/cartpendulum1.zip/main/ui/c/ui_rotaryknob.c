/**
 * ui_rotaryknob.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <math.h>

#include <ui_vlx.h>
	
#define	PIf			(3.1415926535897932384626433832795f)
#define	PI2f		(6.283185307179586476925286766559f)
#define	PIfdiv2		(1.5707963267948966192313216916398f)
#define	PI3fdiv2	(4.7123889803846898576939650749193f)
#define	invPI2f		(0.15915494309189533576888376337251f)

static float CalcAngle(float dx, float dy)
{
	float angle;
	
	if (dx>=0 && dy<=0) {
		angle = PIfdiv2-atan2f(-dy,dx);
	} else
	if (dx>=0 && dy>0) {
		angle = PIfdiv2+atan2f(dy,dx);
	} else
	if (dx<0 && dy>0) {
		angle = PI3fdiv2-atan2f(dy,-dx);
	} else {
		angle = PI3fdiv2+atan2f(-dy,-dx);
	}
	return angle;
}

int Notify_rotaryknob(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	ROTARYKNOB* rk = (ROTARYKNOB*)me;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;
	
	if (type==NOTIFY_INIT) {
		WriteValueToBuddy(rk->buddy,rk->dataType,rk->init);
	} else	
	if (type==NOTIFY_PRESSED) {
		if (IsHit((CONTROL*)rk,x,y)) {
			real_t value,dx,dy,angle;
			
			dx = (real_t)(x-rk->xc);
			dy = (real_t)(y-rk->yc);
			angle = (float)CalcAngle((float)dx,(float)dy);
			if (angle-rk->angle<-PIf) {
				rk->nrotate++;
			} else
			if (angle-rk->angle>PIf) {
				rk->nrotate--;
			}
			rk->angle = angle;
			value = rk->angle*rk->inc*invPI2f+rk->nrotate*rk->inc;
			rk->value = min(rk->vmax,max(value,rk->vmin));
			WriteValueToBuddy(rk->buddy,rk->dataType,rk->value);
		}
	} else
	if (type==NOTIFY_RELEASED) {
	} else
	if (type==NOTIFY_MOVE) {
		if ((uii->status&UI_TOUCH) && IsHit((CONTROL*)rk,x,y)) {
			real_t value,dx,dy,angle;
			
			dx = (real_t)(x-rk->xc);
			dy = (real_t)(y-rk->yc);
			angle = (float)CalcAngle((float)dx,(float)dy);
			if (angle-rk->angle<-PIf) {
				rk->nrotate++;
			} else
			if (angle-rk->angle>PIf) {
				rk->nrotate--;
			}
			rk->angle = angle;
			value = rk->angle*rk->inc*invPI2f+rk->nrotate*rk->inc;
			rk->value = min(rk->vmax,max(value,rk->vmin));
			WriteValueToBuddy(rk->buddy,rk->dataType,rk->value);
		}
	} else	
	if (type==NOTIFY_UPDATE) {
		if (rk->base.visible) {
			int16 xknob,yknob,count=0;
						
			ui_draw_filled_circle(rk->xc,rk->yc,rk->rOuter,rk->outercolor,rk->outercolor);

			xknob = (int16)(rk->xc+rk->rInner*sinf(rk->angle));
			yknob = (int16)(rk->yc-rk->rInner*cosf(rk->angle));
			ui_draw_filled_circle(xknob,yknob,rk->rknob,rk->knobcolor,rk->knobcolor);
			
			/* text out of buddy */
			if (rk->buddy) {
				if (rk->dataType==BOOL_T||rk->dataType==INT_T||rk->dataType==LONGINT_T) {
					int_t ivalue = *(int_t*)rk->buddy;
					rk->value = (real_t)ivalue;
					count = i2s(ivalue,rk->text,sizeof(rk->text),0);
				} else {
					qreal q;
					rk->value = *(real_t*)rk->buddy;
					q = ConvR2Q(rk->value);
					count = q2s(q,rk->text,sizeof(rk->text)-2-rk->accuracy,rk->accuracy,0);
				}
			}
			x = (rk->base.left+rk->base.right-count*6)/2;
			y = (rk->base.top+rk->base.bottom)/2-10;
			ui_draw_text_transparent(rk->text,x,y,rk->textcolor);
		}
	}
	return ecode;
}
