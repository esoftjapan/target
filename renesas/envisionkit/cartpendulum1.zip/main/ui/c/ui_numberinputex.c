/**
 *
 * ui_numberinputex.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * --------------------------------------------------------------------------------------------
 *	2018/06/01		YT				created
 *
 */
 
#include <ui_vlx.h>

int Notify_numberinputex(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	NUMBERINPUTEX* ni = (NUMBERINPUTEX*)me;
	NUMBERDISPLAY* disp = ni->numberdisplay;
	TENKEY* tk = ni->tenkey;
		
	/* numberdisplay */
	Notify_numberdisplay(type,(CONTROL*)disp,param1,param2);
	
	/* tenkey */
	if (tk->base.visible) {
		Notify_tenkey(type,(CONTROL*)tk,param1,param2);
	}
	
	if (type==NOTIFY_INIT) {
		Notify_tenkey(type,(CONTROL*)tk,param1,param2);		
	} else
	if (type==NOTIFY_PRESSED) {
		UIINPUT* uii = (UIINPUT*)param1;
		uint16 x = uii?uii->x:0;
		uint16 y = uii?uii->y:0;
		if (IsHit((CONTROL*)ni,x,y)) {
			/* popup tenkey */
			tk->base.visible = 1;
		}
	} else
	if (type==NOTIFY_ACTION) {
		CONTROL* tk = (CONTROL*)param1;
		if (tk==(CONTROL*)ni->tenkey) {
			char *str = (char*)param2;
			real_t value = ConvS2R(str);
			WriteValueToBuddy(ni->numberdisplay->buddy,ni->numberdisplay->dataType,value);
		}
	} else
	if (type==NOTIFY_UPDATE) {
		/* the internal numberdisplay displays */
	}
	return ecode;
}
