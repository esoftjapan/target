/**
 * ui_label.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>
	
int Notify_label(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	LABEL* l = (LABEL*)me;

	if (type==NOTIFY_UPDATE) {
		if (l->base.visible) {
			ui_draw_icon(l->tga,l->base.left,l->base.top);
		}
	}
	return ecode;
}
