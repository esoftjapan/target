/**
 * ui_graphics.c
 *
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */
 
#include "target_config.h"
#include <ui_vlx.h>
#include <string.h>

extern const font_t default_system_font;

static uint8 _transparent_enable = 1;
static color_t _transparent_color = RGBCOLOR(0xff,0xff,0xff);

uint16 LIMITWIDTH(uint16 x)
{
#if NUMPANELS>0
	if (x>=32768) {
		x = 0;
	} else
	if (x>PANEL_WIDTH) {
		x = PANEL_WIDTH;
	}
#endif
	return x;
}

uint16 LIMITHEIGHT(uint16 y)
{
#if NUMPANELS>0
	if (y>=32768) {
		y = 0;
	} else
	if (y>PANEL_HEIGHT) {
		y = PANEL_HEIGHT;
	}
#endif
	return y;
}

void ui_set_transparent(uint8 enable, color_t color)
{
	_transparent_enable = enable;
	_transparent_color = color;
}

uint8 ui_get_transparent_enable()
{
	return _transparent_enable;
}

color_t ui_get_transparent_color()
{
	return _transparent_color;
}

void ui_draw_icon(const uint8 *p, uint16 xoffset, uint16 yoffset)
{
	TGAHEADER* tga = (TGAHEADER*)p;
	uint16 colourmaplength = tga->colourmaplength;
	
	if (colourmaplength==2) {
		ui_draw_icon_2(p,xoffset,yoffset);
	} else
	if (colourmaplength==16) {
		ui_draw_icon_16(p,xoffset,yoffset);
	} else
	if (colourmaplength==256) {
		ui_draw_icon_256(p,xoffset,yoffset);
	} else {
		//error
		FatalError(__FILE__,__LINE__,"ui_draw_icon:unknown color map length");
	}
}

/**
 * draw TGA format bitmap imag with 256 colors
 */
void ui_draw_icon_256(const uint8 *p, uint16 xoffset, uint16 yoffset)
{
	const uint8 *pixels;
	const uint8 *palette;
	uint16 y;
	uint16 width;
	uint16 height;
	uint16 ncolors;

	width = *((uint16 *)(p + 12));
	height = *((uint16 *)(p + 14));
	ncolors = p[6]*256+p[5];
	if (ncolors!=256) {
		FatalError(__FILE__,__LINE__,"ui_draw_icon_256");
		return;
	}

	palette = p+18;
	pixels = p+18+ncolors*sizeof(color_t);

    for (y=0; y<height; y++) {
		const uint8 *raster = &pixels[y*width];
		ui_raster_indexed_color(xoffset,yoffset+y,raster,(color_t*)palette,width);
	}
}

/**
 * draw TGA format bitmap imag with 16 colors
 */
void ui_draw_icon_16(const uint8 *p, uint16 xoffset, uint16 yoffset)
{
	const uint8 *pixels;
	const color_t *palette;
	uint16 x,y,width,height,ncolors,width_byte;
	uint16 i,j,k;
	uint8 byte,nibble;
	color_t* q;
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 fb_width = ui_get_framebuffer_width();

	width = *((uint16 *)(p + 12));
	height = *((uint16 *)(p + 14));
	ncolors = p[6]*256+p[5];
	if (ncolors!=16) {
		FatalError(__FILE__,__LINE__,"ui_draw_icon_16");
		return;
	}

	palette = (color_t*)(p+18);
	pixels = p+18+ncolors*sizeof(color_t);

	width_byte = (width*4+7)/8;
    for (y=0; y<height; y++) {
		for (x=0; x<width; x++) {
			i = x/2;
			j = x%2;
			k = y*width_byte+i;
			byte = pixels[k];
			if (j==0) {
				nibble = (byte&0xf0)>>4;
			} else {
				nibble = byte&0x0f;
			}

			q = fb+(y+yoffset)*fb_width+(x+xoffset);
			ui_draw_pixel(q,palette[nibble]);
		}
	}
}

/**
 * draw TGA format bitmap imag with mono chro
 */
void ui_draw_icon_2(const uint8 *p, uint16 xoffset, uint16 yoffset)
{
	const uint8 *pixels;
	const color_t *palette;
	uint8 bit,byte;
	uint16 x,y,width,height,ncolors;
	uint16 i,j,k,width_byte;
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 fb_width = ui_get_framebuffer_width();
	color_t* q;

	width = *((uint16 *)(p + 12));
	height = *((uint16 *)(p + 14));
	ncolors = p[6]*256+p[5];
	if (ncolors!=2) {
		FatalError(__FILE__,__LINE__,"ui_draw_icon_2");
		return;
	}

	palette = (color_t*)(p+18);
	pixels = p+18+ncolors*sizeof(color_t);

	width_byte = (width+7)/8;
    for (y=0; y<height; y++) {
		for (x=0; x<width; x++) {
			i = x/8;
			j = x%8;
			k = y*width_byte+i;
			byte = pixels[k];
			bit = byte&(1<<(7-j));

			q = fb+(y+yoffset)*fb_width+(x+xoffset);
			ui_draw_pixel(q,palette[bit>0?1:0]);
		}
	}
}

void ui_raster_indexed_color(uint16 x, uint16 y, const uint8* pixels, color_t* palette, uint16 npixels)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	color_t* p = fb+y*width+x;

	while (npixels--) {
		ui_draw_pixel(p++,palette[*(pixels++)]);
	}
}

void ui_draw_text(const char *text, uint16 x, uint16 y, color_t fgcolor, color_t bgcolor)
{
	uint16 i,xorg;
	const font_t* font = &default_system_font;

	xorg = x;
	i = 0;
	while (text[i] != '\0') {
		if (text[i] == '\n') {
			y += font->height;
			x = xorg;
		} else
		if ((text[i] >= font->first) && (text[i] <= font->last)) {
			uint16 width = ui_put_char(text[i],x,y,fgcolor,bgcolor);
			x += width;
		}
		i++;
	}
}

void ui_draw_text_transparent(const char *text, uint16 x, uint16 y, color_t fgcolor)
{
	uint16 i,xorg;
	const font_t* font = &default_system_font;

	xorg = x;
	i = 0;
	while (text[i] != '\0') {
		if (text[i] == '\n') {
			y += font->height;
			x = xorg;
		} else
		if ((text[i] >= font->first) && (text[i] <= font->last)) {
			uint16 width = ui_put_char_transparent(text[i],x,y,fgcolor);
			x += width;
		}
		i++;
	}
}

uint16 ui_put_char(const char textchar, uint16 x, uint16 y, color_t fgcolor, color_t bgcolor)
{
	uint16 i,j,index,width,height,line,bit;
	const uint16* chardata;
	const font_t* font = &default_system_font;

	height = font->height;

	index = textchar-font->first;
	chardata = font->table+(index*height);
	width = font->width_table[index];

	for (i=0; i<height; i++) {
		line = chardata[i];
		bit = 0x8000;
		for (j=0; j<width; j++) {
			if (line&bit) {
				ui_put_pixel(fgcolor,x+j,y+i);
			} else {
				ui_put_pixel(bgcolor,x+j,y+i);
			}
			bit >>= 1;
		}
	}
	return width;
}

uint16 ui_put_char_transparent(const char textchar, uint16 x, uint16 y, color_t fgcolor)
{
	uint16 i,j,index,width,height,line,bit;
	const uint16* chardata;
	const font_t* font = &default_system_font;

	height = font->height;

	index = textchar-font->first;
	chardata = font->table+(index*height);
	width = font->width_table[index];

	for (i=0; i<height; i++) {
		line = chardata[i];
		bit = 0x8000;
		for (j=0; j<width; j++) {
			if (line&bit) {
				ui_put_pixel(fgcolor,x+j,y+i);
			}
			bit >>= 1;
		}
	}
	return width;
}

void ui_put_pixel(color_t color, uint16 x, uint16 y)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	color_t* p = fb+LIMITHEIGHT(y)*width+LIMITWIDTH(x);

	ui_draw_pixel(p,color);
}

color_t ui_get_pixel(uint16 x, uint16 y)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	color_t* p = fb+y*width+x;
	
	color_t color = ui_get_pixel_color(p);
	return color;
}

void ui_draw_filled_rectangle(uint16 x1, uint16 y1, uint16 x2, uint16 y2, color_t bgcolor, color_t edgecolor)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	uint16 x,y;

	if (x1>x2) {
		uint16 z = x2;
		x2 = x1;
		x1 = z;
	}
	if (y1>y2) {
		uint16 z = y2;
		y2 = y1;
		y1 = z;
	}

	for (y=y1; y<=y2; y++) {
		color_t* p = fb+y*width+x1;
		for (x=x1; x<=x2; x++) {
			ui_draw_pixel(p++,bgcolor);
		}
	}
	ui_draw_rectangle(x1,y1,x2,y2,edgecolor);
}

/**
 * draw pixels directly on a frame buffer
 */
int ui_is_using_framebuffer(void)
{
	return (ui_get_hidden_framebuffer()!=0?1:0);
}

void ui_draw_filled_rectangle_direct(uint16 x1, uint16 y1, uint16 x2, uint16 y2, uint8 bgcolor, color_t edgecolor)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	uint16 y;
	int count;

	if (x1>x2) {
		uint16 z = x2;
		x2 = x1;
		x1 = z;
	}
	if (y1>y2) {
		uint16 z = y2;
		y2 = y1;
		y1 = z;
	}

	/* draw pixels on the frame buffer */ 
	count = (x2-x1+1)*sizeof(color_t);
	for (y=y1; y<=y2; y++) {
		color_t* p = fb+y*width+x1;
		memset(p,0xff,count);
	}
	ui_draw_rectangle(x1,y1,x2,y2,edgecolor);
}

void ui_draw_rectangle(uint16 x1, uint16 y1, uint16 x2, uint16 y2, color_t edgecolor)
{
	ui_draw_horizontal_line(x1,x2,y1,edgecolor);
	ui_draw_horizontal_line(x1,x2,y2,edgecolor);
	ui_draw_vertical_line(x1,y1,y2,edgecolor);
	ui_draw_vertical_line(x2,y1,y2,edgecolor);
}

void ui_draw_rectangle_linewidth(uint16 x1, uint16 y1, uint16 x2, uint16 y2, color_t edgecolor, uint16 linewidth)
{
	ui_draw_horizontal_line_linewidth(x1,x2,y1,linewidth,edgecolor);
	ui_draw_horizontal_line_linewidth(x1,x2,y2,linewidth,edgecolor);
	ui_draw_vertical_line_linewidth(x1,y1,y2,linewidth,edgecolor);
	ui_draw_vertical_line_linewidth(x2,y1,y2,linewidth,edgecolor);
}

void ui_draw_3D_rectangle(uint16 x1, uint16 y1, uint16 x2, uint16 y2)
{
	ui_draw_horizontal_line(x1,x2,y1,BLACK);
	ui_draw_horizontal_line(x1,x2,y2,BLACK);
	ui_draw_vertical_line(x1,y1,y2,BLACK);
	ui_draw_vertical_line(x2,y1,y2,BLACK);
}

/* Bresenham's algorithm */
void ui_draw_line(uint16 x1, uint16 y1, uint16 x2, uint16 y2, color_t color)
{
	qreal dx,dy,err,e2;
	uint16 sx,sy,x,y;
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	
	x1 = LIMITWIDTH(x1);
	x2 = LIMITWIDTH(x2);
	y1 = LIMITHEIGHT(y1);
	y2 = LIMITHEIGHT(y2);
	
	if (x2>x1) {
		dx = i2q(x2-x1);
		sx = 1;
	} else {
		dx = i2q(x1-x2);
		sx = -1;
	}
	if (y2>y1) {
		dy = i2q(y2-y1);
		sy = 1;
	} else {
		dy = i2q(y1-y2);
		sy = -1;
	}
	err = dx-dy;

	x = x1;
	y = y1;
	
	while (1) {
		color_t* p = fb+y*width+x;
		ui_draw_pixel(p,color);
	
		if ((x==x2) && (y==y2)) {
			break;
		}
			
		e2 = 2*err;
		if (e2>-dy) { 
			err -= dy;
			x += sx;
		}
		if (e2<dx) { 
			err += dx;
			y += sy;
		}
	}
}

void ui_draw_horizontal_line(uint16 x1, uint16 x2, uint16 y, color_t color)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	uint16 x;
	color_t* p;
	
	x1 = LIMITWIDTH(x1);
	x2 = LIMITWIDTH(x2);
	y = LIMITHEIGHT(y);

	if (x1>x2) {
		uint16 z = x2;
		x2 = x1;
		x1 = z;
	}
	
	p = fb+y*width+x1;
	for (x=x1; x<=x2; x++) {
		ui_draw_pixel(p++,color);
	}
}

void ui_draw_horizontal_line_linewidth(uint16 x1, uint16 x2, uint16 y, uint16 linewidth, color_t color)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	uint16 height = ui_get_framebuffer_height();
	uint16 x;

	x1 = LIMITWIDTH(x1);
	x2 = LIMITWIDTH(x2);
	y = LIMITHEIGHT(y);

	if (x1>x2) {
		uint16 z = x2;
		x2 = x1;
		x1 = z;
	}

	if (linewidth<2) {
		color_t* p = fb+y*width+x1;
		
		for (x=x1; x<=x2; x++) {
			ui_draw_pixel(p++,color);
		}
	} else
	if (linewidth==2) {
		uint16 y1 = min(y+1,height);
		color_t* p = fb+y*width+x1;
		color_t* p1 = fb+y1*width+x1;
		
		for (x=x1; x<=x2; x++) {
			ui_draw_pixel(p++,color);
			ui_draw_pixel(p1++,color);
		}
	} else {
		uint16 y1 = max(y-1,0);
		uint16 y2 = min(y+1,height);
		color_t* p = fb+y*width+x1;
		color_t* p1 = fb+y1*width+x1;
		color_t* p2 = fb+y2*width+x1;
		
		for (x=x1; x<=x2; x++) {
			ui_draw_pixel(p++,color);
			ui_draw_pixel(p1++,color);
			ui_draw_pixel(p2++,color);
		}
	}
}

void ui_draw_vertical_line(uint16 x, uint16 y1, uint16 y2, color_t color)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	uint16 y;
	color_t* p;
	
	x = LIMITWIDTH(x);
	y1 = LIMITHEIGHT(y1);
	y2 = LIMITHEIGHT(y2);

	if (y1>y2) {
		uint16 z = y2;
		y2 = y1;
		y1 = z;
	}
	
	p = fb+y1*width+x;
	for (y=y1; y<=y2; y++) {
		ui_draw_pixel(p,color);
		p += width;
	}
}

void ui_draw_vertical_line_linewidth(uint16 x, uint16 y1, uint16 y2, uint16 linewidth, color_t color)
{
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 width = ui_get_framebuffer_width();
	uint16 y;
	
	x = LIMITWIDTH(x);
	y1 = LIMITHEIGHT(y1);
	y2 = LIMITHEIGHT(y2);

	if (y1>y2) {
		uint16 z = y2;
		y2 = y1;
		y1 = z;
	}
		
	if (linewidth<2) {
		color_t* p = fb+y1*width+x;
		
		for (y=y1; y<=y2; y++) {
			ui_draw_pixel(p,color);
			p += width;
		}
	} else
	if (linewidth==2) {
		uint16 x1 = min(x+1,width);
		color_t* p = fb+y1*width+x;
		color_t* p1 = fb+y1*width+x1;
		
		for (y=y1; y<=y2; y++) {
			ui_draw_pixel(p,color);
			ui_draw_pixel(p1,color);
			p += width;
			p1 += width;
		}
	} else {
		uint16 x1 = min(x+1,width);
		uint16 x2 = max(x-1,0);
		color_t* p = fb+y1*width+x;
		color_t* p1 = fb+y1*width+x1;
		color_t* p2 = fb+y1*width+x2;
		
		for (y=y1; y<=y2; y++) {
			ui_draw_pixel(p,color);
			ui_draw_pixel(p1,color);
			ui_draw_pixel(p2,color);
			p += width;
			p1 += width;
			p2 += width;
		}
	}
}

void ui_draw_polyline(uint16 count, point_t* pt, color_t edgecolor)
{
	uint16 i;
	
	for (i=0; i<count; i++) {
		int j = i+1;
		if (j==count) {
			j = 0;
		}
		ui_draw_line(pt[i].x,pt[i].y,pt[j].x,pt[j].y,edgecolor);
	}
}

/**
 * points are ordered counter-clockwise
 */
void ui_draw_polygon(uint16 count, point_t* pt, color_t edgecolor, color_t bgcolor)
{
	uint16 i,j;
	uint16 x,y,xmin,xmax,ymin,ymax;
	qreal x1,y1,x2,y2,qx,qy;
	qreal dx,dy,a,b,c,f;
		
	xmin = ymin = 4096;
	xmax = ymax = 0;
	for (i=0; i<count; i++) {
		if (pt[i].x<xmin) {
			xmin = pt[i].x; 
		}
		if (pt[i].y<ymin) {
			ymin = pt[i].y; 
		}
		if (pt[i].x>xmax) {
			xmax = pt[i].x; 
		}
		if (pt[i].y>ymax) {
			ymax = pt[i].y; 
		}
	}
	
	for (y=ymin; y<=ymax; y++) {
		for (x=xmin; x<=xmax; x++) {
			uint8 inside = 1;
			for (i=0; i<count; i++) {
				j = i+1;
				if (j==count) {
					j = 0;
				}
				/* f(x,y)=ax+by+c=0 */
				qx = i2q(x);
				qy = i2q(y);
				x1 = i2q(pt[i].x);
				y1 = i2q(pt[i].y);
				x2 = i2q(pt[j].x);
				y2 = i2q(pt[j].y);
				dx = x2-x1;
				dy = y2-y1;
				a = -dy;
				b = dx;
				c = qmul(x1,dy)-qmul(y1,dx);
				f = qmul(a,qx)+qmul(b,qy)+c;
				if (f>0) {
					/**
					 * CAUTION: positive y-direction in the screen coordinate is downward.
					 */
					inside = 0;
					break;
				}
			}
			if (inside) {
				ui_put_pixel(bgcolor,x,y);
			}
		}
	}
	
	/* draw edge */
	ui_draw_polyline(count,pt,edgecolor);	
}

/**
 * Bresenham's algorithm
 */
void ui_draw_cirle(uint16 xc, uint16 yc, uint16 r, color_t color)
{
	int16 x,y,d;
	
	x = 0;
	y = r;
	ui_put_pixel(color,xc,yc+y);
	ui_put_pixel(color,xc,yc-y);
	d = (3-2*r);

	while (x<=y) {
		if (d<=0) {
			d += (4*x+6);
		} else {
			d += 4*(x-y)+10; 
			y--; 
		}
		x++;
		ui_put_pixel(color,xc+x,yc+y);
		ui_put_pixel(color,xc-x,yc+y);
		ui_put_pixel(color,xc+x,yc-y);
		ui_put_pixel(color,xc-x,yc-y);
		ui_put_pixel(color,xc+y,yc+x);
		ui_put_pixel(color,xc-y,yc+x);
		ui_put_pixel(color,xc+y,yc-x);
		ui_put_pixel(color,xc-y,yc-x);
	}
}

void ui_draw_filled_circle(uint16 xc, uint16 yc, uint16 r, color_t bgcolor, color_t edgecolor)
{
	int16 x,y,d;
	
	x = 0;
	y = r;

	ui_draw_horizontal_line(xc-r,xc+r,yc,bgcolor);
	
	d = (3-2*r);

	while (x<=y) {
		if (d<=0) {
			d += (4*x+6);
		} else {
			d += 4*(x-y)+10; 
			y--; 
		}
		x++;

		ui_draw_horizontal_line(xc-x,xc+x,yc+y,bgcolor);
		ui_draw_horizontal_line(xc-x,xc+x,yc-y,bgcolor);
		ui_draw_horizontal_line(xc-y,xc+y,yc+x,bgcolor);
		ui_draw_horizontal_line(xc-y,xc+y,yc-x,bgcolor);
	}
	
	if (bgcolor!=edgecolor) {
		ui_draw_cirle(xc,yc,r,edgecolor);
	}
}

/**
 * Rotating an image
 * There are many holes in the rotated image by the simple algorithm.
 * This is an improved version.
 * [Inverse Rotation Method]
 * (1)find region of rotated image
 * (2)scan the rotated region to find original point
 */

static void RotatePoint(int16* px, int16* py, int16 x, int16 y, int16 xpivot, int16 ypivot, real_t angle);
static void FindMinMaxOfRotatedImage(UIRECT* rc, uint16 width, uint16 height, int16 xpivot, int16 ypivot, real_t angle);

void ui_draw_icon_with_rotate(const uint8 *p, uint16 xoffset, uint16 yoffset, int16 xpivot, int16 ypivot, real_t angle)
{
	TGAHEADER* tga = (TGAHEADER*)p;
	uint16 colourmaplength = tga->colourmaplength;
	
	if (colourmaplength==2) {
		ui_draw_icon_with_rotate_2(p,xoffset,yoffset,xpivot,ypivot,angle);
	} else
	if (colourmaplength==16) {
		ui_draw_icon_with_rotate_16(p,xoffset,yoffset,xpivot,ypivot,angle);
	} else
	if (colourmaplength==256) {
		ui_draw_icon_with_rotate_256(p,xoffset,yoffset,xpivot,ypivot,angle);
	} else {
		//error
		FatalError(__FILE__,__LINE__,"ui_draw_icon_with_rotate:unknown color map length");
	}
}

void ui_draw_icon_with_rotate_256(const uint8 *p, uint16 xoffset, uint16 yoffset, int16 xpivot, int16 ypivot, real_t angle)
{
	const uint8 *pixels;
	const color_t *palette;
	UIRECT rc;
	int16 x,y,xmin,ymin,xmax,ymax;
	uint16 width,height,ncolors;
	color_t* q;
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 fb_width = ui_get_framebuffer_width();

	width = *((uint16 *)(p + 12));
	height = *((uint16 *)(p + 14));
	ncolors = p[6]*256+p[5];
	if (ncolors!=256) {
		FatalError(__FILE__,__LINE__,"ui_draw_icon_256");
		return;
	}

	palette = (color_t*)(p+18);
	pixels = p+18+ncolors*sizeof(color_t);

	/* find region of rotated image */
	FindMinMaxOfRotatedImage(&rc,width,height,xpivot,ypivot,angle);
	xmin = rc.left; ymin = rc.top;
	xmax = rc.right; ymax = rc.bottom;
	
    for (y=ymin; y<=ymax; y++) {
		for (x=xmin; x<=xmax; x++) {
			int16 px,py;
			uint16 k;
			uint8 index;
			color_t color;
			
			/* inverse rotate : (x,y) <= rotated from (px,py) */
			RotatePoint(&px,&py,x,y,xpivot,ypivot,-angle);
			if (!(px>=0 && px<width && py>=0 && py<height)) {
				continue;
			}
			k = py*width+px;
			index = pixels[k];
			color = palette[index];

			if (_transparent_enable && color==_transparent_color) {
				continue;
			}
			
			q = fb+(y+yoffset)*fb_width+(x+xoffset);
			ui_draw_pixel(q,color);
		}
	}
}

/**
 * draw TGA format bitmap imag with 16 colors
 */
void ui_draw_icon_with_rotate_16(const uint8 *p, uint16 xoffset, uint16 yoffset, int16 xpivot, int16 ypivot, real_t angle)
{
	const uint8 *pixels;
	const color_t *palette;
	uint16 width,height,ncolors,width_byte;
	uint16 i,j,k;
	uint8 byte,nibble;
	int16 x,y,px,py,xmin,ymin,xmax,ymax;
	UIRECT rc;
	color_t color;
	color_t* q;
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 fb_width = ui_get_framebuffer_width();

	width = *((uint16 *)(p + 12));
	height = *((uint16 *)(p + 14));
	ncolors = p[6]*256+p[5];
	if (ncolors!=16) {
		FatalError(__FILE__,__LINE__,"ui_draw_icon_16");
		return;
	}

	palette = (color_t*)(p+18);
	pixels = p+18+ncolors*sizeof(color_t);

	/* find region of rotated image */
	FindMinMaxOfRotatedImage(&rc,width,height,xpivot,ypivot,angle);
	xmin = rc.left; ymin = rc.top;
	xmax = rc.right; ymax = rc.bottom;
	
	width_byte = (width*4+7)/8;
    for (y=ymin; y<=ymax; y++) {
		for (x=xmin; x<=xmax; x++) {
		
			/* inverse rotate : (x,y) <= rotated from (px,py) */
			RotatePoint(&px,&py,x,y,xpivot,ypivot,-angle);
			if (!(px>=0 && px<width && py>=0 && py<height)) {
				continue;
			}
		
			i = px/2;
			j = px%2;
			k = py*width_byte+i;
			byte = pixels[k];
			if (j==0) {
				nibble = (byte&0xf0)>>4;
			} else {
				nibble = byte&0x0f;
			}

			color = palette[nibble];
			if (_transparent_enable && color==_transparent_color) {
				continue;
			}
		
			q = fb+(y+yoffset)*fb_width+(x+xoffset);
			ui_draw_pixel(q,color);
		}
	}
}

/**
 * draw TGA format bitmap imag with mono chro
 */
void ui_draw_icon_with_rotate_2(const uint8 *p, uint16 xoffset, uint16 yoffset, int16 xpivot, int16 ypivot, real_t angle)
{
	const uint8 *pixels;
	const color_t *palette;
	color_t color;
	uint8 bit,byte;
	uint16 width,height,ncolors;
	uint16 i,j,k,width_byte;
	int16 x,y,px,py,xmin,ymin,xmax,ymax;
	UIRECT rc;
	color_t* fb = ui_get_hidden_framebuffer();
	uint16 fb_width = ui_get_framebuffer_width();
	color_t* q;

	width = *((uint16 *)(p + 12));
	height = *((uint16 *)(p + 14));
	ncolors = p[6]*256+p[5];
	if (ncolors!=2) {
		FatalError(__FILE__,__LINE__,"ui_draw_icon_2");
		return;
	}

	palette = (color_t*)(p+18);
	pixels = p+18+ncolors*sizeof(color_t);

	/* find region of rotated image */
	FindMinMaxOfRotatedImage(&rc,width,height,xpivot,ypivot,angle);
	xmin = rc.left; ymin = rc.top;
	xmax = rc.right; ymax = rc.bottom;
	
	width_byte = (width+7)/8;
    for (y=ymin; y<=ymax; y++) {
		for (x=xmin; x<=xmax; x++) {
		
			/* inverse rotate : (x,y) <= rotated from (px,py) */
			RotatePoint(&px,&py,x,y,xpivot,ypivot,-angle);
			if (!(px>=0 && px<width && py>=0 && py<height)) {
				continue;
			}
		
			i = px/8;
			j = px%8;
			k = py*width_byte+i;
			byte = pixels[k];
			bit = byte&(1<<(7-j));

			color = palette[bit>0?1:0];
			if (_transparent_enable && color==_transparent_color) {
				continue;
			}
			
			q = fb+(y+yoffset)*fb_width+(x+xoffset);
			ui_draw_pixel(q,color);
		}
	}
}

void RotatePoint(int16* px, int16* py, int16 x, int16 y, int16 xpivot, int16 ypivot, real_t angle)
{
	float S,C;
	float rx,ry;

	rx = (float)(x-xpivot);
	ry = (float)(y-ypivot);
	
	_sincosf((float)angle,&S,&C);
	*px = (int16)(rx*C-ry*S)+xpivot;
	*py = (int16)(ry*C+rx*S)+ypivot;
}

void FindMinMaxOfRotatedImage(UIRECT* rc, uint16 width, uint16 height, int16 xpivot, int16 ypivot, real_t angle)
{
	int16 x1,y1,xmin,xmax,ymin,ymax;
	
	xmin = 32767; xmax = -32767;
	ymin = 32767; ymax = -32767;

	RotatePoint(&x1,&y1,0,0,xpivot,ypivot,angle);
	if (x1<xmin) {
		xmin = x1;
	}
	if (x1>xmax) {
		xmax = x1;
	}
	if (y1<ymin) {
		ymin = y1;
	}
	if (y1>ymax) {
		ymax = y1;
	}
	RotatePoint(&x1,&y1,width,0,xpivot,ypivot,angle);
	if (x1<xmin) {
		xmin = x1;
	}
	if (x1>xmax) {
		xmax = x1;
	}
	if (y1<ymin) {
		ymin = y1;
	}
	if (y1>ymax) {
		ymax = y1;
	}
	
	RotatePoint(&x1,&y1,0,height,xpivot,ypivot,angle);
	if (x1<xmin) {
		xmin = x1;
	}
	if (x1>xmax) {
		xmax = x1;
	}
	if (y1<ymin) {
		ymin = y1;
	}
	if (y1>ymax) {
		ymax = y1;
	}
	
	RotatePoint(&x1,&y1,width,height,xpivot,ypivot,angle);
	if (x1<xmin) {
		xmin = x1;
	}
	if (x1>xmax) {
		xmax = x1;
	}
	if (y1<ymin) {
		ymin = y1;
	}
	if (y1>ymax) {
		ymax = y1;
	}
	rc->left = xmin;
	rc->top = ymin;
	rc->right = xmax;
	rc->bottom = ymax;
}

void ui_plot_trace(uint16 plotsize, uint16 x1, uint16 x2, uint16 y1, uint16 y2, real_t xmin, real_t xmax, real_t ymin, real_t ymax, real_t* xbuf, real_t* ybuf, real_t sf, color_t color)
{
	uint16 k,ix1,ix2,iy1,iy2,width;
	real_t x,y,xslope,yslope;
	color_t *fb;
	
	fb = ui_get_hidden_framebuffer();
	width = ui_get_framebuffer_width();
	xslope = (x2-x1)/(xmax-xmin);
	yslope = (y1-y2)/((ymax-ymin)*sf);
	
	if (plotsize>=width) {
		/* using vertical line */ 
		y = ybuf[0];
		iy1 = (uint16)((y-ymin*sf)*yslope+y2);
		for (k=1; k<plotsize; k++) {
			x = xbuf[k];
			y = ybuf[k];
			ix2 = (uint16)((x-xmin)*xslope+x1);
			iy2 = (uint16)((y-ymin*sf)*yslope+y2);

			ui_draw_vertical_line(ix2,iy1,iy2,color);
			iy1 = iy2;
		}
	} else {
		y = ybuf[0];
		ix1 = x1;
		iy1 = (uint16)((y-ymin*sf)*yslope+y2);
		for (k=1; k<plotsize; k++) {
			x = xbuf[k];
			y = ybuf[k];
			ix2 = (uint16)((x-xmin)*xslope+x1);
			iy2 = (uint16)((y-ymin*sf)*yslope+y2);

			ui_draw_line(ix1,iy1,ix2,iy2,color);
			ix1 = ix2;
			iy1 = iy2;
		}
	}
}