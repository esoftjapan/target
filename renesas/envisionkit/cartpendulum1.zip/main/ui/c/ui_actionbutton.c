/**
 * ui_actionbutton.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>

extern int _active_panel;
extern int _previous_panel;

int Notify_actionbutton(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	ACTIONBUTTON* b = (ACTIONBUTTON*)me;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	if (type==NOTIFY_PRESSED) {
		if (IsHit((CONTROL*)b,x,y)) {
			if (b->status==0) {
				b->status = 1;
				InvalidateDisplay();
			}
		}
	} else
	if (type==NOTIFY_RELEASED) {
		if (b->status) {
			if (b->type==ACTION_OPENPANEL) {
				if (b->panel>=0) {
					_previous_panel = _active_panel;
					_active_panel = b->panel;
				}
			} else
			if (b->type==ACTION_CLOSEPANEL) {
				_active_panel = _previous_panel;
			} else
			if (b->type==ACTION_QUIT) {
				Quit();
			}
			b->status = 0;
			InvalidateDisplay();
		}
	} else
	if (type==NOTIFY_UPDATE) {
		uint16 x1 = b->base.left;
		uint16 x2 = b->base.right;
		uint16 y1 = b->base.top;
		uint16 y2 = b->base.bottom;
		uint16 status = b->status;
		
		if (b->status) {
			ui_draw_filled_rectangle(x1+5,y1+5,x2+5,y2+5,b->bg_color,b->edge_color);
		} else {
			ui_draw_filled_rectangle(x1,y1,x2,y2,b->bg_color,b->edge_color);
		}

		if (b->caption) {
			uint16 xlabel,ylabel;
			TGAHEADER* header = (TGAHEADER*)b->caption;
			uint16 width = header->width;	/* *((uint16 *)(b->caption + 12)); */
			uint16 height = header->height;	/* *((uint16 *)(b->caption + 14)); */
	
			xlabel = (x1+x2-width)/2;
			ylabel = (y1+y2-height)/2;		
			if (b->status) {
				ui_draw_icon(b->caption,xlabel+5,ylabel+5);
			} else {
				ui_draw_icon(b->caption,xlabel,ylabel);
			}
		}
	}
	return ecode;
}
