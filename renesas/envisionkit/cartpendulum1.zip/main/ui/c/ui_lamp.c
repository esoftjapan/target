/**
 * ui_lamp.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>
	
int Notify_lamp(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	LAMP* l = (LAMP*)me;

	if (type==NOTIFY_UPDATE) {
		if (l->base.visible) {
			if (IsTrue(l->buddy,l->dataType,l->threshold)) {
				ui_draw_icon(l->onimage,l->base.left,l->base.top);
			} else {
				ui_draw_icon(l->offimage,l->base.left,l->base.top);
			}
		}
	}
	return ecode;
}
