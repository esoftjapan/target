/**
 * ui_updown.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __UPDOWN_H__
#define	__UPDOWN_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>
#include <ui_numberdisplay.h>

typedef struct __UPDOWN
{
	CONTROL			base;				//base class

	/* updown */
	real_t			init;				/* initial value */
	real_t			inc;				/* increment */
	real_t			llimit;				/* lower limit */
	real_t			ulimit;				/* upper limit */
	real_t			value;				/* value */

	void*			buddy;				//buddy
	const uint8		dataType;			//buddy data type
	
	/* number display */
	uint16			pitch;				//pitch between digits
	color_t			fgcolor;			//foreground color
	color_t			bgcolor;			//background color
	color_t			edgecolor;			//edge color
	int				ndigits;			//number of total digits
	int				precision;			//number of fraction didgits
	char			digits[NUMDIGITS];	//number
	 
	//font
	const uint8*	tga_0;				//TGA format font of '0'
	const uint8*	tga_1;				//TGA format font of '1'
	const uint8*	tga_2;				//TGA format font of '2'
	const uint8*	tga_3;				//TGA format font of '3'
	const uint8*	tga_4;				//TGA format font of '4'
	const uint8*	tga_5;				//TGA format font of '5'
	const uint8*	tga_6;				//TGA format font of '6'
	const uint8*	tga_7;				//TGA format font of '7'
	const uint8*	tga_8;				//TGA format font of '8'
	const uint8*	tga_9;				//TGA format font of '9'
	const uint8*	tga_dot;			//TGA format font of '.'
	const uint8*	tga_plus;			//TGA format font of '+'
	const uint8*	tga_minus;			//TGA format font of '-'	
} UPDOWN;

extern int Notify_updown(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif