/**
 * ui_label.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __LABEL_H__
#define	__LABEL_H__

#include <ui_types.h>
#include <ui_control.h>

typedef struct __LABEL
{
	CONTROL				base;
	
	color_t				edgecolor;
	int8				style;
	const uint8*		tga;

} LABEL;

extern int Notify_label(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif