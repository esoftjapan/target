/**
 * ui_levelmeter.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __LEVELMETER_H__
#define	__LEVELMETER_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __LEVELMETER
{
	CONTROL			base;

	LMSTYLE			style;				/* 0:vertical, 1:horizontal */
	color_t			levelcolor;			/* level color */
	real_t			min;				/* lower limit */
	real_t			max;				/* upper limit */
	uint16			xorg;				/* xorg of image */
	uint16			yorg;				/* yorg of image */
	const uint8*	image;				/* bg image */
	void*			buddy;				/* buddy */
	const uint8		dataType;			/* buddy data type */
} LEVELMETER;

extern int Notify_levelmeter(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);
#endif