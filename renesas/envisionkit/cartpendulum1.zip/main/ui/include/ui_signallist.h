/**
 * ui_signallist.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __SIGNALLIST_H__
#define	__SIGNALLIST_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __SIGNALITEM SIGNALITEM;
struct __SIGNALITEM
{
	const uint8*	blockName;
	const uint8*	signalName;
	void*			buddy;
	const uint8		dataType;	/* buddy data type */
};

typedef struct __SIGNALLIST
{
	CONTROL			base;

	/* signallist */
	const int16				nitems;		/* number of items */
	const SIGNALITEM*		items;		/* item array */
	int16					top;		/* top item */
	int16					pos;		/* scroll bar handle position */
	int16					grapsed;	/* handle is grapsed */
} SIGNALLIST;

extern int Notify_signallist(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif