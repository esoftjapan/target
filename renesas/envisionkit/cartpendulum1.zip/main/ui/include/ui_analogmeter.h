/**
 * ui_analoglmeter.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __ANALOGMETER_H__
#define	__ANALOGMETER_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __ANALOGMETER
{
	CONTROL			base;

	color_t			indicatorcolor;		/* indicator color */
	real_t			min;				/* lower limit */
	real_t			max;				/* upper limit */
	real_t			begin;				/* angle of begin */
	real_t			end;				/* angle of end */
	const uint8*	image;				/* bg image */
	void*			buddy;				/* buddy */
	const uint8		dataType;			/* buddy data type */
} ANALOGMETER;

extern int Notify_analogmeter(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);
#endif