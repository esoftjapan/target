/**
 * qmath.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 * fixed point real
 */
 
#ifndef __QMATH_H__
#define	__QMATH_H__

#include <ui_types.h>

typedef int32 qreal;

#ifdef __cplusplus
extern "C" {
#endif

int get_qbit();
int isqov(qreal q);
qreal qadd(qreal lhs, qreal rhs);
qreal qsub(qreal lhs, qreal rhs);
qreal qmul(qreal lhs, qreal rhs);
qreal qdiv(qreal lhs, qreal rhs);
qreal f2q(float rhs);
qreal i2q(int intpart);
float q2f(qreal rhs);
qreal d2q(double rhs);
int32 q2i(qreal rhs);
double q2d(qreal rhs);
int q2s(qreal src, char* s, int count, int precision, int plus_sign);
int i2s(int src, char* s, int count, int plus_sign);
int f2s(float v, char* s, int count, int precision, int plus_sign);
int d2s(double v, char* s, int count, int precision, int plus_sign);
float s2f(const char* s);
double s2d(const char* s);
int s2i(const char* s);
float roundup125f(float x, float* psf);
float rounddown125f(float x, float* psf);
double roundup125d(double x, double* psf);
double rounddown125d(double x, double* psf);

#ifdef __cplusplus
}
#endif

#ifdef USING_FLOAT
	#define	ConvQ2R			q2f
	#define	ConvR2Q			f2q
	#define	ConvR2S			f2s
	#define ConvS2R			s2f
	#define RoundUp125		roundup125f
	#define RoundDown125	rounddown125f

	#define	__fabs			fabsf
	#define	__floor			floorf
	#define	__ceil			ceilf
	#define	__log10			log10f
	#define	__pow			powf
#else
	#define	ConvQ2R			q2d
	#define	ConvR2Q			d2q
	#define	ConvR2S			d2s
	#define ConvS2R			s2d
	#define RoundUp125		roundup125d
	#define RoundDown125	rounddown125d

	#define	__fabs			fabs
	#define	__floor			floor
	#define	__ceil			ceil
	#define	__log10			log10
	#define	__pow			pow
#endif

#endif /* __QMATH_H__ */
