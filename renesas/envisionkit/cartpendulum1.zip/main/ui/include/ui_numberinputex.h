/**
 * ui_numberinputex.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */
 
#ifndef __NUMBERINPUTEX_H__
#define	__NUMBERINPUTEX_H__
 
#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>
#include <ui_numberdisplay.h>
#include <ui_tenkey.h>

typedef struct __NUMBERINPUTEX
{
	CONTROL			base;				/* base class */
	NUMBERDISPLAY*	numberdisplay;		/* internal numberdisplay */
	TENKEY*			tenkey;				/* internal tenkey */ 
} NUMBERINPUTEX;

extern int Notify_numberinputex(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif
