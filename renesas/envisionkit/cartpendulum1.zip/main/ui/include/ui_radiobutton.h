/**
 * ui_radiobutton.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __RADIOBUTTON_H__
#define	__RADIOBUTTON_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __RADIOBUTTON RADIOBUTTON;
struct __RADIOBUTTON
{
	CONTROL			base;

	/* radiobutton */
	const uint8		style;		/* 0:normal, 1:image */
	const uint8*	offimage;	/* off image */
	const uint8*	onimage;	/* onimage */
	const real_t	offvalue;	/* value at off */
	const real_t	onvalue;	/* value at on */
	const char*	caption;	/* caption */
	const uint8		init;		/* initial status */
	uint8			status;		/* 0:off, 1:on(pushed) */
	RADIOBUTTON*	link;		/* linked list of the same group */
	void*			buddy;		/* buddy */
	const uint8		dataType;	/* buddy data type */
};

extern int Notify_radiobutton(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif