/**
 * ui_vlx.h
 *
 * Copyright 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2016/10/01		YT				created
 *
 */
 
#ifndef __VLX_H__
#define	__VLX_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <qmath.h>
#include <ui_utils.h>
#include <ui_colors.h>
#include <ui_control.h>
#include <ui_system.h>
#include <ui_framebuffer.h>
#include <ui_graphics.h>
#include <ui_actionbutton.h>
#include <ui_actionbuttonex.h>
#include <ui_numberdisplay.h>
#include <ui_numberdisplayex.h>
#include <ui_label.h>
#include <ui_lamp.h>
#include <ui_switch.h>
#include <ui_group.h>
#include <ui_radiobutton.h>
#include <ui_updown.h>
#include <ui_levelmeter.h>
#include <ui_analogmeter.h>
#include <ui_slider.h>
#include <ui_rotaryknob.h>
#include <ui_led.h>
#include <ui_dropdownlist.h>
#include <ui_numberinput.h>
#include <ui_numberinputex.h>
#include <ui_tenkey.h>
#include <ui_bitmapex.h>
#include <ui_message.h>
#include <ui_trendgraph.h>
#include <ui_xygraph.h>
#include <ui_paramlist.h>
#include <ui_signallist.h>

#endif