/**
 * ui_utils.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */
 
#ifndef __UTILS_H__
#define	__UTILS_H__

#include "vlx_types.h"
#include "ui_types.h"
#include "ui_control.h"

#ifndef min
#define	min(x,y)	((x)<(y)? x:y)
#endif
#ifndef max
#define	max(x,y)	((x)>(y)? x:y)
#endif

#ifndef abs
#define abs(x)		((x)>0?(x):-(x))
#endif

PANEL* GetActivePanel();
uint8 IsMainPanel(PANEL* panel);
uint8 IsHit(CONTROL* c, uint16 x, uint16 y);
uint8 IsHitRect(UIRECT* rc, uint16 x, uint16 y);
uint8 IsHitEx(CONTROL* c, uint16 x, uint16 y, uint16 dx, uint16 dy);
int StringClear(char* str);
int StringCopy(char* dst, const char* src, int count);
int StringLength(const char* str);
int StringAppend(char* dst, const char* src, int count);
uint8 WriteValueToBuddy(void* buddy, DATATYPE dataType, real_t value);
real_t ReadValueFromBuddy(void* buddy, DATATYPE dataType);
uint8 IsTrue(void* buddy, DATATYPE dataType, real_t threshold);
int _sincosf(float theta, float* S, float* C);
uint16 GetPanelWidth();
uint16 GetPanelHeight();
uint16 FontHeight();
uint16 StringWidth(const char* str);
int32 StepProcessTimeNanosec(uint8 type);

#endif
