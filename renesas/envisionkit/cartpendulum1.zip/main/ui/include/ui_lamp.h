/**
 * ui_lamp.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __LAMP_H__
#define	__LAMP_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __LAMP
{
	CONTROL			base;

	/* lamp */
	const uint8*	onimage;	/* on image */
	const uint8*	offimage;	/* off image */
	const real_t	threshold;	/* threshold level */
	void*			buddy;		/* buddy */
	const uint8		dataType;	/* buddy data type */
} LAMP;

extern int Notify_lamp(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif