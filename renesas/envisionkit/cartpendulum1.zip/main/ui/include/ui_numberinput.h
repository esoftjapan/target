/**
 * ui_numberinput.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */
 
#ifndef __NUMBERINPUT_H__
#define	__NUMBERINPUT_H__
 
#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>
#include <ui_numberdisplay.h>
#include <ui_tenkey.h>

typedef struct __NUMBERINPUT
{
	CONTROL			base;				/* base class */
	NUMBERDISPLAY*	numberdisplay;		/* internal numberdisplay */
	TENKEY*			tenkey;				/* internal tenkey */ 
} NUMBERINPUT;

extern int Notify_numberinput(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif
