/**
 * ui_system.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 * 
 */

#ifndef __SYSTEM_H__
#define	__SYSTEM_H__

#include <ui_types.h>
#include <ui_control.h>

void Quit();
void InvalidateDisplay();
void Buzzer(int freq, int duration);
void FatalError(const char* filename, int line, const char* fmt, ...);
void Log(const char* filename, int line, const char* fmt, ...);
void EnterCritical();
void ExitCritical();
int32 StepProcessTimeNanosec(uint8 type);
int32 TestFloatingPointException();
real_t GetModelTime();

#endif
