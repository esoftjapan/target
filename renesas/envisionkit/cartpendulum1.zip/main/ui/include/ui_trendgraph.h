/**
 * ui_trendgraph.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */


#ifndef __TRENDGRAPH_H__
#define	__TRENDGRAPH_H__

#include <target_config.h>
#include <ui_types.h>
#include <ui_control.h>

#ifndef MAXCHANNEL
#define	MAXCHANNEL	(8)
#endif

typedef struct __TRENDGRAPH
{
	CONTROL			base;
	TENKEY*			tenkey;				/* internal tenkey */ 

	const uint16	nchannels;						/* number of active channels */
	const uint16	ringbufsize;					/* ring buffer size */
	const uint16	plotsize;						/* plot size */
	const color_t	bgcolor;						/* background color */
	const color_t	tracebgcolor;					/* background color of trace area */
	const color_t	edgecolor;						/* edge color */
	const color_t	gridcolor;						/* grid color */
	const color_t	tracecolor[MAXCHANNEL];			/* trace color */
	const uint16	linewidth;						/* line width */
	const uint16	xaxis_divide;					/* xaxis divide */
	const uint16	yaxis_divide;					/* yaxis divide */
	const uint16	xsig_digits;					/* number of significant digits of x-axis */
	const uint16	ysig_digits;					/* number of significant digits of x-axis */
	const char*		xaxis_name_unit;				/* xaxis name and unit */
	const char*		yaxis_name_unit;				/* yaxis name and unit */
	const char*		title;							/* title */
	const uint16	x1;								/* left of trace area */
	const uint16	y1;								/* top of trace area */
	const uint16	x2;								/* right of trace area */
	const uint16	y2;								/* bottom of trace area */
	const uint16	menu_width;						/* menu icon width */
	const uint16	menu_height;					/* menu icon height */
	const char*		legend[MAXCHANNEL];				//legend

	int16			status;							/* setup status */
	int16			visible[MAXCHANNEL];			/* channel is visible */
	int16			style;							/* 0:trendgraph, 1:stripchart */
	int16			scale_mode;						/* 0:normal, 1:auto, 2:manual */
	int16			trigger_mode;					/* 0:free run, 1:single, 2:repeat */
	int16			trigger_ch;						/* trigger channel */
	int16			trigger_slope;					/* 0:plus, 1:minous */
	int16			cursor_on;						/* 0:cursor off, 1:cursor on */
	int16			statemachine;					/* trigger state machine */
	real_t			trigger_pos;					/* trigger position[%] */
	int16			trigger_delay;					/* trigger delay countetr */
	int16			cursor_pos;						/* cursor position */
	int16			repeat_period;					/* repeat period */
	int16			repeat_count;					/* repeat count */
	int16			wp;								/* write pointer of ring buffer */
	int16			rp;								/* read poinyer of ring buffer */
	int16			decr;							/* decimation rate */
	real_t			xdelta;							/* xdelta = __stepTime*decr */
	real_t			xmax_hold;						/* xmax at hold */
	real_t			ymin[MAXCHANNEL];				/* ymin */
	real_t			ymax[MAXCHANNEL];				/* ymax */
	real_t			sf[MAXCHANNEL];					/* scaling factor */
	real_t			trigger_level;					/* trigger level */
	real_t			prev_value;						/* previos value */
	
	const uint8*	menu_hold_off;					/* menu hold off */
	const uint8*	menu_hold_on;					/* menu hold on */
	const uint8*	menu_cursor_off;				/* menu cursor off */
	const uint8*	menu_cursor_on;					/* menu cursor on */
	const uint8*	menu_style_trendgraph;			/* menu style trendgraph */
	const uint8*	menu_style_stripchart;			/* menu style stripchart */
	const uint8*	menu_freerun;					/* menu freerun */
	const uint8*	menu_single;					/* menu single */
	const uint8*	menu_repeat;					/* menu repeat */
	const uint8*	menu_scale_mode;				/* menu scale mode */
	const uint8*	menu_trigger_mode;				/* menu trigger mode */
	
	real_t*			ringbuf[MAXCHANNEL];			/* ring buffers */
	real_t*			xbuf[MAXCHANNEL];				/* x plot buffer */
	real_t*			ybuf[MAXCHANNEL];				/* y plot buffer */

} TRENDGRAPH;

extern int Notify_trendgraph(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif
