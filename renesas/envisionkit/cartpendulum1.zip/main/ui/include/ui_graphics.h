/**
 * ui_graphics.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */
 
#ifndef __GRAPHICS_H__
#define	__GRAPHICS_H__
 
#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

extern void ui_draw_icon(const uint8 *p, uint16 xoffset, uint16 yoffset);
extern void ui_draw_icon_2(const uint8 *p, uint16 xoffset, uint16 yoffset);
extern void ui_draw_icon_16(const uint8 *p, uint16 xoffset, uint16 yoffset);
extern void ui_draw_icon_256(const uint8 *p, uint16 xoffset, uint16 yoffset);
extern void ui_draw_icon_with_rotate(const uint8 *p, uint16 xoffset, uint16 yoffset, int16 xpivot, int16 ypivot, real_t angle);
extern void ui_draw_icon_with_rotate_2(const uint8 *p, uint16 xoffset, uint16 yoffset, int16 xpivot, int16 ypivot, real_t angle);
extern void ui_draw_icon_with_rotate_16(const uint8 *p, uint16 xoffset, uint16 yoffset, int16 xpivot, int16 ypivot, real_t angle);
extern void ui_draw_icon_with_rotate_256(const uint8 *p, uint16 xoffset, uint16 yoffset, int16 xpivot, int16 ypivot, real_t angle);
extern void ui_raster_indexed_color(uint16 x, uint16 y, const uint8* pixels, color_t* palette, uint16 npixels);
extern void ui_draw_text(const char *text, uint16 x, uint16 y, color_t fgcolor, color_t bgcolor);
extern void ui_draw_text_transparent(const char *text, uint16 x, uint16 y, color_t fgcolor);
extern uint16 ui_put_char(const char textchar, uint16 x, uint16 y, color_t fgcolor, color_t bgcolor);
extern uint16 ui_put_char_transparent(const char textchar, uint16 x, uint16 y, color_t fgcolor);
extern void ui_put_pixel(color_t color, uint16 x, uint16 y);
extern color_t ui_get_pixel(uint16 x, uint16 y);
extern void ui_draw_filled_rectangle(uint16 x1, uint16 y1, uint16 x2, uint16 y2, color_t bgcolor, color_t edgecolor);
extern int ui_is_using_framebuffer(void);
extern void ui_draw_filled_rectangle_direct(uint16 x1, uint16 y1, uint16 x2, uint16 y2, uint8 bgcolor, color_t edgecolor);
extern void ui_draw_rectangle(uint16 x1, uint16 y1, uint16 x2, uint16 y2, color_t edgecolor);
extern void ui_draw_rectangle_linewidth(uint16 x1, uint16 y1, uint16 x2, uint16 y2, color_t edgecolor, uint16 linewidth);
extern void ui_draw_3D_rectangle(uint16 x1, uint16 y1, uint16 x2, uint16 y2);
extern void ui_draw_line(uint16 x1, uint16 y1, uint16 x2, uint16 y2, color_t color);
extern void ui_draw_horizontal_line(uint16 x1, uint16 x2, uint16 y, color_t color);
extern void ui_draw_horizontal_line_linewidth(uint16 x1, uint16 x2, uint16 y, uint16 linewidth, color_t color);
extern void ui_draw_vertical_line(uint16 x, uint16 y1, uint16 y2, color_t color);
extern void ui_draw_vertical_line_linewidth(uint16 x, uint16 y1, uint16 y2, uint16 linewidth, color_t color);
extern void ui_draw_polyline(uint16 count, point_t* pt, color_t edgecolor);
extern void ui_draw_polygon(uint16 count, point_t* pt, color_t edgecolor, color_t bgcolor);
extern void ui_draw_cirle(uint16 xc, uint16 yc, uint16 r, color_t color);
extern void ui_draw_filled_circle(uint16 xc, uint16 yc, uint16 r, color_t bgcolor, color_t edgecolor);
extern void ui_set_transparent(uint8 enable, color_t color);
extern uint8 ui_get_transparent_enable();
extern color_t ui_get_transparent_color();
extern uint16 LIMITWIDTH(uint16 x);
extern uint16 LIMITHEIGHT(uint16 y);
extern void ui_plot_trace(uint16 plotsize, uint16 x1, uint16 x2, uint16 y1, uint16 y2, real_t xmin, real_t xmax, real_t ymin, real_t ymax, real_t* xbuf, real_t* ybuf, real_t sf, color_t color);

#endif