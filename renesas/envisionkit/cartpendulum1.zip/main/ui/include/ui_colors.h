/**
 * ui_colors.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */

#ifndef __COLORS_H__
#define	__COLORS_H__

#include "ui_types.h"

#define BLACK     	    	RGBCOLOR(0, 0, 0)
#define LIGHTGRAY  	   		RGBCOLOR(191,191,191)
#define	GRAY				RGBCOLOR(100,100,100)
#define DARKGRAY   	   		RGBCOLOR(63, 63, 63)
#define WHITE      	   		RGBCOLOR(255, 255, 255)
#define RED           		RGBCOLOR(255, 0, 0)
#define GREEN         		RGBCOLOR(0, 255, 0)
#define BLUE          		RGBCOLOR(0, 0, 255)
#define MAGENTA       		(RED | BLUE)
#define CYAN          		(GREEN | BLUE)
#define YELLOW        		(RED | GREEN)
#define LIGHTRED      		RGBCOLOR(255, 63, 63)
#define LIGHTGREEN    		RGBCOLOR(63, 255, 63)
#define LIGHTBLUE     		RGBCOLOR(63, 63, 255)
#define LIGHTMAGENTA  		(LIGHTRED | LIGHTBLUE)
#define LIGHTCYAN     		(LIGHTGREEN | LIGHTBLUE)
#define LIGHTYELLOW   		(LIGHTRED | LIGHTGREEN)


#endif

