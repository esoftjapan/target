/**
 * ui_paramlist.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __PARAMLIST_H__
#define	__PARAMLIST_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __PARAMITEM PARAMITEM;
struct __PARAMITEM
{
	const uint8*	blockName;
	const uint8*	signalName;
	void*			buddy;
	const uint8		dataType;	/* buddy data type */
};

typedef struct __PARAMLIST
{
	CONTROL			base;

	/* paramlist */
	const int16				nitems;				/* number of items */
	const PARAMITEM*		items;				/* item array */
	int16					top;				/* top item */
	int16					pos;				/* scroll bar handle position */
	int16					grapsed;			/* handle is grapsed */
	int16					selected;			/* selected item */
	TENKEY*					tenkey;				/* internal tenkey */ 
	
} PARAMLIST;

extern int Notify_paramlist(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif