/**
 * ui_numberdisplay.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */
 
#ifndef __NUMBERDISPLAY_H__
#define	__NUMBERDISPLAY_H__
 
#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

#ifndef NUMDIGITS
#define	NUMDIGITS		(64)
#endif

typedef struct __NUMBERDISPLAY
{
	CONTROL			base;				//base class

	const uint16	pitch;				//pitch between digits
	const color_t	fgcolor;			//foreground color
	const color_t	bgcolor;			//background color
	const color_t	edgecolor;			//edge color
	uint8			ndigits;			//number of total digits
	uint8			precision;			//number of fraction didgits
	void*			buddy;				//buddy
	uint8			dataType;			//buddy data type
	char			value[NUMDIGITS];	//number
	 
	//font
	const uint8*	tga_0;				//TGA format font of '0'
	const uint8*	tga_1;				//TGA format font of '1'
	const uint8*	tga_2;				//TGA format font of '2'
	const uint8*	tga_3;				//TGA format font of '3'
	const uint8*	tga_4;				//TGA format font of '4'
	const uint8*	tga_5;				//TGA format font of '5'
	const uint8*	tga_6;				//TGA format font of '6'
	const uint8*	tga_7;				//TGA format font of '7'
	const uint8*	tga_8;				//TGA format font of '8'
	const uint8*	tga_9;				//TGA format font of '9'
	const uint8*	tga_dot;			//TGA format font of '.'
	const uint8*	tga_plus;			//TGA format font of '+'
	const uint8*	tga_minus;			//TGA format font of '-'
} NUMBERDISPLAY;

extern int Notify_numberdisplay(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif
