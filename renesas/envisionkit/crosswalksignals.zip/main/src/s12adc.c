﻿/**
 * s12adc.c
 *
 * (C)eSoft 2019, All rights reserved
 *
 * --------------------------------------------------------
 * 2019/03/03		YT
 */
 
#include "iodefine.h"

/**
 * ユニット0は全チャンネル有効
 */
void s12adc0_init()
{
	SYSTEM.PRCR.WORD = 0xA50B;
	MSTP(S12AD) = 0;
	SYSTEM.PRCR.WORD = 0xA500;
	
	/* I/Oポートの変更を許可 */
	MPC.PWPR.BIT.B0WI = 0;
	MPC.PWPR.BIT.PFSWE = 1;

	MPC.P40PFS.BIT.ASEL = 1;
	PORT4.PDR.BIT.B0 = 0;
	PORT4.PMR.BIT.B0 = 1;

	MPC.P41PFS.BIT.ASEL = 1;
	PORT4.PDR.BIT.B1 = 0;
	PORT4.PMR.BIT.B1 = 1;

	MPC.P42PFS.BIT.ASEL = 1;
	PORT4.PDR.BIT.B2 = 0;
	PORT4.PMR.BIT.B2 = 1;

	MPC.P43PFS.BIT.ASEL = 1;
	PORT4.PDR.BIT.B3 = 0;
	PORT4.PMR.BIT.B3 = 1;

	MPC.P44PFS.BIT.ASEL = 1;
	PORT4.PDR.BIT.B4 = 0;
	PORT4.PMR.BIT.B4 = 1;

	MPC.P45PFS.BIT.ASEL = 1;
	PORT4.PDR.BIT.B5 = 0;
	PORT4.PMR.BIT.B5 = 1;

	MPC.P46PFS.BIT.ASEL = 1;
	PORT4.PDR.BIT.B6 = 0;
	PORT4.PMR.BIT.B6 = 1;
	
	MPC.P47PFS.BIT.ASEL = 1;
	PORT4.PDR.BIT.B7 = 0;
	PORT4.PMR.BIT.B7 = 1;

	/* I/Oポートの変更を禁止	*/
    MPC.PWPR.BIT.PFSWE = 0;
    MPC.PWPR.BIT.B0WI = 1;
	
	/* スキャンモードの設定:シングルスキャンモード */
	S12AD.ADCSR.BIT.ADCS = 0;
	
	/* A/D変換チャンネル設定:全チャンネル有効 */
	S12AD.ADANSA0.WORD = 0xff;
	
	/* 加算・平均回数 */
	S12AD.ADADC.BIT.ADC = 0;
	
	/* 加算・平均モードの選択 */
	S12AD.ADADC.BIT.AVEE = 1;
	
	/* サンプリングステート数の設定=11(デフォールト) */
	S12AD.ADSSTR0 = 11;
	S12AD.ADSSTR1 = 11;
	S12AD.ADSSTR2 = 11;
	S12AD.ADSSTR3 = 11;
	S12AD.ADSSTR4 = 11;
	S12AD.ADSSTR5 = 11;
	S12AD.ADSSTR6 = 11;
	S12AD.ADSSTR7 = 11;
	
	/* AD変換開始 */
	S12AD.ADCSR.BIT.ADST = 1;
}

/**
 * ユニット1は温度センサと内部基準電圧のみ有効
 */
void s12adc1_init()
{
	SYSTEM.PRCR.WORD = 0xA50B;
	MSTP(S12AD1) = 0;
	SYSTEM.PRCR.WORD = 0xA500;

	/* スキャンモードの設定:シングルスキャンモード */
	S12AD1.ADCSR.BIT.ADCS = 0;
	
	/* A/D変換チャンネル設定:全チャンネル無効 */
	S12AD1.ADANSA0.WORD = 0;
	S12AD1.ADANSA1.WORD = 0;

	/* 温度センサ出力をA/D変換の対象にする */
	S12AD1.ADEXICR.BIT.TSSA = 1;
		
	/* 温度センサの加算・平均モードを有効 */
	S12AD1.ADEXICR.BIT.TSSAD = 1;

	/* 内部基準電圧出力をA/D変換の対象にする */
	S12AD1.ADEXICR.BIT.OCSA = 1;
		
	/* 内部基準電圧の加算・平均モードを有効 */
	S12AD1.ADEXICR.BIT.OCSAD = 1;

	/* 加算・平均回数 */
	S12AD1.ADADC.BIT.ADC = 5;//0:1回, 1:2回, 2:3回, 3:4回, 5:16回
	
	/* 加算・平均モードの選択 */
	S12AD1.ADADC.BIT.AVEE = 1;
	
	/* サンプリングステート数の設定=11(デフォールト) */
	S12AD1.ADSSTRT = 11;
	S12AD1.ADSSTRO = 11;
	
	/* AD変換開始 */
	S12AD1.ADCSR.BIT.ADST = 1;
}

void s12adc0_restart()
{
	S12AD.ADCSR.BIT.ADST = 1;
}

void s12adc1_restart()
{
	S12AD1.ADCSR.BIT.ADST = 1;	
}

void s12adc0_read(float v[8])
{
	float ref = 3.3f/4096;
	
	v[0] = S12AD.ADDR0*ref;
	v[1] = S12AD.ADDR1*ref;
	v[2] = S12AD.ADDR2*ref;
	v[3] = S12AD.ADDR3*ref;
	v[4] = S12AD.ADDR4*ref;
	v[5] = S12AD.ADDR5*ref;
	v[6] = S12AD.ADDR6*ref;
	v[7] = S12AD.ADDR7*ref;
}

unsigned short s12adc1_read_temperature()
{
	unsigned short reg = S12AD1.ADTSDR;
	return reg;
}

unsigned short s12adc1_read_voltage_ref()
{
	unsigned short reg = S12AD1.ADOCDR;
	return reg;
}
