/**
 * ui_control.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */
 
#ifndef __CONTROL_H__
#define	__CONTROL_H__

#include <vlx_types.h>
#include <ui_types.h>

typedef enum
{
	/* action types */
	ACTIONBUTTONTYPE,
	ACTIONBUTTONEXTYPE,	
	
	/* output types */
	LABELTYPE,
	LAMPTYPE,
	LEDTYPE,
	BITMAPEXTYPE,
	LEVELMETERTYPE,
	ANALOGMETERTYPE,
	DIGITALMETERTYPE,
	NUMBERDISPLAYTYPE,
	NUMBERDISPLAYEXTYPE,
	TRENDGRAPHTYPE,
	XYGRAPHTYPE,
	PARAMLISTTYPE,
	SIGNALLISTTYPE,
	MESSAGEBOXTYPE,
	
	/* input types */
	SWITCHTYPE,
	BITMAPBUTTONTYPE,
	SLIDERTYPE,
	UPDOWNTYPE,
	RADIOBUTTONTYPE,
	GROUPTYPE,
	ROTARYKNOBTYPE,
	DROPDOWNLISTTYPE,
	ROTARYLISTTYPE,
	DIGIWHEELTYPE,
	INTEDITTYPE,
	REALEDITTYPE,
	REALEDITEXTYPE,
	TEXTEDITTYPE,
	TENKEYTYPE,
	
	MAX_CONTROLTYPE,
} CONTROLTYPE;
 
typedef enum
{
	NOTIFY_NONE,
	NOTIFY_INIT,		/* initialize control */
	NOTIFY_FINAL,		/* finalize control */
	NOTIFY_UPDATE,		/* update display */
	NOTIFY_PRESSED,		/* mouse button is pressed, or screen touch on */
	NOTIFY_RELEASED,	/* mouse button is released, or screen touch off */
	NOTIFY_MOVE,		/* mouse or screen touch is moving */
	NOTIFY_ACTION,		/* do something */
	NOTIFY_WRITERINGBUF,	/* write data into reing buffer */

	MAX_NOTIFYTYPE,
} NOTIFYTYPE;

typedef enum
{
	ACTION_NONE,			/* 0 */
	ACTION_OPENPANEL,		/* 1 */
	ACTION_CLOSEPANEL,		/* 2 */
	ACTION_QUIT,			/* 3 */
	
} ACTIONTYPE;

/* text position */
typedef enum
{
	LABELPOS_CENTER,
	LABELPOS_BOTTOM,
	LABELPOS_TOP,
	LABELPOS_RIGHT,
	LABELPOS_LEFT,
} LABELPOS;

/* push botton style */
typedef enum
{
	PBSTYLE_ALTERNATE = 0,
	PBSTYLE_MOMENTARY = 1,
} PBSTYLE;

/* level meter style */
typedef enum
{
	LMSTYLE_VERT = 0,
	LMSTYLE_HORZ = 1,
	
} LMSTYLE;

typedef struct __CONTROL CONTROL;
typedef struct __PANEL PANEL;
typedef int (*NOTIFYFUNC)(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);
typedef int (*ACTIONFUNC)(ACTIONTYPE type, CONTROL* me, void* param1, void* param2);

struct __CONTROL
{
	CONTROLTYPE		type;		/* control type */
	const char*		name;		/* control name */
	uint8			visible;	/* visible control */
	PANEL*			panel;		/* parent panel */
	CONTROL*		next;		/* next control of control chain */
	CONTROL*		prev;		/* previous control of control chain */

	uint16			left;		/* left position */
	uint16			top;		/* top position */
	uint16			right;		/* right position */
	uint16			bottom;		/* bottom position */

	NOTIFYFUNC		notify;		/* notify function */
};

struct __PANEL
{
	uint8			visible;		/* visible panel */
	uint16			width;			/* width of panel */
	uint16			height;	 		/* height of panel */
	uint16			bgtype;			/* back ground type */
	color_t			bgcolor;		/* background color */
	const uint8*	image;			/* image data */
	uint16			gridvisible;	/* visible grid */
	color_t			gridcolor;		/* grid color */
	uint16			xgrid;			/* number of x-grid */
	uint16			ygrid;			/* numbe rof y-grid */
	uint8			invalid;		/* to be updated */

	CONTROL*		link;
	NOTIFYFUNC		notify;			/* notify function */
};

extern int Notify_panel(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#pragma pack(push,1)
/**
 * TGA file format
 *	+-----------+
 *	| header	|
 *	+-----------+
 *	| color map	|
 *	+-----------+
 *	| pixel		|
 *	+-----------+
 */
typedef struct _TGAHEADER
{
   uint8  	idlength;				/* 0	00											*/
   uint8  	colourmaptype;			/* 1	01		0:no color map, 1:color map			*/
   uint8  	datatypecode;			/* 2	01		uncompressed, color-mapped images	*/
   uint16	colourmaporigin;		/* 3	0000										*/
   uint16	colourmaplength;		/* 5	0100	256									*/
   uint8  	colourmapdepth;			/* 7	10		16bit								*/
   uint16 	xorigin;				/* 8	0000										*/
   uint16 	yorigin;				/* 10	0000										*/
   uint16 	width;					/* 12	0040	64									*/
   uint16 	height;					/* 14	0040	64									*/
   uint8  	bitsperpixel;			/* 16	08											*/
   uint8  	imagedescriptor;		/* 17	00		bit5: 0:lower-left, 1:upper-left	*/
} TGAHEADER;
#pragma pack(pop)

typedef struct _point_t
{
	int16	x,y;
} point_t;

typedef point_t UIPOINT;

typedef struct _UIRECT
{
	int16	left;
	int16	top;
	int16	right;
	int16	bottom;
} UIRECT;


#define	UI_TOUCH   (0x0000001)

typedef struct _UIINPUT
{
	uint16	x;
	uint16	y;
	uint32	status;
} UIINPUT;

#endif
