/**
 * ui_actionbuttonex.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __ACTIONBUTTONEX_H__
#define	__ACTIONBUTTONEX_H__

#include <ui_types.h>
#include <ui_control.h>

typedef struct __ACTIONBUTTONEX
{
	CONTROL			base;		//control base

	ACTIONTYPE		type;		//action type
	const uint8*	image;		//bitmap image
	int8			status;		//button status
	int8			panel;		//id of panel to be open or close
} ACTIONBUTTONEX;

extern int Notify_actionbuttonex(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif