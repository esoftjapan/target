/**
 * ui_group.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __UIGROUP_H__
#define	__UIGROUP_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __UIGROUP
{
	CONTROL			base;

	/* datagroup */
	color_t			edgecolor;
	const uint8*	caption;
} UIGROUP;

extern int Notify_group(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif