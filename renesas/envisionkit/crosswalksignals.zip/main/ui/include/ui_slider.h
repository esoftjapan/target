/**
 * ui_slider.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __SLIDER_H__
#define	__SLIDER_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __SLIDER
{
	CONTROL			base;

	/* slider */
	const uint8		style;		/* 1:vertical, 0:horizontal */
	const uint8*	bgimage;	/* background image */
	const uint8*	knobimage;	/* knob image */
	const real_t	vmin;		/* min value */
	const real_t	vmax;		/* max value */
	const real_t	init;		/* initial value */
	const uint16	posmin;		/* position at min value */
	const uint16	posmax;		/* position at max value */
	const uint16	accuracy;	/* number of digits in fractional part */
	uint16			xpos;		/* current knob position */
	uint16			ypos;		/* current knob position */
	real_t			value;		/* current value */
	char			text[32];	/* text display */
	void*			buddy;		/* buddy */
	const uint8		dataType;	/* buddy data type */
} SLIDER;

extern int Notify_slider(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif