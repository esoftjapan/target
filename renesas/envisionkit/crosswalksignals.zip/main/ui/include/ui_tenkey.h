/**
 * ui_tenkey.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __TENKEY_H__
#define	__TENKEY_H__

#include <ui_types.h>
#include <ui_control.h>
#include <ui_numberdisplay.h>

typedef struct __TENKEY
{
	CONTROL				base;
	
	//ten key
	NUMBERDISPLAY*		numberdisplay;		//display area
	CONTROL*			owner;				//owner control
	const uint8*		tga;				//bitmap image
	uint16				status;				//status
	uint16				entry;				//tenkey entry type
	uint16				pos;				//entry position
	uint16				x1,y1,x2,y2;
} TENKEY;

extern int Notify_tenkey(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);
extern void vcl_tenkey_initialize(TENKEY* tk);
extern void vcl_tenkey_show(TENKEY* tk);
extern void vcl_tenkey_set_value(TENKEY* tk, const char* src);
extern void vcl_tenkey_get_value(TENKEY* tk, char* dst);

#endif