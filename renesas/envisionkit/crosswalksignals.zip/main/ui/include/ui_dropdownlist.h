/**
 * ui_dropdownlist.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __DROPDOWNLIST_H__
#define	__DROPDOWNLIST_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __DROPDOWNITEM DROPDOWNITEM;
struct __DROPDOWNITEM
{
	const real_t	value;
	const uint8*	image;
};

typedef struct __DROPDOWNLIST
{
	CONTROL			base;

	/* dropdownlist */
	const uint8				nitems;		/* number of items */
	const uint16			itemheight;	/* item height */
	const DROPDOWNITEM*		items;		/* item array */
	const uint8				init;		/* initial selected item */
	const color_t			edgecolor;	/* color of selector */
	const color_t			bgcolor;	/* color of selector */
	uint8					selected;	/* seleted item id */
	uint8					expanding;	/* list is expanding */
	uint8					hilighted;	/* current hilighted item */
	void*					buddy;		/* buddy */
	const uint8				dataType;	/* buddy data type */
} DROPDOWNLIST;

extern int Notify_dropdownlist(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif