/**
 * ui_paramlist.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

/**
 *	x1		    x3		 x4		x5	 x2
 *  +-----------+--------+-------+----+ y1
 *  | blockname | param  | value | ^  |
 *  +-----------+--------+-------+----+ y3
 *  |           |        |       |    |
 *  +-----------+--------+-------+----+ 
 *  |           |        |       | *  |
 *  +-----------+--------+-------+----+
 *  |           |        |       |    |
 *  +-----------+--------+-------+----+ y4
 *  |           |        |       | v  |
 *  +-----------+--------+-------+----+ y5
 *  |                                 |
 *  +---------------------------------+ y2
 */
 
#include <ui_vlx.h>
	
static const uint16 blockname_width = 100;
static const uint16 signal_width = 100;
static const uint16 item_height = 20;
static const uint16 scrollbar_width = 20;

int Notify_paramlist(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	uint16 nrow,value_width;
	uint16 x1,x2,x3,x4,x5,y1,y2,y3,y4,y5;

	PARAMLIST* pl = (PARAMLIST*)me;
	TENKEY* tk = pl->tenkey;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	nrow = (pl->base.bottom-pl->base.top)/item_height;
	if (nrow>pl->nitems) {
		nrow = pl->nitems;
	}

	x1 = pl->base.left;
	x2 = pl->base.right;
	x5 = x2-scrollbar_width;
	value_width = x2-x5;
	x3 = x1+blockname_width;
	x4 = x3+signal_width;
	y1 = pl->base.top;
	y2 = pl->base.bottom;
	y3 = y1+item_height;
	y5 = y1+(nrow+1)*item_height;
	y4 = y5-item_height;

	/* tenkey */
	if (type!=NOTIFY_UPDATE) {
		Notify_tenkey(type,(CONTROL*)tk,param1,param2);
	}

	if (type==NOTIFY_INIT) {
		pl->top = 0;
		pl->pos = 0;
		pl->grapsed = 0;
		pl->selected = 0;

	} else	
	if (type==NOTIFY_PRESSED) {
		int i;
		UIRECT rc;
		
		/* up arrow */
		rc.left = x5;	rc.right = x2;
		rc.top = y1; 	rc.bottom = y1+item_height;
		if (IsHitRect(&rc,x,y)) {
			int k = pl->top-5;
			pl->top = min(pl->nitems-1,max(0,k));
			pl->pos = pl->top;
		}
		
		/* down arrow */
		rc.left = x5;	rc.right = x2;
		rc.top = y4; 	rc.bottom = y5;
		if (IsHitRect(&rc,x,y)) {
			int k = pl->top+5;
			pl->top = min(pl->nitems-1,max(0,k));
			pl->pos = pl->top;
		}

		/* handle bar */
		rc.left = x5;
		rc.right = x2;
		rc.top = (pl->pos+1)*item_height+y1;
		rc.bottom = rc.top+item_height;
		if (IsHitRect(&rc,x,y)) {
			pl->grapsed = 1;
		}
		
		/* value column */
		for (i=0; i<pl->nitems; i++) {
			uint16 iy;
			
			if (i<pl->top||i>=nrow) {
				continue;
			}
		
			iy = (i+1)*item_height+y1;
			rc.left = x4;	rc.right = x5;
			rc.top = iy; 	rc.bottom = iy+item_height;
			if (IsHitRect(&rc,x,y)) {
				/* popup tenkey */
				pl->selected = i;
				tk->numberdisplay->ndigits = 10;
				tk->numberdisplay->value[0] = 0;
				tk->base.visible = 1;
				break;
			}
		}
	} else
	if (type==NOTIFY_RELEASED) {
		if (pl->grapsed) {
			pl->top = pl->pos;
		}
		pl->grapsed = 0;
	} else
	if (type==NOTIFY_MOVE) {
		if (pl->grapsed) {
			int k = 0;
			k = (y-y1-item_height)/item_height;
			pl->pos = max(0,min(pl->nitems-1,k));
		}
	} else
	if (type==NOTIFY_ACTION) {
		CONTROL* tk = (CONTROL*)param1;
		if (tk==(CONTROL*)pl->tenkey) {
			char *str = (char*)param2;
			real_t value = ConvS2R(str);
			WriteValueToBuddy(pl->items[pl->selected].buddy,pl->items[pl->selected].dataType,value);
		}
	} else
	if (type==NOTIFY_UPDATE) {
		if (pl->base.visible) {
			uint16 dx,dy,iy,i;
			point_t pt[3];
			
			/* title */
			ui_draw_filled_rectangle(x1,y1,x5,y1+item_height,LIGHTCYAN,BLACK);
			ui_draw_text_transparent("Block",x1+5,y1+5,BLACK);
			ui_draw_text_transparent("Signal",x3+5,y1+5,BLACK);
			ui_draw_text_transparent("Value",x4+5,y1+5,BLACK);

			/* grid */
			ui_draw_vertical_line(x1,y1,y5,BLACK);
			ui_draw_vertical_line(x2,y1,y5,BLACK);
			ui_draw_vertical_line(x3,y1,y5,BLACK);
			ui_draw_vertical_line(x4,y1,y5,BLACK);
			ui_draw_vertical_line(x5,y1,y5,BLACK);

			ui_draw_horizontal_line(x5,x2,y1,BLACK);
			ui_draw_horizontal_line(x5,x2,y1+item_height,BLACK);
			for (i=2; i<nrow+2; i++) {
				iy = i*item_height+y1;
				if (i<nrow) {
					ui_draw_horizontal_line(x1,x5,iy,BLACK);
				} else {
					ui_draw_horizontal_line(x1,x2,iy,BLACK);
				}
			}

			/* up triangle */
			dx = 6; dy = 7;
			pt[0].x = x2-dx;		pt[0].y = y3-dy;
			pt[1].x = (x5+x2)/2;	pt[1].y = y1+dy;
			pt[2].x = x5+dx;		pt[2].y = y3-dy;
			ui_draw_polygon(3,pt,BLACK,BLACK);

			/* down triangle */
			pt[0].x = x2-dx;		pt[0].y = y4+dy;
			pt[1].x = x5+dx;		pt[1].y = y4+dy;
			pt[2].x = (x5+x2)/2;	pt[2].y = y5-dy;
			ui_draw_polygon(3,pt,BLACK,BLACK);
			
			/* handle bar */
			iy = (pl->pos+1)*item_height+y1;
			iy = min(y5-item_height*2,iy);
			ui_draw_filled_rectangle(x5+dx,iy+dy,x2-dx,iy+item_height-dy,BLACK,BLACK);
						
			/* list body */
			for (i=0; i<pl->nitems; i++) {
				const PARAMITEM* item = &pl->items[i];
				real_t value;
				int count;
				char str[32];
				
				if (i<pl->top||i>=nrow) {
					continue;
				}
				
				iy = (i-pl->top+1)*item_height+y1;
				
				/* block name */
				ui_draw_text_transparent(item->blockName,x1+5,iy+5,BLACK);
				
				/* signal name */
				ui_draw_text_transparent(item->signalName,x3+5,iy+5,BLACK);
				
				/* value */
				value = ReadValueFromBuddy(item->buddy,item->dataType);
				count = ConvR2S(value,str,10,3,0);
				ui_draw_text_transparent(str,x4+5,iy+5,BLACK);
			}
		}
	}

	/* draw tenkey */
	if (tk->base.visible) {
		if (type==NOTIFY_UPDATE) {
			Notify_tenkey(type,(CONTROL*)tk,param1,param2);
		}
	}

	return ecode;
}
