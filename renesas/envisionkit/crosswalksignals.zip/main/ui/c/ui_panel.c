/**
 * ui_panel.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <stdio.h>
#include <ui_vlx.h>
#include "model_ui.h"
#include "target_config.h"

#pragma warning(disable:4996)

static void UpdatePanel(PANEL* panel, void* param1, void* param2);
static void UpdateModalDialog(PANEL* panel, CONTROL* dlg, void* param1, void* param2);
static CONTROL* GetActiveModalDialog();

static char _touchpanel_info[64] = {0};

int Notify_panel(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	PANEL* panel = (PANEL*)me;
	CONTROL* dlg;
	
	//modal dialog
	dlg = GetActiveModalDialog();
	if (dlg) {
		if (type==NOTIFY_UPDATE) {
			if (panel->invalid) {
				UpdateModalDialog(panel,dlg,param1,param2);
				panel->invalid = 0;
			}
		} else {
			(dlg->notify)(type,dlg,param1,param2);
		}
		return ecode;
		/////////////
	}
	
	if (type==NOTIFY_UPDATE) {
		if (panel->invalid) {
			UpdatePanel(panel,param1,param2);
			panel->invalid = 0;
		}
	} else {
		CONTROL* control = panel->link;
		while (control) {
			if (control->notify && control->visible) {
				(control->notify)(type,control,param1,param2);
			}
			control = control->next;
		}
	}

#if (TARGET_DEBUG_MODE&TARGET_DEBUG_MODE_TOUCHPANEL_EVENT)
	if (type==NOTIFY_PRESSED||type==NOTIFY_RELEASED) {
		UIINPUT* uii = (UIINPUT*)param1;

		if (type==NOTIFY_PRESSED) {
			sprintf(_touchpanel_info,"pressed: x=%d, y=%d",uii->x,uii->y);
		} else
		if (type==NOTIFY_RELEASED) {
			sprintf(_touchpanel_info,"released: x=%d, y=%d",uii->x,uii->y);
		}
	}
#endif
	return ecode;
}

void UpdatePanel(PANEL* panel, void* param1, void* param2)
{
	CONTROL* control;

	if (panel->bgtype==2 && panel->image) {
		ui_draw_icon(panel->image,0,0);
	} else
	if (panel->bgtype==1) {
		ui_clear_framebuffer(panel->bgcolor);
	} else {
		ui_clear_framebuffer(WHITE);
	}
	control = panel->link;
	while (control) {
		if (control->notify && control->visible) {
			(control->notify)(NOTIFY_UPDATE,control,param1,param2);
		}
		control = control->next;
	}

#if (TARGET_DEBUG_MODE&TARGET_DEBUG_MODE_STEPPROCESS_TIME)
	/* step_process_time */
	if (IsMainPanel(panel)) {
		static char s[100];
		uint16 x,y,count,width;
		
		/* [YT20190420]change unit from nsec to usec and add display process time */
		int avg_step_process_time = StepProcessTimeNanosec(1)/1000;
		int max_step_process_time = StepProcessTimeNanosec(2)/1000;
		int display_process_time = StepProcessTimeNanosec(3)/1000;

		if (display_process_time>0) {
			count = sprintf(s,"%d/%d/%d",avg_step_process_time,max_step_process_time,display_process_time);
		} else {
			count = sprintf(s,"%d/%d",avg_step_process_time,max_step_process_time);
		}
		width = StringWidth(s);
		x = panel->width-width-5;
		y = panel->height-FontHeight();
		ui_draw_text_transparent(s,x,y,BLACK);
	}
#endif

#if (TARGET_DEBUG_MODE&TARGET_DEBUG_MODE_TOUCHPANEL_EVENT)
	{
		int x,y;
		x = 5;
		y = panel->height-FontHeight();
		ui_draw_text_transparent(_touchpanel_info,x,y,BLACK);
	}
#endif

	ui_switch_framebuffer();
}

void UpdateModalDialog(PANEL* panel, CONTROL* dlg, void* param1, void* param2)
{
	CONTROL* control;

	ui_clear_framebuffer(panel->bgcolor);	
	control = panel->link;
	while (control) {
		if (control->notify && control->visible) {
			(control->notify)(NOTIFY_UPDATE,control,param1,param2);
		}
		control = control->next;
	}
	(dlg->notify)(NOTIFY_UPDATE,dlg,param1,param2);
	ui_switch_framebuffer();
}

CONTROL* GetActiveModalDialog()
{
#if 0
	CONTROL* dlg = _modal_dialog_list;
	
	while (dlg) {
		if (dlg->visible) {
			return dlg;
		}
		dlg = dlg->next;
	}
#endif
	return 0;
}
