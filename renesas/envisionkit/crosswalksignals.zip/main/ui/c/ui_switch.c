/**
 * ui_switch.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>
	
int Notify_switch(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	SWITCH* sw = (SWITCH*)me;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	if (type==NOTIFY_INIT) {
		sw->status = sw->init;
		WriteValueToBuddy(sw->buddy,sw->dataType,sw->onvalue);
		if (sw->init==0) {
			WriteValueToBuddy(sw->buddy,sw->dataType,sw->offvalue);
		} else {
			WriteValueToBuddy(sw->buddy,sw->dataType,sw->onvalue);
		}
	} else	
	if (type==NOTIFY_PRESSED) {
		if (IsHit((CONTROL*)sw,x,y)) {
			if (sw->mode==0) {
				/* toggle */
				if (sw->status==0) {
					sw->status = 1;
					WriteValueToBuddy(sw->buddy,sw->dataType,sw->onvalue);
					InvalidateDisplay();
				} else {
					sw->status = 0;
					WriteValueToBuddy(sw->buddy,sw->dataType,sw->offvalue);
					InvalidateDisplay();
				}
			} else {
				/* momentary */
				if (sw->status==0) {
					sw->status = 1;
					WriteValueToBuddy(sw->buddy,sw->dataType,sw->onvalue);
					InvalidateDisplay();
				}
			}
		}
	} else
	if (type==NOTIFY_RELEASED) {
		if (sw->mode==0) {
			/* toggle */
			/* do nothing */
		} else {
			/* momentary */
			if (sw->status) {
				sw->status = 0;
				WriteValueToBuddy(sw->buddy,sw->dataType,sw->offvalue);
				InvalidateDisplay();
			}
		}
	} else	
	if (type==NOTIFY_UPDATE) {
		if (sw->base.visible) {
			if (sw->status>0) {
				ui_draw_icon(sw->onimage,sw->base.left,sw->base.top);
			} else {
				ui_draw_icon(sw->offimage,sw->base.left,sw->base.top);
			}
		}
	}
	return ecode;
}
