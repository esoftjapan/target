/**
 * ui_trendgraph.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT		created
 * 2019/04/22		YT		ui_draw_filled_rectangle_direct() and ui_plot_trace()
 */

#include <stdio.h>
#include <math.h>
#include "ui_vlx.h"
#include "qmath.h"

extern real_t __stepTime;

#pragma warning(disable:4996)

/* graph style */
#define	STYLE_TRENDGRAPH		0
#define	STYLE_STRIPCHART		1

/* sacling mode */
#define	SCALEMODE_NORMAL		0
#define	SCALEMODE_AUTO			1
#define	SCALEMODE_MANUAL		2

/* trigger mode */
#define TRIGGERMODE_FREERUN		0
#define	TRIGGERMODE_SINGLE		1
#define	TRIGGERMODE_REPEAT		2

/* trigger setup dialog */
#define	TRIGGERSETUP_VISIBLE	0x01
#define	TRIGGERLEVEL_ITEM		1
#define	TRIGGERPOSITION_ITEM	2
#define	TRIGGERCHANNEL_ITEM		3
#define	TRIGGERSLOPE_ITEM		4
#define	REPEATPERIOD_ITEM		5
#define	SCALEMODE_ITEM			6

/* trigger statemachine */
#define	TSTATE_FREERUN			0
#define	TSTATE_DETECTED			1
#define	TSTATE_DELAYED			2
#define	TSTATE_HOLD				3

static void Plot(TRENDGRAPH* tg);
static int TriggerSetupDialogNotify(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);


int Notify_trendgraph(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	TRENDGRAPH* tg = (TRENDGRAPH*)me;
	TENKEY* tk = tg->tenkey;

	int MENU_WIDTH = tg->menu_width;
	int MENU_HEIGHT = tg->menu_height;
	
	if (type==NOTIFY_INIT) {
		int ch,k;

		tg->wp = 0;
		tg->rp = 0;
		tg->statemachine = TSTATE_FREERUN;
		tg->trigger_delay = 0;
		tg->cursor_pos = tg->x1;

		if (tg->trigger_slope==0) {
			tg->prev_value = tg->trigger_level-1;
		} else {
			tg->prev_value = tg->trigger_level+1;
		}
		
		for (ch=0; ch<tg->nchannels; ch++) {
			for (k=0; k<tg->ringbufsize; k++) {
				tg->ringbuf[ch][k] = 0;
			}
			for (k=0; k<tg->plotsize; k++) {
				tg->xbuf[ch][k] = 0;
				tg->ybuf[ch][k] = 0;
			}
			tg->ymin[ch] = (real_t)(-1.0);
			tg->ymax[ch] = (real_t)1.0;
			tg->sf[ch] = 1;			
		}

		/* init tenkey */
		Notify_tenkey(type,(CONTROL*)tk,param1,param2);

	} else
	if (type==NOTIFY_WRITERINGBUF) {
		/**
		 * CAUTION:
		 * This is called from model.c, which can run in a different thread
		 */
		uint16 ch;
		real_t value;
		real_t t = GetModelTime();
		int decr = tg->decr;

		if (param1==0) {
			FatalError(__FILE__,__LINE__,"trendgraph:NOTIFY_WRITERINGBUF");
			return -1;
		}
		value = *(real_t*)param1;
		ch = (int)param2;
		
		/* write data in the ring buffer */
		tg->ringbuf[ch][tg->wp] = value;

		/* detecting trigger */
		if (tg->trigger_mode>0) {
			if (tg->trigger_ch==ch) {
				if (tg->statemachine==TSTATE_FREERUN) {
					if (tg->trigger_slope==0) {
						/* + slope */
						if (tg->prev_value<tg->trigger_level && tg->trigger_level<=value) {
							tg->trigger_delay = (uint16)(tg->plotsize*(1.0-tg->trigger_pos*0.01));
							tg->repeat_count = tg->repeat_period*tg->decr;
							tg->statemachine = TSTATE_DETECTED;
						}
					} else {
						/* - slope */
						if (tg->prev_value>tg->trigger_level && tg->trigger_level>=value) {
							tg->trigger_delay = (uint16)(tg->plotsize*(1.0-tg->trigger_pos*0.01));
							tg->repeat_count = tg->repeat_period*tg->decr;
							tg->statemachine = TSTATE_DETECTED;
						}
					}
				}
				/* set previsou value for detecting slope */
				tg->prev_value = value;

				/* trigger delay */
				if (tg->statemachine==TSTATE_DETECTED) {
					if (tg->trigger_delay--<=0) {
						tg->rp = tg->wp-tg->plotsize;
						if (tg->rp<0) {
							tg->rp += tg->ringbufsize;
						}
						tg->xmax_hold = t;
						tg->statemachine = TSTATE_DELAYED;
					}
				}
			}
		}

		if (ch==tg->nchannels-1) {
			/* last channel */
			tg->wp = (tg->wp+1)%tg->ringbufsize;
		}
	} else
	if (type==NOTIFY_PRESSED) {
		UIRECT rc;
		UIINPUT* uii = (UIINPUT*)param1;
		uint16 x = uii?uii->x:0;
		uint16 y = uii?uii->y:0;
		uint16 i;
		uint8 legend_hit = 0;

		/* menu */
		rc.left = tg->base.right-MENU_WIDTH;
		rc.right = tg->base.right;

		for (i=0; i<10; i++) {
			rc.top = tg->base.top+i*MENU_HEIGHT;
			rc.bottom = rc.top+MENU_HEIGHT;
			if (IsHitRect(&rc,x,y)) {
				break;
			}
		}
		if (i==0) {
			/* hold */
			if (tg->statemachine!=TSTATE_HOLD) {
				real_t t,xmin,xspan;
				int ch,k;

				t = GetModelTime();
				tg->xmax_hold = t;
				xspan = tg->plotsize*tg->xdelta;
				xmin = t-xspan;
				for (k=0; k<tg->plotsize; k++) {
					real_t x = xmin+k*tg->xdelta;
					for (ch=0; ch<tg->nchannels; ch++) {
						tg->xbuf[ch][k] = x;
					}
				}

				tg->statemachine = TSTATE_HOLD;

			} else {
				tg->statemachine = TSTATE_FREERUN;
			}
		} else
		if (i==1) {
			/* cursor */
			tg->cursor_on = (tg->cursor_on+1)%2;
		} else
		if (i==2) {
			/* style */
			tg->style =(tg->style+1)%2;
		} else
		if (i==3) {
			/* trigger mode */
			tg->trigger_mode = (tg->trigger_mode+1)%3;
			if (tg->trigger_mode==TRIGGERMODE_FREERUN||tg->trigger_mode==TRIGGERMODE_REPEAT) {
				tg->statemachine = TSTATE_FREERUN;
			}
		} else
		if (i==4) {
			/* trigger setup dialog */
			if (tg->status&TRIGGERSETUP_VISIBLE) {
				TENKEY* tk = tg->tenkey;
				tk->base.visible = 0;
				tg->status = 0;
			} else {
				tg->status = TRIGGERSETUP_VISIBLE;
			}
		}

		/* legend */
		if (tg->style==STYLE_TRENDGRAPH) {
			uint16 ch,ix1,iy1,iy;
			UIRECT rc;
			uint16 font_height = FontHeight();

			ix1 = tg->x1;
			iy1 = tg->y1;
			for (ch=0; ch<tg->nchannels; ch++) {
				iy = ch*font_height+iy1;
				rc.left = ix1; rc.right=ix1+20;
				rc.top = iy; rc.bottom = rc.top+font_height;
				if (IsHitRect(&rc,x,y)) {
					/* toggle trace visible */
					tg->visible[ch] = tg->visible[ch]>0? 0:1;
					legend_hit = 1;
					break;
				}
			}
		} else {
			/* legend of stripchart is always visible */
		}

		/* cursor move */
		if (tg->cursor_on) {
			rc.left = tg->x1;
			rc.top = tg->y1;
			rc.right = tg->x2;
			rc.bottom = tg->y2;
			if (IsHitRect(&rc,x,y) && legend_hit==0) {
				tg->cursor_pos = x;
			}
		}
	} else
	if (type==NOTIFY_UPDATE) {
		if (tg->base.visible) {
			/* plot traces */
			Plot(tg);
			
			/* menu */
			if (tg->statemachine==TSTATE_HOLD) {
				ui_draw_icon(tg->menu_hold_on,tg->base.right-MENU_WIDTH,tg->base.top);
			} else {
				ui_draw_icon(tg->menu_hold_off,tg->base.right-MENU_WIDTH,tg->base.top);
			}

			if (tg->cursor_on) {
				ui_draw_icon(tg->menu_cursor_on,tg->base.right-MENU_WIDTH,tg->base.top+MENU_HEIGHT);
			} else {
				ui_draw_icon(tg->menu_cursor_off,tg->base.right-MENU_WIDTH,tg->base.top+MENU_HEIGHT);
			}

			if (tg->style) {
				ui_draw_icon(tg->menu_style_stripchart,tg->base.right-MENU_WIDTH,tg->base.top+MENU_HEIGHT*2);
			} else {
				ui_draw_icon(tg->menu_style_trendgraph,tg->base.right-MENU_WIDTH,tg->base.top+MENU_HEIGHT*2);
			}

			if (tg->trigger_mode==0) {
				ui_draw_icon(tg->menu_freerun,tg->base.right-MENU_WIDTH,tg->base.top+MENU_HEIGHT*3);
			} else
			if (tg->trigger_mode==1) {
				ui_draw_icon(tg->menu_single,tg->base.right-MENU_WIDTH,tg->base.top+MENU_HEIGHT*3);
			} else {
				ui_draw_icon(tg->menu_repeat,tg->base.right-MENU_WIDTH,tg->base.top+MENU_HEIGHT*3);
			}

			/* trigger setup dialog */
			ui_draw_icon(tg->menu_trigger_mode,tg->base.right-MENU_WIDTH,tg->base.top+MENU_HEIGHT*4);

			/* edge */
			ui_draw_rectangle(tg->base.left,tg->base.top,tg->base.right,tg->base.bottom,tg->edgecolor);
		}
	}

	if (tg->status&TRIGGERSETUP_VISIBLE) {
		TriggerSetupDialogNotify(type,me,param1,param2);
	}

	return ecode;
}

void Plot(TRENDGRAPH* tg)
{
	int ch,rp_init;
	int hold_request;
	uint16 font_height = FontHeight();
	real_t xspan,xmin,xmax;
	real_t xslope,yslope;
	real_t t = GetModelTime();
	
	/**
	 * initial read pointer
	 * IMPORTANT:
	 *	the statemachine will be changed in the model thread.
	 *	hold_request flag is required to maintain consistency.
	 */
	hold_request = 0;
	if (tg->statemachine==TSTATE_DELAYED) {
		rp_init = tg->rp;
		hold_request = 1;
	} else {
		rp_init = tg->wp-tg->plotsize;
	}
	if (rp_init<0) {
		rp_init += tg->ringbufsize;
	}
	
	/* x-axis scaling */
	xspan = tg->plotsize*tg->xdelta;
	if (tg->statemachine==TSTATE_DELAYED||tg->statemachine==TSTATE_HOLD) {
		xmax = tg->xmax_hold;
		xmin = xmax-xspan;
	} else {
		if (t<xspan) {
			xmax = xspan;
			xmin = 0;
		} else {
			xmax = t;
			xmin = xmax-xspan;
		}
	}
	xslope = (tg->x2-tg->x1)/xspan;
	
	/* y-axis scaling */
	for (ch=0; ch<tg->nchannels; ch++) {
		int rp,k;
		real_t ymin,ymax;

		if (tg->visible[ch]==0) {
			continue;
		}

		/* auto scaling */
		ymin = (real_t)1e20;
		ymax = (real_t)(-1e20);
		rp = rp_init;
		for (k=0; k<tg->plotsize; k++) {
			real_t y;
			
			if (tg->statemachine==TSTATE_DELAYED||tg->statemachine==TSTATE_HOLD) {
				y = tg->ybuf[ch][k];
			} else {
				y = tg->ringbuf[ch][rp];
			}

			if (y<ymin) {
				ymin = y;
			}
			if (y>ymax) {
				ymax = y;
			}
			
			rp = (rp+1)%tg->ringbufsize;
		}
		
		if (ymax-ymin<(real_t)1e-9) {
			tg->ymin[ch] = (real_t)(-1.0);
			tg->ymax[ch] = (real_t)1.0;
			tg->sf[ch] = 1;
		} else {
			ymin = RoundDown125(ymin,NULL);
			ymax = RoundUp125(ymax,NULL);
			tg->ymin[ch] = ymin;
			tg->ymax[ch] = ymax;
			tg->sf[ch] = 1;
		}

		if (tg->scale_mode==0) {
			/* normal scaling */
			real_t z,sf;
			
			z = max(__fabs(ymin),__fabs(ymax));
			if (z<1e-9) {
				sf = 1;
			} else {
				real_t n;
				n = __ceil(__log10(z));
				sf = __pow((real_t)10.0,n);
			}

			tg->sf[ch] = sf;
			tg->ymin[ch] = (real_t)-1;
			tg->ymax[ch] = (real_t)+1;
		}
	}
	
	/* grid and legend */
	if (tg->style==STYLE_TRENDGRAPH) {
		/* trendgraph */
		uint16 ix1,ix2,iy1,iy2,nx,ny,d,i;
		real_t xmajor,ymajor;

		/* xaxis grid */
		nx = tg->xaxis_divide;
		xmajor = (real_t)1.0*(tg->x2-tg->x1)/nx;
		iy1 = tg->y1;
		iy2 = tg->y2;
		for (i=0; i<nx; i++) {
			ix1 = (uint16)(i*xmajor+tg->x1);
			ui_draw_vertical_line(ix1,iy1,iy2,tg->gridcolor);
		}
		ui_draw_vertical_line(tg->x2,iy1,iy2,tg->gridcolor);

		/* yaxis grid */
		ny = tg->yaxis_divide;
		ymajor = (real_t)1.0*(tg->y2-tg->y1)/ny;
		ix1 = tg->x1;
		ix2 = tg->x2;
		for (i=0; i<ny; i++) {
			iy1 = (uint16)(i*ymajor+tg->y1);
			ui_draw_horizontal_line(ix1,ix2,iy1,tg->gridcolor);
		}
		ui_draw_horizontal_line(ix1,ix2,tg->y2,tg->gridcolor);

		yslope = (tg->y1-tg->y2)/(tg->ymax[ch]-tg->ymin[ch]);

		/* trigger marker */
		if (tg->trigger_mode>0) {
			int ix,iy,k;
			real_t x,y;

			k = (int)(tg->plotsize*tg->trigger_pos*0.01);
			x = xmin+k*tg->xdelta;
			y = tg->trigger_level;
			ix = (int16)((x-xmin)*xslope+tg->x1);
			iy = (int16)((y-tg->ymin[tg->trigger_ch])*yslope+tg->y2);
			ix = max(tg->x1,min(ix,tg->x2));
			iy = max(tg->y1,min(iy,tg->y2));

			ui_draw_horizontal_line(tg->x1,tg->x2,iy,BLACK);
			ui_draw_vertical_line(ix,tg->y1,tg->y2,BLACK);
		}

		/* legend */
		ix1 = tg->x1;
		iy1 = tg->y1;
		d = font_height-2;
		for (ch=0; ch<tg->nchannels; ch++) {
			char s1[64],s2[64];
			real_t ymin,ymax;
			int iy = ch*font_height+iy1;

			ymin = tg->ymin[ch];
			ymax = tg->ymax[ch];
			if (tg->scale_mode==0) {
				/* normal scale mode */
				real_t sf = tg->sf[ch];
				ymin *= sf;
				ymax *= sf;
			}

//			snprintf(s1,64,"CH%d:%s(%f,%f)",ch+1,tg->legend[ch],ymin,ymax);

			StringCopy(s1,"CH",64);
			i2s(ch+1,s2,64,0);
			StringAppend(s1,s2,64);
			StringAppend(s1,":",64);
			StringAppend(s1,tg->legend[ch],64);
			StringAppend(s1,"(",64);

			ConvR2S(ymin,s2,32,1,0);
			StringAppend(s1,s2,64);
			StringAppend(s1,",",64);
			ConvR2S(ymax,s2,32,1,0);
			StringAppend(s1,s2,64);
			StringAppend(s1,")",64);

			if (tg->visible[ch]) {
				ui_draw_filled_rectangle(ix1,iy,ix1+d,iy+d,tg->tracecolor[ch],BLACK);
				ui_draw_text_transparent(s1,ix1+d+5,iy,BLACK);
			} else {
				ui_draw_filled_rectangle(ix1,iy,ix1+d,iy+d,LIGHTGRAY,BLACK);
				ui_draw_text_transparent(s1,ix1+d+5,iy,LIGHTGRAY);
			}
		}
	} else {
		/* stripchart */
		real_t chart_height = (real_t)1.0*(tg->y2-tg->y1)/tg->nchannels;

		/* grid and legend */
		for (ch=0; ch<tg->nchannels; ch++) {
			uint16 ytop,ybottom;
			uint16 ix1,ix2,iy1,iy2,nx,ny,k;
			real_t xmajor,ymajor;

			ytop = (uint16)(ch*chart_height+tg->y1);
			ybottom = (uint16)(ytop+chart_height);
			yslope = (ytop-ybottom)/(tg->ymax[ch]-tg->ymin[ch]);

			/* xaxis grid */
			nx = tg->xaxis_divide;
			xmajor = (real_t)1.0*(tg->x2-tg->x1)/nx;
			iy1 = ytop;
			iy2 = ybottom;
			for (k=0; k<nx; k++) {
				ix1 = (uint16)(k*xmajor+tg->x1);
				ui_draw_vertical_line(ix1,iy1,iy2,tg->gridcolor);
			}
			ui_draw_vertical_line(tg->x2,iy1,iy2,tg->gridcolor);

			/* yaxis grid */
			ny = tg->yaxis_divide;
			ymajor = (real_t)1.0*(ybottom-ytop)/ny;
			ix1 = tg->x1;
			ix2 = tg->x2;
			for (k=0; k<ny; k++) {
				iy1 = (uint16)(k*ymajor+ytop);
				ui_draw_horizontal_line(ix1,ix2,iy1,tg->gridcolor);
			}

			/* trigger marker */
			if (tg->trigger_mode>0 && tg->trigger_ch==ch) {
				int ix,iy,k;
				real_t x,y;

				k = (int)(0.01*tg->trigger_pos*tg->plotsize);
				x = xmin+k*tg->xdelta;
				y = tg->trigger_level;
				ix = (int16)((x-xmin)*xslope+tg->x1);
				iy = (int16)((y-tg->ymin[ch])*yslope+ybottom);
				ix = max(tg->x1,min(ix,tg->x2));
				iy = max(tg->y1,min(iy,ybottom));

				ui_draw_horizontal_line(tg->x1,tg->x2,iy,BLACK);
				ui_draw_vertical_line(ix,ytop,ybottom,BLACK);
			}

			/* legend */
			{
				char s1[64],s2[64];
				real_t ymin,ymax;

				ymin = tg->ymin[ch];
				ymax = tg->ymax[ch];
				if (tg->scale_mode==0) {
					/* normal scale mode */
					real_t sf = tg->sf[ch];
					ymin *= sf;
					ymax *= sf;
				}
//				snprintf(s1,64,"CH%d:%s(%f,%f)",ch+1,tg->legend[ch],ymin,ymax);
				StringCopy(s1,"CH",64);
				i2s(ch+1,s2,64,0);
				StringAppend(s1,s2,64);
				StringAppend(s1,":",64);
				StringAppend(s1,tg->legend[ch],64);
				StringAppend(s1,"(",64);

				ConvR2S(ymin,s2,32,1,0);
				StringAppend(s1,s2,64);
				StringAppend(s1,",",64);
				ConvR2S(ymax,s2,32,1,0);
				StringAppend(s1,s2,64);
				StringAppend(s1,")",64);

				ui_draw_text_transparent(s1,tg->x1,ytop,BLACK);
			}
		}
		ui_draw_horizontal_line(tg->x1,tg->x2,tg->y2,tg->gridcolor);
	}
	
	/* x-axis scale annotation */
	{
		int cx;
		char annot[32];
		
		ConvR2S(xmin,annot,6,3,0);
		ui_draw_text_transparent(annot,tg->x1,tg->y2,BLACK);

		ConvR2S(xmax,annot,6,3,0);
		cx = StringWidth(annot);
		ui_draw_text_transparent(annot,tg->x2-cx,tg->y2,BLACK);
	}
	
	//setup plot data
	if (tg->statemachine==TSTATE_HOLD) {
		/* hold mode */
		if (tg->trigger_mode==2) {
			if (--tg->repeat_count<=0) {
				/* reset hold */
				tg->statemachine = TSTATE_FREERUN;
			}
		}
	} else {
		/* update plot data */
		for (ch=0; ch<tg->nchannels; ch++) {
			int rp,k;
				
			rp = rp_init;
			for (k=0; k<tg->plotsize; k++) {
				real_t x,y;
					
				x = xmin+k*tg->xdelta;
				y = tg->ringbuf[ch][rp];
				tg->xbuf[ch][k] = x;
				tg->ybuf[ch][k] = y;

				rp = (rp+1)%tg->ringbufsize;
			}
		}
	}

	//plot traces
	if (tg->style==STYLE_TRENDGRAPH) {
		/* trend graph */
		for (ch=0; ch<tg->nchannels; ch++) {		
			int k;
			real_t sf = tg->scale_mode==0?tg->sf[ch]:1;

			if (tg->visible[ch]==0) {
				continue;
			}
			
			ui_plot_trace(tg->plotsize,tg->x1,tg->x2,tg->y1,tg->y2,xmin,xmax,tg->ymin[ch],tg->ymax[ch],tg->xbuf[ch],tg->ybuf[ch],sf,tg->tracecolor[ch]);

			if (tg->cursor_on) {
				char s1[32];
				int ix,iy;
				real_t x,y;
				uint16 dx = 5;
				uint16 dy = FontHeight()/2;

				yslope = (tg->y1-tg->y2)/((tg->ymax[ch]-tg->ymin[ch])*sf);
				k = tg->plotsize*(tg->cursor_pos-tg->x1)/(tg->x2-tg->x1);
				x = tg->xbuf[ch][k];
				y = tg->ybuf[ch][k];
				ix = tg->cursor_pos;
				iy = (int16)((y-tg->ymin[ch]*sf)*yslope+tg->y2);

				ConvR2S(y,s1,32,3,0);
//				ui_draw_text_transparent(s1,LIMITWIDTH(ix+dx),LIMITHEIGHT(iy-dy),BLACK);
				ui_draw_text(s1,LIMITWIDTH(ix+dx),LIMITHEIGHT(iy-dy),BLACK,WHITE);
				ui_draw_filled_rectangle(LIMITWIDTH(ix-2),LIMITHEIGHT(iy-2),LIMITWIDTH(ix+2),LIMITHEIGHT(iy+2),tg->tracecolor[ch],BLACK);

			}
		}
		/* x value at cursor */
		if (tg->cursor_on) {
			char s1[32];
			int ix,iy,k;
			real_t x;
			uint16 dx = 5;
			uint16 dy = FontHeight()/2;

			k = tg->plotsize*(tg->cursor_pos-tg->x1)/(tg->x2-tg->x1);
			x = tg->xbuf[0][k];
			ix = tg->cursor_pos;
			iy = tg->y2;

			ConvR2S(x,s1,32,3,0);
//			ui_draw_text_transparent(s1,LIMITWIDTH(ix+dx),LIMITHEIGHT(iy+dy),BLACK);
			ui_draw_text(s1,LIMITWIDTH(ix+dx),LIMITHEIGHT(iy+dy),BLACK,WHITE);
			ui_draw_filled_rectangle(LIMITWIDTH(ix-2),LIMITHEIGHT(iy-2),LIMITWIDTH(ix+2),LIMITHEIGHT(iy+2),BLACK,BLACK);

		}
	} else {
		/* strip  chart */
		real_t chart_height = (real_t)1.0*(tg->y2-tg->y1)/tg->nchannels;

		for (ch=0; ch<tg->nchannels; ch++) {
			int k;
			uint16 ytop,ybottom;
			real_t sf = tg->scale_mode==0?tg->sf[ch]:1;

			if (tg->visible[ch]==0) {
				continue;
			}

			ytop = (uint16)(ch*chart_height+tg->y1);
			ybottom = (uint16)(ytop+chart_height);
			ui_plot_trace(tg->plotsize,tg->x1,tg->x2,ytop,ybottom,xmin,xmax,tg->ymin[ch],tg->ymax[ch],tg->xbuf[ch],tg->ybuf[ch],sf,tg->tracecolor[ch]);

			if (tg->cursor_on) {
				char s1[32];
				uint16 ix,iy;
				real_t x,y;
				uint16 dx = 5;
				uint16 dy = FontHeight()/2;

				yslope = (ytop-ybottom)/((tg->ymax[ch]-tg->ymin[ch])*sf);
				k = tg->plotsize*(tg->cursor_pos-tg->x1)/(tg->x2-tg->x1);
				x = tg->xbuf[ch][k];
				y = tg->ybuf[ch][k];
				ix = tg->cursor_pos;
				iy  = (int16)((y-tg->ymin[ch]*sf)*yslope+ybottom);

				ConvR2S(y,s1,32,3,0);
//				ui_draw_text_transparent(s1,LIMITWIDTH(ix+dx),LIMITHEIGHT(iy-dy),BLACK);
				ui_draw_text(s1,LIMITWIDTH(ix+dx),LIMITHEIGHT(iy-dy),BLACK,WHITE);
				ui_draw_filled_rectangle(LIMITWIDTH(ix-2),LIMITHEIGHT(iy-2),LIMITWIDTH(ix+2),LIMITHEIGHT(iy+2),tg->tracecolor[ch],BLACK);
			}
		}

		/* x value at cursor */
		if (tg->cursor_on) {
			char s1[32];
			int ix,iy,k;
			real_t x;
			uint16 dx = 5;
			uint16 dy = FontHeight()/2;

			k = tg->plotsize*(tg->cursor_pos-tg->x1)/(tg->x2-tg->x1);
			x = tg->xbuf[0][k];
			ix = tg->cursor_pos;
			iy = tg->y2;

			ConvR2S(x,s1,32,3,0);
//			ui_draw_text_transparent(s1,LIMITWIDTH(ix+dx),LIMITHEIGHT(iy+dy),BLACK);
			ui_draw_text(s1,LIMITWIDTH(ix+dx),LIMITHEIGHT(iy+dy),BLACK,WHITE);
			ui_draw_filled_rectangle(LIMITWIDTH(ix-2),LIMITHEIGHT(iy-2),LIMITWIDTH(ix+2),LIMITHEIGHT(iy+2),BLACK,BLACK);
		}
	}
	
	/* next state */
	if (hold_request) {
		tg->statemachine = TSTATE_HOLD;
	}
}


/**
 *  x1                  x3       x2
 *  ------------------------------- y1
 *	Trigger Settings            [X]
 *  -------------------------------
 *	trigger level		0.0
 *	trigger position	50.0
 *	trigger channel		0
 *	trigger slope		+/-
 *	repeat period		10
 *	scale mode			auto
 *	decimation inc.		decr
 *	decimation dec.		decr
 *  ------------------------------- y2
 *
 */
int TriggerSetupDialogNotify(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	TRENDGRAPH* tg = (TRENDGRAPH*)me;
	TENKEY* tk = tg->tenkey;
	uint16 x1,y1,x2,y2,x3,height;
	height = 20;
	x1 = 0;
	y1 = 0;
	x3 = x1+150;
	x2 = x3+100;
	y2 = y1+height*9;

	if (type==NOTIFY_UPDATE) {
		uint16 count,y,w,d;
		char str[64];
		
		d = 3;

		//erase background */
		if (ui_is_using_framebuffer()) {
			ui_draw_filled_rectangle_direct(x1,y1,x2,y2,0xff,BLACK);
		} else {
			ui_draw_filled_rectangle(x1,y1,x2,y2,WHITE,BLACK);
		}
		
		/* title */
		ui_draw_text_transparent("Trigger Settings",x1+d,y1+d,BLACK);
		w = StringWidth("[X]");
		ui_draw_text_transparent("[X]",x2-w,y1+d,BLACK);

		/* trigger level */
		y = y1+height;
		ui_draw_horizontal_line(x1,x2,y,GRAY);
		count = ConvR2S(tg->trigger_level,str,8,3,0);
		ui_draw_text_transparent("Trigger Level:",x1+d,y+d,BLACK);
		ui_draw_text_transparent(str,x3,y+d,BLACK);

		/* trigger position */
		y = y1+height*2;
		ui_draw_horizontal_line(x1,x2,y,GRAY);
		count = ConvR2S(tg->trigger_pos,str,6,1,0);
		ui_draw_text_transparent("Trigger Position[%]:",x1+d,y+d,BLACK);
		ui_draw_text_transparent(str,x3,y+d,BLACK);

		/* trigger channel */
		y = y1+height*3;
		ui_draw_horizontal_line(x1,x2,y,GRAY);
		count = i2s(tg->trigger_ch+1,str,3,0);
		ui_draw_text_transparent("Trigger Channel:",x1+d,y+d,BLACK);
		ui_draw_text_transparent(str,x3,y+d,BLACK);

		/* trigger slope */
		y = y1+height*4;
		ui_draw_horizontal_line(x1,x2,y,GRAY);
		ui_draw_text_transparent("Trigger Slope:",x1+d,y+d,BLACK);
		if (tg->trigger_slope==0) {
			ui_draw_text_transparent("+",x3,y+d,BLACK);
		} else {
			ui_draw_text_transparent("-",x3,y+d,BLACK);
		}

		/* repeat period */
		y = y1+height*5;
		ui_draw_horizontal_line(x1,x2,y,GRAY);
		count = i2s(tg->repeat_period,str,6,0);
		ui_draw_text_transparent("Repeat Period:",x1+d,y+d,BLACK);
		ui_draw_text_transparent(str,x3,y+d,BLACK);

		/* scale mode */
		y = y1+height*6;
		ui_draw_horizontal_line(x1,x2,y,GRAY);
		ui_draw_text_transparent("Scale Mode:",x1+d,y+d,BLACK);
		if (tg->scale_mode==0) {
			ui_draw_text_transparent("normal",x3,y+d,BLACK);
		} else {
			ui_draw_text_transparent("auto",x3,y+d,BLACK);
		}

		/* decimation up */
		y = y1+height*7;
		ui_draw_horizontal_line(x1,x2,y,GRAY);
		count = i2s(tg->decr,str,6,0);
		ui_draw_text_transparent("Decimation up:",x1+d,y+d,BLACK);
		ui_draw_text_transparent(str,x3,y+d,BLACK);

		/* decimation down */
		y = y1+height*8;
		ui_draw_horizontal_line(x1,x2,y,GRAY);
		count = i2s(tg->decr,str,6,0);
		ui_draw_text_transparent("Decimation down:",x1+d,y+d,BLACK);
		ui_draw_text_transparent(str,x3,y+d,BLACK);

	} else
	if (type==NOTIFY_PRESSED) {
		UIINPUT* uii = (UIINPUT*)param1;
		uint16 x = uii?uii->x:0;
		uint16 y = uii?uii->y:0;
		UIRECT rc;

		/* close button */
		rc.left = x2-20; rc.right = x2; rc.top = y1; rc.bottom = y1+height;
		if (IsHitRect(&rc,x,y)) {
			tk->base.visible = 0;
			tg->status = 0;
			goto Lexit;
		}

		/* tenkey is first */
		if (tk->base.visible) {
			goto Lexit;
		}

		/* find item of trigger setup dialog */
		rc.left = x1; rc.right = x2; rc.top = y1+height; rc.bottom = rc.top+height;
		if (IsHitRect(&rc,x,y)) {
			tg->status = (int8)((TRIGGERLEVEL_ITEM<<4)+TRIGGERSETUP_VISIBLE);
			ConvR2S(tg->trigger_level,tk->numberdisplay->value,9,3,0);
			tk->base.visible = 1;
			return 0;
		}
		rc.left = x1; rc.right = x2; rc.top = y1+height*2; rc.bottom = rc.top+height;
		if (IsHitRect(&rc,x,y)) {
			tg->status = (int8)((TRIGGERPOSITION_ITEM<<4)+TRIGGERSETUP_VISIBLE);
			ConvR2S(tg->trigger_pos,tk->numberdisplay->value,6,2,0);
			tk->base.visible = 1;
			return 0;
		}
		rc.left = x1; rc.right = x2; rc.top = y1+height*3; rc.bottom = rc.top+height;
		if (IsHitRect(&rc,x,y)) {
			tg->status = (int8)((TRIGGERCHANNEL_ITEM<<4)+TRIGGERSETUP_VISIBLE);
			i2s(tg->trigger_ch+1,tk->numberdisplay->value,2,0);
			tk->base.visible = 1;
			return 0;
		}
		rc.left = x1; rc.right = x2; rc.top = y1+height*4; rc.bottom = rc.top+height;
		if (IsHitRect(&rc,x,y)) {
			tg->status = (int8)((TRIGGERSLOPE_ITEM<<4)+TRIGGERSETUP_VISIBLE);
			tg->trigger_slope = tg->trigger_slope==0? 1:0;
			return 0;
		}
		rc.left = x1; rc.right = x2; rc.top = y1+height*5; rc.bottom = rc.top+height;
		if (IsHitRect(&rc,x,y)) {
			tg->status = (int8)((REPEATPERIOD_ITEM<<4)+TRIGGERSETUP_VISIBLE);
			i2s(tg->repeat_period,tk->numberdisplay->value,6,0);
			tk->base.visible = 1;
			return 0;
		}
		rc.left = x1; rc.right = x2; rc.top = y1+height*6; rc.bottom = rc.top+height;
		if (IsHitRect(&rc,x,y)) {
			tg->status = (int8)((TRIGGERSLOPE_ITEM<<4)+TRIGGERSETUP_VISIBLE);
			//toggle scale mode
			tg->scale_mode = tg->scale_mode==0?1:0;
			return 0;
		}
		rc.left = x1; rc.right = x2; rc.top = y1+height*7; rc.bottom = rc.top+height;
		if (IsHitRect(&rc,x,y)) {
			tg->status = (int8)((TRIGGERSLOPE_ITEM<<4)+TRIGGERSETUP_VISIBLE);
			tg->decr = tg->decr+1;
			tg->xdelta = __stepTime*tg->decr;
			return 0;
		}
		rc.left = x1; rc.right = x2; rc.top = y1+height*8; rc.bottom = rc.top+height;
		if (IsHitRect(&rc,x,y)) {
			tg->status = (int8)((TRIGGERSLOPE_ITEM<<4)+TRIGGERSETUP_VISIBLE);
			tg->decr = max(1,tg->decr-1);
			tg->xdelta = __stepTime*tg->decr;
			return 0;
		}


	} else
	if (type==NOTIFY_ACTION) {
		/* calling from tenkey */
		TENKEY* tk1 = (TENKEY*)param1;
		if (tk1==tk) {
			char *str = (char*)param2;
			int8 item = tg->status>>4;
			if (item==1) {
				/* trigger level */
				real_t value = ConvS2R(str);
				tg->trigger_level = value;
			} else
			if (item==2) {
				/* trigger position */
				real_t value = ConvS2R(str);
				tg->trigger_pos = max(0,min(100,value));
			} else
			if (item==3) {
				/* trigger channel */
				int value = s2i(str);
				tg->trigger_ch = max(0,min(7,value-1));
			} else
			if (item==4) {
				/* trigger slope : no tenkey */
			} else
			if (item==5) {
				/* repeat period */
				int value = s2i(str);
				tg->repeat_period = max(0,value);
			} else
			if (item==6) {
				/* scale mode : no tenkey */
			}
		}
	}
	
Lexit:
	/* tenkey */
	if (tk->base.visible) {
		Notify_tenkey(type,(CONTROL*)tk,param1,param2);
	}
	return ecode;
}
