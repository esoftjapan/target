/**
 * ui_message.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>

extern int _active_panel;
extern int _previous_panel;
extern int _enable_buzzer;
extern PANEL* _panels[];

int Notify_message(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	MESSAGE* m = (MESSAGE*)me;

	if (type==NOTIFY_UPDATE) {
		if (m->base.visible) {
			ui_draw_icon(m->tga,m->base.left,m->base.top);
		}
	}
	return ecode;
}

int Notify_messagebox(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	MESSAGEBOX* mb = (MESSAGEBOX*)me;
	static int8 warning = 0;
	
	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	if (mb->base.visible==0) {
		return 0;
	}
	
	if (type==NOTIFY_PRESSED) {
		//modal dialog
		if (IsHit((CONTROL*)mb,x,y)) {
			if (x>mb->ok_left && x<mb->ok_right && y>mb->ok_top && y<mb->ok_bottom) {
				if (_enable_buzzer) {
					Buzzer(250,25);
				}
				mb->status = 1;
			}
		} else {
			warning = 1;
			Buzzer(250,25);
			InvalidateDisplay();
		}
	} else
	if (type==NOTIFY_RELEASED) {
		//modal dialog
		if (mb->status && IsHit((CONTROL*)mb,x,y)) {
			mb->status = 0;
			mb->base.visible = 0;
			InvalidateDisplay();
		} else {
			warning = 0;
			InvalidateDisplay();
		}
	} else
	if (type==NOTIFY_UPDATE) {
		MESSAGE* m1 = mb->message1;
		MESSAGE* m2 = mb->message2;
		MESSAGE* m3 = mb->message3;
		int xc = (mb->base.left+mb->base.right)/2;
		int y = mb->base.top+20;
		int x;

		ui_draw_filled_rectangle(mb->base.left,mb->base.top,mb->base.right,mb->base.bottom,mb->bgcolor,mb->edgecolor);

		if (m1) {
			x = xc-(m1->base.right-m1->base.left)/2;
			ui_draw_icon(m1->tga,x,y);
			y += m1->base.bottom-m1->base.top+5;
		}
		if (m2) {
			x = xc-(m2->base.right-m2->base.left)/2;
			ui_draw_icon(m2->tga,x,y);
			y += m2->base.bottom-m2->base.top+5;
		}
		if (m3) {
			x = xc-(m3->base.right-m3->base.left)/2;
			ui_draw_icon(m3->tga,x,y);
		}
		
		ui_draw_icon(mb->ok,mb->ok_left,mb->ok_top);
		if (mb->status) {
			ui_draw_rectangle(mb->ok_left,mb->ok_top,mb->ok_right,mb->ok_bottom,MAGENTA);
		}
		
		if (warning) {
			ui_draw_rectangle_linewidth(mb->base.left,mb->base.top,mb->base.right,mb->base.bottom,MAGENTA,3);
		}
	}
	
	return ecode;
}

int ui_messagebox_show(MESSAGEBOX* mb, MESSAGE* m1, MESSAGE* m2, MESSAGE* m3)
{	
	mb->message1 = m1;
	mb->message2 = m2;
	mb->message3 = m3;
	mb->base.visible = 1;
	InvalidateDisplay();
	return 0;
}

int ui_messagebox_hide(MESSAGEBOX* mb)
{	
	mb->base.visible = 0;
	InvalidateDisplay();
	return 0;
}