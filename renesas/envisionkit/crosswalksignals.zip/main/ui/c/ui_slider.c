/**
 * ui_slider.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>
	
int Notify_slider(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	SLIDER* s = (SLIDER*)me;

	UIINPUT* uii = (UIINPUT*)param1;
	uint16 x = uii?uii->x:0;
	uint16 y = uii?uii->y:0;

	if (type==NOTIFY_INIT) {
		WriteValueToBuddy(s->buddy,s->dataType,s->init);
	} else	
	if (type==NOTIFY_PRESSED) {
		if (IsHit((CONTROL*)s,x,y)) {
			if (s->style==1) {
				/* vertical xpos is fixed on the bar */
				s->ypos = y;
				s->value = (y-s->posmin)*(s->vmax-s->vmin)/(s->posmax-s->posmin)+s->vmin;
			} else {
				/* horizontal, ypos is fixed on the bar */
				s->xpos = x;
				s->value = (x-s->posmin)*(s->vmax-s->vmin)/(s->posmax-s->posmin)+s->vmin;
			}
			WriteValueToBuddy(s->buddy,s->dataType,s->value);
		}
	} else
	if (type==NOTIFY_RELEASED) {
	} else
	if (type==NOTIFY_MOVE && uii->status&UI_TOUCH) {
		if (IsHit((CONTROL*)s,x,y)) {
			if (s->style==0) {
				/* horizontal, ypos is fixed on the bar */
				x = min(s->posmax,max(x,s->posmin));
				s->xpos = x;
				s->value = (x-s->posmin)*(s->vmax-s->vmin)/(s->posmax-s->posmin)+s->vmin;
				WriteValueToBuddy(s->buddy,s->dataType,s->value);
			} else {
				/* vertical xpos is fixed on the bar */
				y = min(s->posmin,max(y,s->posmax));
				s->ypos = y;
				s->value = (y-s->posmin)*(s->vmax-s->vmin)/(s->posmax-s->posmin)+s->vmin;
				WriteValueToBuddy(s->buddy,s->dataType,s->value);
			}
		}
	} else
	if (type==NOTIFY_UPDATE) {
		if (s->base.visible) {
			TGAHEADER* tga = (TGAHEADER*)s->knobimage;
			uint16 knobleft,knobtop,count=0,x,y;
			
			/* update knob pos */
			if (s->buddy) {
				if (s->dataType==BOOL_T||s->dataType==INT_T||s->dataType==LONGINT_T) {
					int_t ivalue = *(int_t*)s->buddy;
					s->value = (real_t)ivalue;
					count = i2s(ivalue,s->text,sizeof(s->text),0);
				} else {
					qreal q;
					s->value = *(real_t*)s->buddy;
					q = ConvR2Q(s->value);
					count = q2s(q,s->text,sizeof(s->text)-2-s->accuracy,s->accuracy,0);
				}
			}
			if (s->style==1) {
				/* vertical xpos is fixed on the bar */
				s->ypos = (uint16)((s->value-s->vmin)*(s->posmax-s->posmin)/(s->vmax-s->vmin)+s->posmin);
			} else {
				/* horizontal, ypos is fixed on the bar */
				s->xpos = (uint16)((s->value-s->vmin)*(s->posmax-s->posmin)/(s->vmax-s->vmin)+s->posmin);
			}			
			
			/* back ground image */
			ui_draw_icon(s->bgimage,s->base.left,s->base.top);
			
			/* knob image */
			knobleft = s->xpos-tga->width/2;
			knobtop = s->ypos-tga->height/2;
			ui_draw_icon(s->knobimage,knobleft,knobtop);			
			
			/* text out of buddy */
			x = (s->base.left+s->base.right-count*6)/2;
			y = s->base.bottom-20;
			ui_draw_text_transparent(s->text,x,y,BLACK);			
		}
	}
	return ecode;
}
