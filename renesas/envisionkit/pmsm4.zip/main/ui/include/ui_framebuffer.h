/**
 * ui_framebuffer.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created 
 */
 
#ifndef __FRAMEBUFFER_H__
#define	__FRAMEBUFFER_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

extern color_t* ui_get_active_framebuffer();
extern color_t* ui_get_hidden_framebuffer();
extern uint16 ui_get_framebuffer_width();
extern uint16 ui_get_framebuffer_height();
extern void ui_clear_framebuffer(color_t bgcolor);
extern void ui_draw_framebuffer();
extern void ui_switch_framebuffer();
extern void ui_draw_pixel(color_t* p, color_t color);
extern color_t ui_get_pixel_color(color_t* p);

#endif
