/**
 * ui_led.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __LED_H__
#define	__LED_H__

#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

typedef struct __LED
{
	CONTROL			base;

	/* led */
	const uint8*	onimage;	/* on image */
	const uint8*	offimage;	/* off image */
	const real_t	threshold;	/* threshold level */
	void*			buddy;		/* buddy */
	const uint8		dataType;	/* buddy data type */
} LED;

extern int Notify_led(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif