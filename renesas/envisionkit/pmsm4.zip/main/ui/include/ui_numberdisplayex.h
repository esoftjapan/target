/**
 * ui_numberdisplayex.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */
 
#ifndef __NUMBERDISPLAYEX_H__
#define	__NUMBERDISPLAYEX_H__
 
#include <vlx_types.h>
#include <ui_types.h>
#include <ui_control.h>

#ifndef NUMDIGITS
#define	NUMDIGITS		(64)
#endif

typedef struct __NUMBERDISPLAYEX
{
	CONTROL			base;				//base class

	const uint16	pitch;				//pitch between digits
	const color_t	fgcolor;			//foreground color
	const color_t	bgcolor;			//background color
	const color_t	edgecolor;			//edge color
	const uint8		ndigits;			//number of total digits
	const uint8		precision;			//number of fraction didgits
	const uint16	title_width;		//width of title
	const uint16	unit_width;			//width of unit
	const real_t	scale;				//sacling factor
	const real_t	smooth;				//smoothing coefficient
	real_t			smoothed_value;		//smoothed value
	void*			buddy;				//buddy
	const uint8		dataType;			//buddy data type
	char			value[NUMDIGITS];	//number
	 
	//title & unit image
	const uint8*	title;				//title image
	const uint8*	unit;				//unit image
	
	//font
	const uint8*	tga_0;				//TGA format font of '0'
	const uint8*	tga_1;				//TGA format font of '1'
	const uint8*	tga_2;				//TGA format font of '2'
	const uint8*	tga_3;				//TGA format font of '3'
	const uint8*	tga_4;				//TGA format font of '4'
	const uint8*	tga_5;				//TGA format font of '5'
	const uint8*	tga_6;				//TGA format font of '6'
	const uint8*	tga_7;				//TGA format font of '7'
	const uint8*	tga_8;				//TGA format font of '8'
	const uint8*	tga_9;				//TGA format font of '9'
	const uint8*	tga_dot;			//TGA format font of '.'
	const uint8*	tga_plus;			//TGA format font of '+'
	const uint8*	tga_minus;			//TGA format font of '-'
} NUMBERDISPLAYEX;

extern int Notify_numberdisplayex(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif
