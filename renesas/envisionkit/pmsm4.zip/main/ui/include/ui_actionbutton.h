/**
 * ui_actionbutton.h
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#ifndef __ACTIONBUTTON_H__
#define	__ACTIONBUTTON_H__

#include <ui_types.h>
#include <ui_control.h>

typedef struct __ACTIONBUTTON
{
	CONTROL				base;

	ACTIONTYPE			type;				//action type
	const uint8*		caption;			//bitmap image of caption
	color_t				bg_color;			//background color
	color_t				edge_color;			//edge colore
	int8				status;				//button status
	int8				panel;				//panel ID to be open
} ACTIONBUTTON;

extern int Notify_actionbutton(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2);

#endif