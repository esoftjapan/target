/**
 * ui_group.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */

#include <ui_vlx.h>
	
int Notify_group(NOTIFYTYPE type, CONTROL* me, void* param1, void* param2)
{
	int ecode = 0;
	UIGROUP* g = (UIGROUP*)me;
	TGAHEADER* tga = (TGAHEADER*)g->caption;

	if (type==NOTIFY_UPDATE) {
		if (g->base.visible) {
			int16 x1 = g->base.left;
			int16 y1 = g->base.top;
			int16 x2 = g->base.right;
			int16 y2 = g->base.bottom;
			int16 x = x1+10;
			int16 y = y1-tga->height/2;

			ui_draw_rectangle_linewidth(x1,y1,x2,y2,g->edgecolor,1);
			ui_draw_icon(g->caption,x,y);
		}
	}
	return ecode;
}
