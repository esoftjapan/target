/**
 * qmath.c
 *
 * Copyright(C) 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 */
 
/**
 * Qx.y format : fixed point real data
 * 
 * 32bit 2's complement
 * x: length of integer part = 32-__qbit
 * y: length of fractional part = __qbit
 *
 * Single Precision Floating Point Format
 * value = s*2^(m-127)*(1+f)
 *
 *  31 30    23 22              0
 * +--+--------+-----------------+
 * |s |  m(8)  |      f(23)      |
 * +--+--------+-----------------+
 *
 * Double Precision Floating Point Format
 * value = s*2^(m-1023)*(1+f)
 *
 *  63 62          52 51                              0
 * +--+--------------+---------------------------------+
 * |s |    m(11)     |              f(52)              |
 * +--+--------------+---------------------------------+
 *
 */
 
#include <stdlib.h>
#include <math.h>
#include "qmath.h"


#ifndef min
#define	min(x,y)	((x)<(y)? x:y)
#endif
#ifndef max
#define	max(x,y)	((x)>(y)? x:y)
#endif

#ifndef abs
#define abs(x)		((x)>0?(x):-(x))
#endif

#define	positive_qmax	(0x7fffffff)				/* max of qreal */
#define	negative_qmax	(0x80000000)				/* min of qreal */
#define	qreal_sign		(0x80000000)				/* sign bit of qreal */

#define	float_sign		(0x80000000)				/* sign bit */
#define	float_hidden	(0x800000)					/* hidden bit */
#define	float_frac		(0x7fffff)					/* mask of fractional part */
#define	float_man		(0x7f800000)				/* mask of mantissa */

#define	double_sign		(0x8000000000000000)		/* sign bit */
#define	double_hidden	(0x10000000000000)			/* hidden bit */
#define	double_frac		(0xfffffffffffff)			/* mask of fractional part */
#define	double_man		(0x7ff0000000000000)		/* mask of mantissa */

static int __qbit = 16;

int get_qbit()
{
	return __qbit;
}

int isqov(qreal q)
{
	int ov = (q==positive_qmax)||(q==negative_qmax);
	return ov;
}

/**
 * CAUTION; no overflow checked
 * This function is not usefull, same as lhs+rhs
 */
qreal qadd(qreal lhs, qreal rhs)
{
	return lhs+rhs;
}

/**
 * CAUTION; no overflow checked
 * This function is not usefull, same as lhs-rhs
 */
qreal qsub(qreal lhs, qreal rhs)
{
	return lhs-rhs;
}

/**
 * lhs*rhs
 */
qreal qmul(qreal lhs, qreal rhs)
{
	qreal res;
	int64 tmp = lhs;

	tmp *= rhs;
	tmp >>= __qbit;

	if (tmp>=0) {
		if (tmp>=positive_qmax) {
			return positive_qmax;
		}
	} else {
		int64 tmp1 = -tmp;
		if (tmp1>=positive_qmax) {
			return negative_qmax;
		}
	}
	res = (qreal)tmp;
	return res;
}

/**
 * lhs/rhs
 */
qreal qdiv(qreal lhs, qreal rhs)
{
	qreal res;
	int64 tmp = lhs;

	tmp <<= __qbit;
	tmp /= rhs;

	if (tmp>=0) {
		if (tmp>=positive_qmax) {
			return positive_qmax;
		}
	} else {
		long long int tmp1 = -tmp;
		if (tmp1>=positive_qmax) {
			return negative_qmax;
		}
	}
	res = (qreal)(tmp);
	return res;
}

qreal i2q(int intpart)
{
	qreal q;	
	q = intpart<<__qbit;
	return q;
}

int q2i(qreal rhs)
{
	qreal lhs;
	
	if (rhs>0) {
		lhs = rhs>>__qbit;
	} else {
		lhs = (-rhs)>>__qbit;
		lhs = -lhs;
	}
	return lhs;
}

/**
 * convert from float to qreal
 */
qreal f2q(float rhs)
{
	qreal res;
	uint32 frac;
	uint32 tmp = *(uint32*)&rhs;
	int sign = tmp&float_sign;
	uint32 f = tmp&float_frac; 
	int m = (tmp&float_man)>>23;
	int n = m-127+__qbit-23;
	
	if (tmp==0||tmp==float_sign) {
		return 0;
	}
	if (n>7) {
		/* over flow */
		if (sign) {
			res = negative_qmax;
		} else {
			res = positive_qmax;
		}
		return res;
	} else
	if (n<-31) {
		/* under flow */ 
		return 0;
	}

	/* shift (1+f) left or right */
	frac = float_hidden+f;
	if (n==0) {
		res = frac;
	} else
	if (n>0) {
		res = frac<<n;
	} else {
		n = -n;
		res = (frac+(1<<(n-1)))>>n;
	}
	if (sign) {
		res = -res;
	}
	return res;
}

/**
 * convert qreal to float
 */
float q2f(qreal rhs)
{
	float lhs;
	uint32 res,sign,tmp,bit,m,f;
	int pos,n;
	
	if (rhs==0) {
		return 0.0f;
	}
	if (rhs&qreal_sign) {
		tmp = -rhs;
		sign = float_sign;
	} else {
		tmp = rhs;
		sign = 0;
	}
	for (pos=31; pos>=0; pos--) {
		bit = 1<<pos;
		if (tmp & bit) {
			break;
		}
	}
	m = pos-__qbit+127;
	n = pos-23;
	f = tmp & (~bit);
	if (n>0) {
		f = f>>n;
	} else {
		f = f<<(-n);
	}
	res = sign+(m<<23)+f;
	lhs = *(float*)&res;
	return lhs;
}

/**
 * convert double to qreal
 */
qreal d2q(double rhs)
{
	qreal res;
	uint64 frac;
	uint64 tmp = *(uint64 *)&rhs;
	int sign = (tmp&double_sign)==0? 0:1;
	uint64 f = tmp&double_frac;
	int m = (tmp&double_man)>>52;
	int n = m-1023+__qbit-52;
	
	if (tmp==0||tmp==double_sign) {
		return 0;
	}
	if (n>7) {
		/* over flow */
		if (sign) {
			res = negative_qmax;
		} else {
			res = positive_qmax;
		}
		return res;
	} else
	if (n<-63) {
		/* under flow */ 
		return 0;
	}

	//shift (1+f) to left or right
	frac = double_hidden+f;
	if (n==0) {
		res = (int)frac;
	} else
	if (n>0) {
		res = (int)(frac<<n);
	} else {
		n = -n;
		res = (int)((frac+((uint64)1<<(n-1)))>>n);

	}
	if (sign) {
		res = -res;
	}
	return res;
}

/**
 * convert qreal to double
 */
double q2d(qreal rhs)
{
	double lhs;
	uint64 res,sign,tmp,bit,m,f;
	int pos,n;
	
	if (rhs==0) {
		return 0.0f;
	}
	if (rhs&qreal_sign) {
		tmp = -rhs;
		sign = double_sign;
	} else {
		tmp = rhs;
		sign = 0;
	}
	for (pos=63; pos>=0; pos--) {
		bit = (uint64)1<<pos;
		if (tmp & bit) {
			break;
		}
	}
	m = pos-__qbit+1023;
	n = pos-52;
	f = tmp & (~bit);
	if (n>0) {
		f = f>>n;
	} else {
		f = f<<(-n);
	}
	res = sign+(m<<52)+f;
	lhs = *(double*)&res;
	return lhs;
}

/**
 * convert qreal to decimal text
 * x = a(n)10^n+a(n-1)10^(n-1)+...+a(1)10+a(0)+b(1)10^(-1)+b(2)10^(-2)+....+b(m)10^(-m)
 */
int q2s(qreal src, char* s, int count, int precision, int plus_sign)
{
	char c;
	int i,j,n1,n2,nfrac;
	int a,b,mask,x;
	int sign = (src&qreal_sign)==0? 0: 1;
	char s1[20],s2[20];

	count = min(20,count);

	if (src==0) {
		s[0] = '0';
		s[1] = 0;
		return 1;
	}
		
	if (sign) {
		src = -src;
	}
		
	mask = (1<<__qbit)-1;

	a = src>>__qbit;
	b = src & mask;

	//integer part, LSB first
	i = 0;
	while (i<count-1) {
		x = a%10;
		c = (char)('0'+x);
		s1[i++] = c;
		a = a/10;
		if (a==0) {
			break;
		}
	}
	n1 = i;

	//fractional part
	if (plus_sign||sign) {
		//3 extra characters : sign,decimal point,terminator
		nfrac = count-n1-3;
	} else {
		//2 extra characters : decimal point,terminator
		nfrac = count-n1-2;
	}
	nfrac = min(precision,nfrac);
	i = 0;
	while (i<nfrac) {
		b &= mask;
		b *= 10;
		x = b;
		x >>= __qbit;
		c = (char)('0'+x);
		s2[i++] = c;
	}
	n2 = i;

	/**
	 * reverse integer part+'.'+fractional part+terminator
	 */
	i = 0;
	if (plus_sign) {
		s[i++] = sign>0? '-':'+';
	} else
	if (sign) {
		s[i++] = '-';
	}
	for (j=0; j<n1; j++) {
		s[i++] = s1[n1-j-1];
	}
	if (n2>0) {
		s[i++] = '.';
	}
	for (j=0; j<n2; j++) {
		s[i++] = s2[j];
	}
	s[i++] = 0;
	return i;
}

int i2s(int src, char* s, int count, int plus_sign)
{
	char c;
	int i,j,n1;
	int a,x;
	int sign = (src&qreal_sign)==0? 0: 1;
	char s1[20];

	count = min(20,count);

	if (sign) {
		src = -src;
	}
	a = src;

	//integer part, LSB first
	i = 0;
	while (i<count-1) {
		x = a%10;
		c = (char)('0'+x);
		s1[i++] = c;
		a = a/10;
		if (a==0) {
			break;
		}
	}
	n1 = i;

	/**
	 * reverse integer part
	 */
	i = 0;
	if (plus_sign) {
		s[i++] = sign>0? '-':'+';
	} else
	if (sign) {
		s[i++] = '-';
	}
	for (j=0; j<n1; j++) {
		s[i++] = s1[n1-j-1];
	}
	s[i++] = 0;
	return i;
}

#ifdef _MSC_VER
extern int _snprintf(char *str, int size, const char *format, ...);
int d2s(double v, char* s, int count, int precision, int plus_sign)
{
	int len;

	if (abs(v)<32767) {
		qreal q = d2q(v);
		len = q2s(q,s,count,precision,plus_sign);
	} else {
		if (plus_sign) {
			len = _snprintf(s,count,"%+.*f",precision,v);
		} else {
			len = _snprintf(s,count,"%.*f",precision,v);
		}
	}
	return len;
}

int f2s(float v, char* s, int count, int precision, int plus_sign)
{
	int len;

	if (abs(v)<32767) {
		qreal q = f2q(v);
		len = q2s(q,s,count,precision,plus_sign);
	} else {
		if (plus_sign) {
			len = _snprintf(s,count,"%+.*f",precision,v);
		} else {
			len = _snprintf(s,count,"%.*f",precision,v);
		}
	}
	return len;
}
#else
extern int snprintf(char *str, size_t size, const char *format, ...);
int d2s(double v, char* s, int count, int precision, int plus_sign)
{
	int len;

	if (abs(v)<32767) {
		qreal q = d2q(v);
		len = q2s(q,s,count,precision,plus_sign);
	} else {
		if (plus_sign) {
			len = snprintf(s,count,"%+.*f",precision,v);
		} else {
			len = snprintf(s,count,"%.*f",precision,v);
		}
	}
	return len;
}

int f2s(float v, char* s, int count, int precision, int plus_sign)
{
	int len;

	if (abs(v)<32767) {
		qreal q = f2q(v);
		len = q2s(q,s,count,precision,plus_sign);
	} else {
		if (plus_sign) {
			len = snprintf(s,count,"%+.*f",precision,v);
		} else {
			len = snprintf(s,count,"%.*f",precision,v);
		}
	}
	return len;
}
#endif

double s2d(const char* s)
{
//	double value = strtod(s,0); //multiple definition error
	double value = atof(s);
	return value;
}

#ifdef _MSC_VER
/* CAUTION: strtof is not standard in C89 */
float s2f(const char* s)
{
	float value = (float)s2d(s);
	return value;
}
#else
extern float strtof(const char *nptr, char **endptr);
float s2f(const char* s)
{
	float value = strtof(s,0);
	return value;
}
#endif

int s2i(const char* s)
{
	return atoi(s);
}

/**
 * round up or down by 1-2-5
 *
 *	value	up		down
 * ------------------------------
 *	+7.0	10		5
 *	+3.0	5		2
 *	+1.5	2		1
 *	+0.5	1		0.1
 *	-0.5	-0.1	-1
 *	-3.0	-2		-5
 *	-7.0	-5		-10
 */
float roundup125f(float x, float* psf)
{
	float n,z,y,sf;

	if (fabsf(x)<1e-9f) {
		if (psf) {
			*psf = 1.0f;
		}
		y = 0.0f;
		return y;
	}

	n = floorf(log10f(fabsf(x)));
	sf = powf(10.0f,n);
	z = x/sf;

	if (z>5.0f) {
		sf *= 10.0f;
		y = 1.0f*sf;
	} else
	if (z>2.0f) {
		y = 5.0f*sf;
	} else
	if (z>1.0f) {
		y = 2.0f*sf;
	} else
	if (z>0.0f) {
		y = sf;
	} else
	if (z>-1.0f) {
		sf *= 0.1f;
		y = -sf;
	} else
	if (z>-2.0f) {
		y = -sf;
	} else
	if (z>-5.0f) {
		y = -2.0f*sf;
	} else {
		y = -5.0f*sf;
	}

	if (psf) {
		*psf = sf;
	}
	return y;
}

float rounddown125f(float x, float* psf)
{
	float n,z,y,sf;

	if (fabsf(x)<1e-9f) {
		if (psf) {
			*psf = 1.0f;
		}
		y = 0.0f;
		return y;
	}

	n = floorf(log10f(fabsf(x)));
	sf = powf(10.0f,n);
	z = x/sf;

	if (z>=5.0f) {
		y = 5.0f*sf;
	} else
	if (z>=2.0f) {
		y = 2.0f*sf;
	} else
	if (z>=1.0f) {
		y = 1.0f*sf;
	} else
	if (z>=0.0f) {
		sf *= 0.1f;
		y = sf;
	} else
	if (z>=-1.0f) {
		y = -sf;
	} else
	if (z>=-2.0f) {
		y = -2.0f*sf;
	} else
	if (z>=-5.0f) {
		y = -5.0f*sf;
	} else {
		sf *= 10.0f;
		y = -sf;
	}

	if (psf) {
		*psf = sf;
	}
	return y;
}

double roundup125d(double x, double* psf)
{
	double n,z,y,sf;

	if (fabsf(x)<1e-9) {
		if (psf) {
			*psf = 1.0;
		}
		y = 0.0;
		return y;
	}

	n = floor(log10(fabs(x)));
	sf = pow(10.0,n);
	z = x/sf;

	if (z>5.0) {
		sf *= 10.0;
		y = sf;
	} else
	if (z>2.0) {
		y = 5.0*sf;
	} else
	if (z>1.0) {
		y = 2.0*sf;
	} else
	if (z>0.0) {
		y = sf;
	} else
	if (z>-1.0) {
		sf *= 0.1;
		y = -sf;
	} else
	if (z>=-2.0) {
		y = -sf;
	} else
	if (z>-5.0) {
		y = -2.0*sf;
	} else {
		y = -5.0*sf;
	}

	if (psf) {
		*psf = sf;
	}
	return y;
}

double rounddown125d(double x, double* psf)
{
	double n,z,y,sf;

	if (fabsf(x)<1e-9) {
		if (psf) {
			*psf = 1.0;
		}
		y = 0.0;
		return y;
	}

	n = floor(log10(fabs(x)));
	sf = pow(10.0,n);
	z = x/sf;

	if (z>=5.0) {
		y = 5.0*sf;
	} else
	if (z>=2.0) {
		y = 2.0*sf;
	} else
	if (z>=1.0) {
		y = sf;
	} else
	if (z>=0.0) {
		sf *= 0.1;
		y = sf;
	} else
	if (z>=-1.0) {
		y = -sf;
	} else
	if (z>=-2.0) {
		y = -2.0*sf;
	} else
	if (z>=-5.0) {
		y = -5.0*sf;
	} else {
		sf *= 10.0;
		y = -sf;
	}

	if (psf) {
		*psf = sf;
	}
	return y;
}
