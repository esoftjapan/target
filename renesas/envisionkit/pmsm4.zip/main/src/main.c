/**
 * main.c
 *
 * main routine for Envision Kit(RX65N)
 *
 * (C) eSoft 2019, All rights reserved
 * -----------------------------------------------------------
 *	2019/4/16		YT
 */
#include <iodefine.h>
#include "model.h"
#include "ui_system.h"
#include "ui_utils.h"
#include "ui_touchpanel.h"
#include "glcdc.h"

int __run;
unsigned long long int __SysTick;

static const real_t __avg_rate = 0.999f;
static real_t __sysclk_period;
static real_t __inst_step_process_time = 0;
static real_t __avg_step_process_time = 0;
static real_t __max_step_process_time = 0;
static real_t __display_process_time = 0;

/* the following are defined in ui_touchpanel.c */
extern int ui_touchpanel_event();
#define	TOUCHPANEL_EVENT_NONE			(0x00000000)
#define	TOUCHPANEL_EVENT_PRESSED		(0x00000001)
#define	TOUCHPANEL_EVENT_RELEASED		(0x00000002)
static int _touchpanel_event;

static void SetupModelStepTimer();
static void InitTickMeter();
static long GetTickMeter();

int main(void)
{
	PANEL* panel;

	GLCDCInitialize();
	ui_touchpanel_init();

	/**
	 * _init() must be called before initializing timer
	 */
	__init(__t);
	__run = 1;
	__SysTick = 0;

#if NUMPANELS>0	
	panel = GetActivePanel();
	panel->invalid = 1;
	panel->notify(NOTIFY_INIT,(CONTROL*)panel,0,0);
#endif

	/* timer for model step */
	InitTickMeter();
	SetupModelStepTimer();

    while(__run) {
#if NUMPANELS>0
		if (GLCDCIsBlanking()) {
			long begin,end;

			begin = GetTickMeter();
			/*******************************************************/
			panel = GetActivePanel();
			panel->invalid = 1;
			panel->notify(NOTIFY_UPDATE,(CONTROL*)panel,0,0);
			GLCDCClearBlankingFlag();
			GLCDCSwitchFrameBuffer();
			/*******************************************************/
			end = GetTickMeter();
			__display_process_time = (end-begin)*__sysclk_period;
		}
		/* touch panel */
		_touchpanel_event = ui_touchpanel_event();
		if (_touchpanel_event&TOUCHPANEL_EVENT_PRESSED) {
			UIINPUT uii;

			uii.x = ui_touchpanel_get_x();
			uii.y = ui_touchpanel_get_y();
			uii.status = UI_TOUCH;
			panel->notify(NOTIFY_PRESSED,(CONTROL*)panel,&uii,0);
			_touchpanel_event &= ~TOUCHPANEL_EVENT_PRESSED;
		} else
		if (_touchpanel_event&TOUCHPANEL_EVENT_RELEASED) {
			UIINPUT uii;

			uii.x = ui_touchpanel_get_x();
			uii.y = ui_touchpanel_get_y();
			uii.status = UI_TOUCH;
			panel->notify(NOTIFY_RELEASED,(CONTROL*)panel,&uii,0);
			_touchpanel_event &= ~TOUCHPANEL_EVENT_RELEASED;
		}
#endif
    }

	__final(__t);
	return 0;
}

// ICLK=120MHz
#define	PCLK	60000000

void SetupModelStepTimer()
{
	real_t cmcor;

	/* initialize timer for model step */
	SYSTEM.PRCR.WORD = 0xA502;
	MSTP(CMT0) = 0;
	SYSTEM.PRCR.WORD = 0xA500;
	cmcor = (PCLK/8.0f)*__stepTime-1;
	if (cmcor<65536) {
		CMT0.CMCR.BIT.CKS = 0;
	} else {
		cmcor = (PCLK/32.0f)*__stepTime-1;
		if (cmcor<65536) {
			CMT0.CMCR.BIT.CKS = 1;
		} else {
			cmcor = (PCLK/128.0f)*__stepTime-1;
			if (cmcor<65536) {
				CMT0.CMCR.BIT.CKS = 2;
			} else {
				cmcor = (PCLK/512.0f)*__stepTime-1;
				if (cmcor<65536) {
					CMT0.CMCR.BIT.CKS = 3;
				} else {
					cmcor = 65535;
					CMT0.CMCR.BIT.CKS = 3;
				}
			}
		}
	}

	CMT0.CMCR.BIT.CMIE = 1;
    CMT0.CMCNT = 0;
	CMT0.CMCOR = (unsigned short)cmcor;
	_IEN(_CMT0_CMI0) = 1;
	_IPR(_CMT0_CMI0) = 10; //5; /* model step interrupt level */
	CMT.CMSTR0.BIT.STR0 = 1;
}

/* CMTU0_CMT0 interrupt service routine */
void ModelStepIsr()
{
	long begin,end;

	/* set IPL=6, Ibit=1 */
//	asm("mvtc #05010000h,psw");

	__SysTick++;
	__t = __SysTick*__stepTime;

	/* model step */
	begin = GetTickMeter();
	__prestep(__t);
	__step(__t);
	__integrate(__t);
	__poststep(__t);
	end = GetTickMeter();

	/* step process time */
	__inst_step_process_time = (end-begin)*__sysclk_period;
	if (__inst_step_process_time>__max_step_process_time) {
		__max_step_process_time = __inst_step_process_time;
	}
	__avg_step_process_time = __avg_step_process_time*__avg_rate+__inst_step_process_time*(1.0f-__avg_rate);
}

void FatalError(const char* filename, int line, const char* fmt, ...)
{
	while (1) {};
}

void EnterCritical()
{

}

void ExitCritical()
{

}

real_t GetModelTime()
{
	return __t;
}

void Quit()
{

}

void InvalidateDisplay()
{
}

int _enable_buzzer = 0;
void Buzzer(int freq, int duration)
{

}

int32 StepProcessTimeNanosec(uint8 type)
{
	long elapsed = 0;

	if (type==1) {
		/* averaged */
		elapsed = (int)(__avg_step_process_time*1e9f);
	} else
	if (type==2){
		/* maximum */
		elapsed = (int)(__max_step_process_time*1e9f);
	} else
	if (type==3) {
		/* display */
		elapsed = (int)(__display_process_time*1e9f);
	}

	return elapsed;
}

void InitTickMeter()
{
	/* 処理速度計測用カウンタ */
	SYSTEM.PRCR.WORD = 0xA502;
	MSTP(CMTW0) = 0;
	SYSTEM.PRCR.WORD = 0xA500;
	if (__stepTime<65536.0f*(8.0f/PCLK)) {
		CMTW0.CMWCR.BIT.CKS = 0;	/* PCLK/8 */
		__sysclk_period = 1.0f/(PCLK/8);
	} else
	if (__stepTime<65536.0f*(32.0f/PCLK)) {
		CMTW0.CMWCR.BIT.CKS = 1;	/* PCLK/32 */
		__sysclk_period = 1.0f/(PCLK/32);
	} else
	if (__stepTime<65536.0f*(128.0f/PCLK)) {
		CMTW0.CMWCR.BIT.CKS = 2;	/* PCLK/128 */
		__sysclk_period = 1.0f/(PCLK/128);
	} else {
		CMTW0.CMWCR.BIT.CKS = 3;	/* PCLK/512 */
		__sysclk_period = 1.0f/(PCLK/512);
	}
	CMTW0.CMWCR.BIT.CMS = 0; //32bit counter
	CMTW0.CMWCNT = 0;
	CMTW0.CMWCOR = 0;
	CMTW0.CMWSTR.BIT.STR = 1;
}

long GetTickMeter()
{
	return CMTW0.CMWCNT;
}

////////////////////////////////////////////////////////////////////////////////////////////
