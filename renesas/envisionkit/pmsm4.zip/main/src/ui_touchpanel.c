/**
 * ui_touchpanel.c
 * (C)eSoft 2019, All rights reserved.
 *
 * -------------------------------------------------------------------
 * 2019/04/18		YT
 */
 
/**
 * [タッチスクリーン仕様]
 * コントローラ： 			FocalTech製FT5206
 * 方式：					容量式
 * インターフェース：			I2c
 * スレーブアドレス：			0x38-->0x70=0x38<<1
 * ビットレート：				350KHz, PCLK=60MHz, n=0, N=5
 * RX65N側インターフェース：	SCI6、簡易I2C
 * リセットピン				P07
 * 割り込み				P02
 */
 
#include "iodefine.h"

static void sleep(int msec);

static int i2c_init()
{
	/**
	 *  タッチスクリーンをリセット
	 *  リセットパルス幅Trst＞5msec
	 *  リセット後の開始時間Trsi>300msecと長い
	 *  パワーオンリセットがあるので、本ルーチンは割愛
	 */
#if 0
	PORT0.PDR.BIT.B7 = 1;
	PORT0.PODR.BIT.B7 = 0;
	sleep(10);
	PORT0.PODR.BIT.B7 = 1;
	sleep(1000);
#endif

	/*************************************
	 *  I/Oポート
	 ************************************/
	/* オープンドレインの設定は不要 */
//	PORT0.ODR0.BIT.B0 = 1; 	//P00
//	PORT0.ODR0.BIT.B2 = 1;	//P01
	
	/*===================================*/
	MPC.PWPR.BIT.B0WI = 0;
	MPC.PWPR.BIT.PFSWE = 1;
	/*===================================*/

	//SDA6:P00
	MPC.P00PFS.BIT.PSEL = 0x0a;
	PORT0.PMR.BIT.B0 = 1;

	//SCL6:P01
	MPC.P01PFS.BIT.PSEL = 0x0a;
	PORT0.PMR.BIT.B1 = 1;

	/**
	 * P02を、割り込み(IRQ10)または汎用入力ポートとして使用
	 */
#if 0
	MPC.P02PFS.BIT.ISEL = 1;
	PORT0.PMR.BIT.B2 = 1;
#else
	PORT0.PMR.BIT.B2 = 0;	//汎用ポート
	PORT0.PDR.BIT.B2 = 0;	//入力ポート
//	PORT0.PCR.BIT.B2 = 1;	//プルアップ
#endif
	
	/*===================================*/
	MPC.PWPR.BIT.PFSWE = 0;
	MPC.PWPR.BIT.B0WI = 1;
	/*===================================*/
	
	/* モジュールを有効にする */
	/************************************/
	SYSTEM.PRCR.WORD = 0xA502;
	MSTP(SCI6) = 0;
	SYSTEM.PRCR.WORD = 0xA500;
	/************************************/

	/* SCR=0 */
	SCI6.SCR.BYTE = 0;
	
	/* バスを開放する */
	SCI6.SIMR3.BIT.IICSDAS = 3;		//high Z, SIMR3.IICSDAS=11b
	SCI6.SIMR3.BIT.IICSCLS = 3;		//high Z, SIMR3.IICSCLS=11b
	
	/* クロック他 */
	SCI6.SMR.BYTE = 0; 				//CKS=PCLK/1
	SCI6.SCMR.BIT.SDIR = 1;			//MSB first
	SCI6.SCMR.BIT.SINV = 0;			//非反転
	SCI6.SCMR.BIT.SMIF = 0;			//非スマートカードインターフェース
	
	/* ボーレートの設定、350kHZ */
	SCI6.BRR = 5;					//BRR=60e6/64*2^-1*350e3 = 5
	
	/* MDDR */
	
	/* 各種設定 */
	SCI6.SEMR.BIT.NFEN = 0;			//ノイズフィルタは使用しない
	SCI6.SEMR.BIT.BRME = 1;			//ビットレート生成を有効にする
	SCI6.SNFR.BIT.NFCS = 0;			//ノイズフィルタ
	SCI6.SIMR1.BIT.IICM = 1;		//I2Cモード
	SCI6.SIMR1.BIT.IICDL = 3;		//SDA遅延=2から3
	SCI6.SIMR2.BIT.IICACKT = 1;		//NACK送信
	SCI6.SIMR2.BIT.IICCSC = 1;		//クロック同期
	SCI6.SPMR.BYTE = 0;
	
	/* 送信と受信を有効にする、割り込みは使用しない */
	SCI6.SCR.BYTE = 0x30;			//SCR.RE(4)=1, TE(5)=1, RIE(6)=0, TIE(7)=0
	return 0;
}

static int i2c_tx(unsigned char slave, unsigned char data)
{
	int err = 0;
	
	/* スタートシーケンスを開始する */
	SCI6.SIMR3.BYTE = 0x51;	//SIMR3.IICSTAREQ=1, IICSCLS=01b, IICSDAS=01b
	
	/* スタートシーケンスが完了するのを待つ */
	while (SCI6.SIMR3.BIT.IICSTIF==0) {
		;
	}
	
	/* バスを獲得する */
	SCI6.SIMR3.BYTE = 0;	//SMIR3.IICSTIF=0, IICSCLS=00b, IICSDAS=00b
	
	/* スレーブアドレス＋ライトモードを送信する */
	SCI6.TDR = slave;
	
	/* 送信が完了するのを待つ */
	while (SCI6.SSR.BIT.TDRE==0) {
		;
	}
	while (SCI6.SSR.BIT.TEND==0) {
		;
	}
	
	/* NACKが返ってきたらエラー */
	if (SCI6.SISR.BIT.IICACKR!=0) {
		//error
		err = -1;
		goto Lstop;
	}
	
	/* データバイトを送信する */
	SCI6.TDR = data;
	
	/* 送信が完了するのを待つ */
	while (SCI6.SSR.BIT.TDRE==0) {
		;
	}
	while (SCI6.SSR.BIT.TEND==0) {
		;
	}	
	
Lstop:
	/*　ストップシーケンスを開始する */
	SCI6.SIMR3.BYTE = 0x54;		//SIMR3.IISTPREQ=1, IICSCLS=01b, IICSDAS= 01b
	
	/* ストップシーケンスが完了するのを待つ */
	while (SCI6.SIMR3.BIT.IICSTIF==0) {
		;
	}
	
	/* バスを開放する */
	SCI6.SIMR3.BYTE = 0xf0;		//SIMR3.IICSTIF=0; IICSCLS=11b, IICSDAS=11b 
	
	return err;
}

static int i2c_write(unsigned char slave, unsigned char* data, int count)
{
	int i,err = 0;

	/* スタートシーケンスを開始する */
	SCI6.SIMR3.BYTE = 0x51;	//SIMR3.IICSTAREQ=1, IICSCLS=01b, IICSDAS=01b

	/* スタートシーケンスが完了するのを待つ */
	while (SCI6.SIMR3.BIT.IICSTIF==0) {
		;
	}

	/* バスを獲得する */
	SCI6.SIMR3.BYTE = 0;	//SMIR3.IICSTIF=0, IICSCLS=00b, IICSDAS=00b

	/* スレーブアドレス＋ライトモードを送信する */
	SCI6.TDR = slave;

	/* 送信が完了するのを待つ */
	while (SCI6.SSR.BIT.TDRE==0) {
		;
	}
	while (SCI6.SSR.BIT.TEND==0) {
		;
	}

	/* NACKが返ってきたらエラー */
	if (SCI6.SISR.BIT.IICACKR!=0) {
		//error
		err = -1;
		goto Lstop;
	}

	for (i=0; i<count; i++) {
		/* データバイトを送信する */
		SCI6.TDR = data[i];

		/* 送信が完了するのを待つ */
		while (SCI6.SSR.BIT.TDRE==0) {
			;
		}
		while (SCI6.SSR.BIT.TEND==0) {
			;
		}

		/* NACKが返ってきたらエラー */
		if (SCI6.SISR.BIT.IICACKR!=0) {
			//error
			err = -1;
			goto Lstop;
		}
	}

Lstop:
	/*　ストップシーケンスを開始する */
	SCI6.SIMR3.BYTE = 0x54;		//SIMR3.IISTPREQ=1, IICSCLS=01b, IICSDAS= 01b

	/* ストップシーケンスが完了するのを待つ */
	while (SCI6.SIMR3.BIT.IICSTIF==0) {
		;
	}

	/* バスを開放する */
	SCI6.SIMR3.BYTE = 0xf0;		//SIMR3.IICSTIF=0; IICSCLS=11b, IICSDAS=11b

	return err;
}

static unsigned char i2c_rx(unsigned char slave)
{
	unsigned char data = 0xff;
	
	/* スタートシーケンスを開始する */
	SCI6.SIMR3.BYTE = 0x51;		//SIMR3.IICSTAREQ=1, IICSCLS=01b, IICSDAS=01b
	
	/* スタートシーケンスが完了するのを待つ */
	while (SCI6.SIMR3.BIT.IICSTIF==0) {
		;
	}

	/* バスを獲得する */
	SCI6.SIMR3.BYTE = 0;	//SMIR3.IICSTIF=0, IICSCLS=00b, IICSDAS=00b
	
	/* スレーブアドレス＋リードモードを送信 */
	SCI6.TDR = slave|0x1;
	
	/* 送信が完了するのを待つ */
	while (SCI6.SSR.BIT.TDRE==0) {
		;
	}
	while (SCI6.SSR.BIT.TEND==0) {
		;
	}
	
	/* NACKが返ってきたらエラー  */
	if (SCI6.SISR.BIT.IICACKR!=0) {
		//error
		data = 0xff;
		goto Lstop;
	}

	/**
	 *  RIICではダミーリードが必要だが、SCIの簡易I2Cでは不要か?
	 */
//	unsigned xxx = SCI6.RDR;
	
	/* 最後のデータを受診した時に、マスタはこれが最終バイトであることをスレーブに知らせるためにNACKを送信する */
	SCI6.SIMR2.BIT.IICACKT = 1;

	/**
	 * ダミーライトが必要な理由：
	 * クロックを供給できるのはマスタだけである。
	 * 受信時も、スレーブにクロックを供給する必要がある。
	 * それには、SDA線がwired-ANDのロジックであることから無害なダミーデータ0xffを送信する。
	 * スレーブはそのクロックに乗せてデータを送信してくる。
	 */
	SCI6.TDR = 0xff;

	/* スレーブからの受信を待つ */
	while (SCI6.SSR.BIT.RDRF==0) {
		;
	}

	/**
	 * RX65Nのハードウエアマニュアルでは受信レジスタRDRを読んだ後、TXIを待つようになっているが、これでは正しく受信データが読めない。
	 * 位置を入れ替える。
	 * 実際、t>200くらいの待ち時間がある。
	 */
	int t = 0;
	while (SCI6.SSR.BIT.TEND==0) {
		t++;
	}

	/* 受信データを読む */
	data = SCI6.RDR;

Lstop:
	/* ストップシーケンスを開始する */
	SCI6.SIMR3.BYTE = 0x54;		//SIMR3.IISTPREQ=1, IICSCLS=01b, IICSDAS= 01b
	
	/* ストップシーケンスが完了するのを待つ */
	while (SCI6.SIMR3.BIT.IICSTIF==0) {
		;
	}
	
	/* バスを開放する */
	SCI6.SIMR3.BYTE = 0xf0;	//SIMR3.IICSTIF=0; IICSCLS=11b, IICSDAS=11b
	
	return data;
}

/**
 * アセンブラリストを見るとfor文は6サイクルかかる、ICK=120MHz時、2ウェイトサイクル
 * 従って、for文１回は6*3/120MHz=0.15usec
 */
static void sleep(int msec)
{
	int i,N;
	
	N = (int)(msec*1000/0.15f);
	for (i=0; i<N; i++) {
		;
	}
}

static unsigned char touchpanel_read_register(unsigned char slave, unsigned char reg)
{
	int err;
	unsigned char data;

	err = i2c_tx(slave,reg);
	data = i2c_rx(slave);
	return data;
}

///////////////////////////////////////////////////////////////////////////////////////////
/**
 * FT5206の割り込みモードは２種類ある。A4Hレジスタで設定する
 * (1)クエリーモード：一連の動作の間、出続ける。このモードを使用する。
 * (2)トリガーモード：指を動かす毎に発生する。使用しない。
 */

#define	SLAVE_ADDRESS					(0x70)
#define	PUT_DOWN						(0)
#define	PUT_UP							(1)
#define	CONTACT							(3)

#define	TOUCHPANEL_EVENT_NONE			(0x00000000)
#define	TOUCHPANEL_EVENT_PRESSED		(0x00000001)
#define	TOUCHPANEL_EVENT_RELEASED		(0x00000002)
int _x = 0;
int _y = 0;

static int _p02_prev = 1;

int ui_touchpanel_init(void)
{
	int err;
	unsigned char data[2];

	err = i2c_init();

	//割り込みモードをポーリングに設定する
	data[0] = 0xa4;
	data[1] = 0;
	err = i2c_write(SLAVE_ADDRESS,data,2);

	_x = 0;
	_y = 0;
	return err;
}


int ui_touchpanel_event(void)
{
	int ret, points;
	unsigned char p02;

	ret = TOUCHPANEL_EVENT_NONE;
	
	//割り込み入力ポートをポーリングする、LOWアクティブ
	p02 = PORT0.PIDR.BIT.B2;
	if ((_p02_prev==1) && (p02==0)) {
		//立ち下がりエッジ、押されたとき
		unsigned char byte,xh,xl,yh,yl;
		int type;

		byte = touchpanel_read_register(0x70,0x03);
		type = byte>>6;
		xh = byte&0xf;
		xl = touchpanel_read_register(0x70,0x04);
		yh = 0xf & touchpanel_read_register(0x70,0x05);
		yl = touchpanel_read_register(0x70,0x06);

		_x = (xh<<8)+xl;
		_y = (yh<<8)+yl;

		if (type==PUT_DOWN) {
			ret = TOUCHPANEL_EVENT_PRESSED;
		}
	} else
	if ((_p02_prev==0) && (p02==1)) {
		//立ち上がりエッジ、離された時
		unsigned char byte,xh,xl,yh,yl;
		int type;

		byte = touchpanel_read_register(0x70,0x03);
		type = byte>>6;
		xh = byte&0xf;
		xl = touchpanel_read_register(0x70,0x04);
		yh = 0xf & touchpanel_read_register(0x70,0x05);
		yl = touchpanel_read_register(0x70,0x06);

		_x = (xh<<8)+xl;
		_y = (yh<<8)+yl;

		if (PUT_UP) {
			ret = TOUCHPANEL_EVENT_RELEASED;
		}
	}
	_p02_prev = p02;
	
	return ret;
}

int ui_touchpanel_get_x(void)
{
	return _x;
}

int ui_touchpanel_get_y(void)
{
	return _y;
}

int ui_touchpanel_timer_callback(void)
{
	return 0;
}

void ui_calibrate_touchpanel(void)
{
}

/**
 * デバッグ時は、e2studioのDynamic printf機能を利用すると良い。
 *
 * タッチ数					0x02
 * イベントタイプ					0x03	b7-b6
 * XH						0x03	b3-b0
 * XL						0x04	b7-b0
 * YH						0x05	b7-b0
 * YL						0x06	b7-b0
 * Chip Ventor ID 			0xa3	b7-b0	0x55
 * CTPM Vendor's Chip ID 	0xa8 	b7-b0	0x79
 */
int ui_touchpanel_test()
{
	int err = 0;

#if 0
	unsigned char id1,id2;

	id1 = touchpanel_read_register(0x70,0xa3);
	id2 = touchpanel_read_register(0x70,0xa8);
#endif

#if 1
	while (1) {
		unsigned char xh,xl,yh,yl;
		int byte,points,x,y,type;

		points = touchpanel_read_register(0x70,0x02)&0x0f;
		byte = touchpanel_read_register(0x70,0x03);
		type = byte>>6;
		xh = byte&0xf;
		xl = touchpanel_read_register(0x70,0x04);
		yh = touchpanel_read_register(0x70,0x05);
		yl = touchpanel_read_register(0x70,0x06);

		x = (xh<<8)+xl;
		y = (yh<<8)+yl;

		sleep(1000);
	}
#endif
	return err;
}

