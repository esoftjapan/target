/**
 * glcdc.h
 *
 *
 *
 * Copyright 2019 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2019/04/16		YT				created
 *
 */

#pragma once

#define	LCD_HDOT			(480)
#define	LCD_VDOT			(272)

void GLCDCInitialize();
int GLCDCIsBlanking();
void GLCDCClearBlankingFlag();
void GLCDCSwitchFrameBuffer();
