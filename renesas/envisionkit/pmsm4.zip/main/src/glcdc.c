/**
 * glcdc.c
 *
 * Copyright 2018 eSoft. All right reserved.
 *
 * ---------------------------------------------------------------------------------------
 * 2018/06/01		YT				created
 *
 */

/**
 * 基本タイミング：
 *
 *             HSYNC_WIDTH(4)
 *	HSYNC		----+   +------------------------------------+   +------
 *				    |   |                                    |   |
 *                  +---+                                    +---+
 *                      H_BACK_PORCH(40)          H_FRONT_PORCH(5)
 *                      <------>                      <------>
 *                             +----------------------+
 *                             |       HE(480)        |
 * DEN 			---------------+                      +-----------------
 *				                                      |
 *                                                    |
 *                                                    v               VSYNC
 *						                            VPOS割り込み          |
 *				    +---+------+----------------------+------+      +---+
 *                  |   |      |                      |      |      |		VYNC_WIDTH(1H)
 *				    +---+------+----------------------+------+      +---+
 *                  |   |      |                      |      |          |	V_BACK_PORCH(8H)
 *                  |   |      |                      |      |          |
 *				    +---+------+----------------------+------+          +
 *                  |   |      |**********************|      |          |
 *                  |   |      |**********************|      |          |
 *                  |   |      |**********************|      |          |
 *                  |   |      |       480x272        |      |          |	VE(272H)
 *                  |   |      |**********************|      |          |
 *                  |   |      |**********************|      |          |
 *                  |   |      |**********************|      |          |
 *				    +---+------+----------------------+------+          +
 *                  |   |      |                      |      |          |	V_FRONT_PORCH(8H)+V_EXTRA(183H)
 *				    +---+------+----------------------+------+          +
 */

#include "iodefine.h"
#include <string.h>
#include "glcdc.h"

#define	HSIZE				(LCD_HDOT)
#define	VSIZE				(LCD_VDOT)
#define	BITS_PER_PIXEL		(16)
#define	BYTES_PER_LINE		((BITS_PER_PIXEL * HSIZE) / 8)			//960
#define	LINE_OFFSET			(((BYTES_PER_LINE + 63) / 64) * 64)		//960
#define	HSIZE_PHYS			((LINE_OFFSET * 8) / BITS_PER_PIXEL)	//480
#define	BYTES_PER_BUFFER	(LINE_OFFSET * VSIZE)					//261120

#define	H_FRONT_PORCH		(5)
#define	H_BACK_PORCH		(40)
#define	V_FRONT_PORCH		(8)
#define	V_BACK_PORCH		(8)
#define	HSYNC_WIDTH			(4)
#define	VSYNC_WIDTH			(1)
#define	H_MARGINE			(2)
#define	V_MARGINE			(1)
#define	BGHSIZE_HP			(H_FRONT_PORCH-H_MARGINE+HSYNC_WIDTH+H_BACK_PORCH)
#define	BGVSIZE_VP			(V_FRONT_PORCH-V_MARGINE+VSYNC_WIDTH+V_BACK_PORCH)
#define	BGSYNC_HP			(H_FRONT_PORCH-H_MARGINE)
#define	BGSYNC_VP			(V_FRONT_PORCH-V_MARGINE)
#define	H_PERIOD			(H_FRONT_PORCH+HSYNC_WIDTH+H_BACK_PORCH+HSIZE)
#define V_PERIOD			(V_FRONT_PORCH+VSYNC_WIDTH+V_BACK_PORCH+VSIZE)

/**
 * -----------------------------------------------------------------------------------------------------
 * [1]シングルバッファ方式
 * RX56Nには内蔵のRAM領域が２か所ある。0x0～0x4000(RAM1:256KB)と0x800000から0x860000（RAM2:384KB）である
 * 内蔵RAMをフレームバッファとしたいが、ダブルバッファ方式にすると255KB×2の領域が必要になる。
 * プログラムのデータ領域は129KBしかない。多くのデータ領域が必要な場合は、シングルバッファ方式にすることになる。
 * シングルバッファ方式の場合は、フリッカを防止するため帰線期間中に描画をする
 * 1ラインの描画時間は、529/10MHz=52.9usec、 帰線期間はV_FRONT_PORTC(8H)なので、描画に割り当てられる時間は、423.3usec
 * これでは、あまりに短すぎるので、帰線期間を延長する。
 * 1フレームの描画時間は、52.9usecx289H=15.3msec
 * 描画更新レートを40fps(25msec)とすると、最大延長時間は、25msec-15.3msec=9.7msec
 * 従って、追加の垂直フロントポーチは、18msec/52.9usec=183H
 * -----------------------------------------------------------------------------------------------------
 * [2]ダブルバッファ方式のRAM割り当て
 * ustack:	0x800000,	LEN=4kB
 * istack:	0x801000, 	LEN=4kB
 * data:	0x802000,	LEN=121kB
 * fb1:		0x000400,	LEN=255KB
 * fb2:		0x820400,	LEN=255KB
 * -----------------------------------------------------------------------------------------------------
 */
#define	DIUBLEFRAMEBUFFER

#ifdef DIUBLEFRAMEBUFFER
/* ダブルバッファリング */
#define	V_EXTRA				(0)
int dcdr = 24;				//10MHz=240MHz/24
static unsigned short* fb1 = (unsigned short*)0x000400;
static unsigned short* fb2 = (unsigned short*)0x820400;
unsigned short* fb[2];
int _active_fb = 0;
#else
/* シングルバッファリング */
#define	V_EXTRA				(183)
int dcdr = 32;				//7.5MHz=240MHz/24
static unsigned short* fb1 = (unsigned short*)0x800000;
static unsigned short* fb2 = (unsigned short*)0x800000;
unsigned short* fb[2];
int _active_fb = 0;
#endif

static int blanking = 0;

static int hsize = HSIZE;
static int vsize = VSIZE;
static int h_back_porch = H_BACK_PORCH;
static int v_back_porch = V_BACK_PORCH;
static int bghsize_hp = BGHSIZE_HP;
static int bgvsize_vp = BGVSIZE_VP;
static int bgsync_hp = BGSYNC_HP;
static int bgsync_vp = BGSYNC_VP;
static int grchs = BGHSIZE_HP-BGSYNC_HP;
static int grcvs = BGVSIZE_VP-BGSYNC_VP;
static int h_period = H_PERIOD;			//529
static int v_period = V_PERIOD+V_EXTRA;	//289+V_EXTRA

void GLCDCInitialize()
{
	unsigned int bgmon;

	/* バックライト */
	PORT6.PDR.BIT.B6 = 1;
	PORT6.PODR.BIT.B6 = 1;

	/* LCD_RESET(DISP) */
	PORT6.PDR.BIT.B3 = 1;
	PORT6.PODR.BIT.B3 = 1;

	/*------------------------------*/
	/* I/Oピン機能設定開始 */
	MPC.PWPR.BIT.B0WI = 0;
	MPC.PWPR.BIT.PFSWE = 1;

	/* LCD_CLK */
	MPC.PB5PFS.BIT.PSEL = 0x25;
	PORTB.PMR.BIT.B5 = 1;

	/* LCD_TCON0 */
	MPC.PB4PFS.BIT.PSEL = 0x25;
	PORTB.PMR.BIT.B4 = 1;

	/* LCD_TCON2 */
	MPC.PB2PFS.BIT.PSEL = 0x25;
	PORTB.PMR.BIT.B2 = 1;

	/* LCD_TCON3 */
	MPC.PB1PFS.BIT.PSEL = 0x25;
	PORTB.PMR.BIT.B1 = 1;

	/* LCD_DATA0 */
	MPC.PB0PFS.BIT.PSEL = 0x25;
	PORTB.PMR.BIT.B0 = 1;

	/* LCD_DATA1 */
	MPC.PA7PFS.BIT.PSEL = 0x25;
	PORTA.PMR.BIT.B7 = 1;

	/* LCD_DATA2 */
	MPC.PA6PFS.BIT.PSEL = 0x25;
	PORTA.PMR.BIT.B6 = 1;

	/* LCD_DATA3 */
	MPC.PA5PFS.BIT.PSEL = 0x25;
	PORTA.PMR.BIT.B5 = 1;

	/* LCD_DATA4 */
	MPC.PA4PFS.BIT.PSEL = 0x25;
	PORTA.PMR.BIT.B4 = 1;

	/* LCD_DATA5 */
	MPC.PA3PFS.BIT.PSEL = 0x25;
	PORTA.PMR.BIT.B3 = 1;

	/* LCD_DATA6 */
	MPC.PA2PFS.BIT.PSEL = 0x25;
	PORTA.PMR.BIT.B2 = 1;

	/* LCD_DATA7 */
	MPC.PA1PFS.BIT.PSEL = 0x25;
	PORTA.PMR.BIT.B1 = 1;

	/* LCD_DATA8 */
	MPC.PA0PFS.BIT.PSEL = 0x25;
	PORTA.PMR.BIT.B0 = 1;

	/* LCD_DATA9 */
	MPC.PE7PFS.BIT.PSEL = 0x25;
	PORTE.PMR.BIT.B7 = 1;

	/* LCD_DATA10 */
	MPC.PE6PFS.BIT.PSEL = 0x25;
	PORTE.PMR.BIT.B6 = 1;

	/* LCD_DATA11 */
	MPC.PE5PFS.BIT.PSEL = 0x25;
	PORTE.PMR.BIT.B5 = 1;

	/* LCD_DATA12 */
	MPC.PE4PFS.BIT.PSEL = 0x25;
	PORTE.PMR.BIT.B4 = 1;

	/* LCD_DATA13 */
	MPC.PE3PFS.BIT.PSEL = 0x25;
	PORTE.PMR.BIT.B3 = 1;

	/* LCD_DATA14 */
	MPC.PE2PFS.BIT.PSEL = 0x25;
	PORTE.PMR.BIT.B2 = 1;

	/* LCD_DATA15 */
	MPC.PE1PFS.BIT.PSEL = 0x25;
	PORTE.PMR.BIT.B1 = 1;

	/* I/Oピン設定の終わり */
	MPC.PWPR.BIT.PFSWE = 0;
	MPC.PWPR.BIT.B0WI = 1;
	/*------------------------------*/

	/* GLCDCモジュールを有効にする */
	SYSTEM.PRCR.WORD = 0xA502;
	MSTP(GLCDC) = 0;
	SYSTEM.PRCR.WORD = 0xA500;

	/* リセットを解除、1-->SWRST */
	GLCDC.BGEN.BIT.SWRST = 1;

	/* クロック */
	GLCDC.PANELCLK.BIT.CLKEN = 1;
	GLCDC.PANELCLK.BIT.CLKSEL = 1;
	GLCDC.PANELCLK.BIT.PIXSEL = 0;
	GLCDC.PANELCLK.BIT.DCDR = dcdr;

	/* クロックを有効にして、リセットが解除するのを待つ */
	while (GLCDC.BGMON.BIT.SWRST==0) {;}

	/* 画像フォーマット BGR=565形式 */
	GLCDC.OUTSET.BIT.FORMAT = 2;

	/* 水平同期信号 */
	GLCDC.BGHSIZE.BIT.HW = hsize;
	GLCDC.BGHSIZE.BIT.HP = bghsize_hp;
	GLCDC.BGSYNC.BIT.HP = bgsync_hp;
	GLCDC.BGPERI.BIT.FH = h_period-1;

	/* 垂直同期信号 */
	GLCDC.BGVSIZE.BIT.VW = vsize;
	GLCDC.BGVSIZE.BIT.VP = bgvsize_vp;
	GLCDC.BGSYNC.BIT.VP = bgsync_vp;
	GLCDC.BGPERI.BIT.FV = v_period-1;

	/* 基準タイミング設定レジスタ */
	GLCDC.TCONTIM.BIT.OFFSET = 0;
	GLCDC.TCONTIM.BIT.HALF = 0;

	/* 水平タイミング設定レジスタ */
	/* HSYNC=STHA */
	GLCDC.TCONSTHA1.BIT.HW = 1;
	GLCDC.TCONSTHA1.BIT.HS = 0;

	/* STHA==>TCON2 */
	GLCDC.TCONSTHA2.BIT.SEL = 2;
	GLCDC.TCONSTHA2.BIT.INV = 1;
	GLCDC.TCONSTHA2.BIT.HSSEL = 0;

	/* 垂直タイミング設定レジスタ */
	/* VSYNC=STVA */
	GLCDC.TCONSTVA1.BIT.VW = 1;
	GLCDC.TCONSTVA1.BIT.VS = 0;

	/* STVA==>TCOM0 */
	GLCDC.TCONSTVA2.BIT.SEL = 0;
	GLCDC.TCONSTVA2.BIT.INV = 1;

	/* DE=STVB^STHB==>TCON3 */
	/* STHB */
	GLCDC.TCONSTHB1.BIT.HW = hsize;
	GLCDC.TCONSTHB1.BIT.HS = h_back_porch+1;
	/* STVB */
	GLCDC.TCONSTVB1.BIT.VW = vsize;
	GLCDC.TCONSTVB1.BIT.VS = v_back_porch+1;
	/* DE */
	GLCDC.TCONSTHB2.BIT.SEL = 7; //DE
	GLCDC.TCONSTHB2.BIT.INV = 0;
	GLCDC.TCONSTHB2.BIT.HSSEL = 0;
	GLCDC.TCONDE.BIT.INV = 0;

	/* 出力位相 */
	int clk_edge = 0; //0:rising edge, 1:falling edge
	GLCDC.CLKPHASE.BIT.TCON3EDG = clk_edge;
	GLCDC.CLKPHASE.BIT.TCON2EDG = clk_edge;
	GLCDC.CLKPHASE.BIT.TCON1EDG = clk_edge;
	GLCDC.CLKPHASE.BIT.TCON0EDG = clk_edge;
	GLCDC.CLKPHASE.BIT.LCDEDG = clk_edge;

	/* 輝度調整 */
	GLCDC.OUTVEN.BIT.VEN = 1;
	GLCDC.BRIGHT1.BIT.BRTG = 0x200;
	GLCDC.BRIGHT2.BIT.BRTB = 0x200;
	GLCDC.BRIGHT2.BIT.BRTR = 0x200;

	/* コントラスト補正 */
	GLCDC.CONTRAST.BIT.CONTR = 0x80;
	GLCDC.CONTRAST.BIT.CONTG = 0x80;
	GLCDC.CONTRAST.BIT.CONTB = 0x80;

	/* 背景色 */
	GLCDC.BGCOLOR.BIT.B = 255;
	GLCDC.BGCOLOR.BIT.G = 0;
	GLCDC.BGCOLOR.BIT.R = 0;

	//フレームバッファ
	fb[0] = fb1;
	fb[1] = fb2;
	memset(fb[0],0,BYTES_PER_BUFFER);
	memset(fb[1],0,BYTES_PER_BUFFER);
	_active_fb = 0;
	blanking = 0;

	/***********************
	 *  グラフィックス1
	 ***********************/
	GLCDC.GR1FLMRD.BIT.RENB = 0;				//0:無効、1:有効
	GLCDC.GR1FLM2 = 0;							//使用しない
	GLCDC.GR1FLM3.BIT.LNOFF = LINE_OFFSET;
	GLCDC.GR1FLM5.BIT.DATANUM = hsize*2/64-1;	//480x2÷64-1=14
	GLCDC.GR1FLM5.BIT.LNNUM = vsize-1; 			//272-1=271
	GLCDC.GR1FLM6.BIT.FORMAT = 0; 				//RGB(565)

	//アルファブレンド1
	GLCDC.GR1AB1.BIT.DISPSEL = 0;		//0:背景, 1:下層, 2:前景（fb1）, 3:下層＋前景（fb1）
	GLCDC.GR1AB1.BIT.GRCDISPON = 0;		//グラフィック枠非表示
	GLCDC.GR1AB1.BIT.ARCDISPON = 0;		//アルファブレンド枠非表示
	GLCDC.GR1AB1.BIT.ARCON = 0;			//ピクセル単位アルファブレンド

	GLCDC.GR1BASE.BIT.R = 0;
	GLCDC.GR1BASE.BIT.B = 0;
	GLCDC.GR1BASE.BIT.G = 1;

	GLCDC.GR1AB2.BIT.GRCVS = grcvs;
	GLCDC.GR1AB2.BIT.GRCVW = vsize;

	GLCDC.GR1AB4.BIT.ARCVS = grcvs;
	GLCDC.GR1AB4.BIT.ARCVW = vsize;

	GLCDC.GR1AB3.BIT.GRCHS = grchs;
	GLCDC.GR1AB3.BIT.GRCHW = hsize;

	GLCDC.GR1AB5.BIT.ARCHS = grchs;
	GLCDC.GR1AB5.BIT.ARCHW = hsize;

	GLCDC.GR1AB6.BIT.ARCRATE = 0;
	GLCDC.GR1AB6.BIT.ARCCOEF = 0;

	GLCDC.GR1AB7.BIT.CKON = 0;
	GLCDC.GR1AB7.BIT.ARCDEF = 0;

	GLCDC.GR1AB8.LONG = 0;
	GLCDC.GR1AB9.LONG = 0;

	GLCDC.GR1CLUTINT.BIT.LINE = VSIZE-1;;
	GLCDC.GR1CLUTINT.BIT.SEL = 0;

	/***********************
	 * グラフィックス2
	 ***********************/
	GLCDC.GR2FLMRD.BIT.RENB = 1;				//0:無効、1:有効
	GLCDC.GR2FLM2 = (int)fb[0];
	GLCDC.GR2FLM3.BIT.LNOFF = LINE_OFFSET;
	GLCDC.GR2FLM5.BIT.DATANUM = hsize*2/64-1;	//480x2÷64-1=14
	GLCDC.GR2FLM5.BIT.LNNUM = vsize-1;			//272-1=271
	GLCDC.GR2FLM6.BIT.FORMAT = 0;				//BGR=565

	//アルファブレンド2
	GLCDC.GR2AB1.BIT.DISPSEL = 2;				//0:背景, 1:下層, 2:前景（fb2）, 3:下層＋前景（fb2）
	GLCDC.GR2AB1.BIT.GRCDISPON = 0;
	GLCDC.GR2AB1.BIT.ARCDISPON = 0;
	GLCDC.GR2AB1.BIT.ARCON = 0;

	GLCDC.GR2BASE.BIT.R = 0;
	GLCDC.GR2BASE.BIT.B = 0;
	GLCDC.GR2BASE.BIT.G = 255;

	GLCDC.GR2AB2.BIT.GRCVS = grcvs;
	GLCDC.GR2AB2.BIT.GRCVW = vsize;

	GLCDC.GR2AB4.BIT.ARCVS = grcvs;
	GLCDC.GR2AB4.BIT.ARCVW = vsize;

	GLCDC.GR2AB3.BIT.GRCHS = grchs;
	GLCDC.GR2AB3.BIT.GRCHW = hsize;

	GLCDC.GR2AB5.BIT.ARCHS = grchs;
	GLCDC.GR2AB5.BIT.ARCHW = hsize;

	GLCDC.GR2AB6.BIT.ARCRATE = 0;
	GLCDC.GR2AB6.BIT.ARCCOEF = 0;

	GLCDC.GR2AB7.BIT.CKON = 0;
	GLCDC.GR2AB7.BIT.ARCDEF = 0;

	GLCDC.GR2AB8.LONG = 0;
	GLCDC.GR2AB9.LONG = 0;

	GLCDC.GR2CLUTINT.BIT.LINE = VSIZE;	//このラインでVPOS割り込みが起きる
	GLCDC.GR2CLUTINT.BIT.SEL = 0;

	/* 割り込み */
	GLCDC.DTCTEN.BIT.VPOSDTC = 1;
	GLCDC.DTCTEN.BIT.GR1UFDTC = 1;
	GLCDC.DTCTEN.BIT.GR2UFDTC = 1;

	GLCDC.INTEN.BIT.VPOSINTEN = 1;
	GLCDC.INTEN.BIT.GR1UFINTEN = 0;
	GLCDC.INTEN.BIT.GR2UFINTEN = 0;

	EN(GLCDC,VPOS) = 1;
//	EN(GLCDC,GR1UF) = 1;
//	EN(GLCDC,GR1UF) = 1;

	int m,n,v;
	unsigned char byte;
	v = VECT_ICU_GROUPAL1; 	//v=113
	m = v/8;				//m=14
	n = v%8;				//n=1
//	ICU.IER[m].BIT.IEN1 = 1;
	byte = ICU.IER[m].BYTE;
	ICU.IER[m].BYTE = byte|(1<<n);
	ICU.IPR[v].BIT.IPR = 3;

	/* BGEN EN=1,VEN=1,SWRST=1 */
	GLCDC.BGEN.LONG = 0x00010101;
	bgmon = GLCDC.BGMON.LONG;
}

unsigned short* GetActiveFrameBuffer()
{
	return fb[_active_fb];
}

unsigned short* GetHiddenFrameBuffer()
{
	return fb[(_active_fb==0)?1:0];
}

/**
 * GLCDCからの割り込みサービスルーチン、 GROUPAL1
 * GLCDC-VPOS割り込みは、レジスタの更新を有効にするために最初に一度だけ先頭のラインで発生する
 * その後は、GLCDC.GR1CLUTINT.BIT.LINEで指定したラインで発生する。
 */
void GLCDCIsr()
{
	GLCDC.STCLR.LONG = 7;
	GLCDC.GR2VEN.BIT.VEN = 1;
	GLCDC.GR2FLM2 = (int)fb[_active_fb];

	blanking = 1;
}

void GLCDCSwitchFrameBuffer()
{
	_active_fb = (_active_fb==0)?1:0;
}

int GLCDCIsBlanking()
{
	return blanking;
}

void GLCDCClearBlankingFlag()
{
	blanking = 0;
}
